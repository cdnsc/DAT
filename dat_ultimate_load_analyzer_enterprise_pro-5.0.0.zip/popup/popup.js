/**
 * DAT Ultimate Load Analyzer - Popup Script
 * Manages the popup interface and communication with background/content scripts
 */

class PopupManager {
  constructor() {
    this.isLoading = true;
    this.currentTab = null;
    this.stats = {
      totalLoads: 0,
      bestDeals: 0,
      avgScore: 0,
      scanRate: 0
    };
    this.config = {
      minRatePerMile: 1.80,
      maxDeadhead: 150,
      minTotalRate: 2000
    };
  }

  // Initialize popup
  async initialize() {
    console.log('🚀 PopupManager: Initializing...');
    
    try {
      // Get current active tab
      await this.getCurrentTab();
      
      // Load current configuration
      await this.loadConfiguration();
      
      // Load current statistics
      await this.loadStatistics();
      
      // Setup event listeners
      this.setupEventListeners();
      
      // Update UI
      this.updateUI();
      
      // Check if we're on a DAT page
      await this.checkDATPageStatus();
      
      this.isLoading = false;
      this.hideLoading();
      
      console.log('✅ PopupManager: Initialization complete');
      
    } catch (error) {
      console.error('❌ PopupManager: Initialization failed:', error);
      this.showError('Failed to initialize popup');
    }
  }

  // Get current active tab
  async getCurrentTab() {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    this.currentTab = tabs[0];
    console.log('📋 Current tab:', this.currentTab?.url);
  }

  // Load configuration from background
  async loadConfiguration() {
    try {
      const response = await chrome.runtime.sendMessage({ type: 'GET_CONFIG' });
      if (response?.config) {
        this.config = response.config;
        console.log('📋 Configuration loaded:', this.config);
      }
    } catch (error) {
      console.error('Configuration loading failed:', error);
    }
  }

  // Load statistics from background
  async loadStatistics() {
    try {
      const response = await chrome.runtime.sendMessage({ type: 'GET_STATS' });
      if (response?.stats) {
        this.stats = response.stats;
        console.log('📊 Statistics loaded:', this.stats);
      }
    } catch (error) {
      console.error('Statistics loading failed:', error);
    }
  }

  // Setup event listeners
  setupEventListeners() {
    // Force scan button
    document.getElementById('force-scan').addEventListener('click', () => {
      this.forceScan();
    });

    // Export data button
    document.getElementById('export-data').addEventListener('click', () => {
      this.exportData();
    });

    // Clear all button
    document.getElementById('clear-all').addEventListener('click', () => {
      this.clearAll();
    });

    // Settings button
    document.getElementById('open-options').addEventListener('click', () => {
      this.openOptions();
    });

    // Filter inputs with debouncing
    const filterInputs = ['min-rate', 'max-deadhead', 'min-total'];
    filterInputs.forEach(id => {
      const input = document.getElementById(id);
      input.addEventListener('input', this.debounce(() => {
        this.updateFilters();
      }, 500));
    });

    // Real-time updates
    setInterval(() => {
      this.refreshData();
    }, 2000);
  }

  // Update UI elements
  updateUI() {
    // Update statistics
    document.getElementById('total-loads').textContent = this.stats.totalLoads || 0;
    document.getElementById('best-deals').textContent = this.stats.bestDeals || 0;
    document.getElementById('avg-score').textContent = Math.round(this.stats.avgScore || 0);
    document.getElementById('scan-rate').textContent = `${this.stats.scanRate || 0}/s`;

    // Update filter inputs
    document.getElementById('min-rate').value = this.config.minRatePerMile || 1.80;
    document.getElementById('max-deadhead').value = this.config.maxDeadhead || 150;
    document.getElementById('min-total').value = this.config.minTotalRate || 2000;

    // Update performance metrics
    this.updatePerformanceMetrics();
  }

  // Check if current page is DAT One
  async checkDATPageStatus() {
    const isDATPage = this.currentTab?.url?.includes('one.dat.com/search-loads');
    const statusDot = document.getElementById('status-dot');
    const statusText = document.getElementById('status-text');

    if (isDATPage) {
      statusDot.className = 'status-dot active';
      statusText.textContent = 'Analyzer Active';
      
      // Try to ping content script with retries
      let connected = false;
      let statusInfo = null;
      
      for (let attempt = 0; attempt < 3; attempt++) {
        try {
          statusInfo = await chrome.tabs.sendMessage(this.currentTab.id, { type: 'PING' });
          connected = true;
          break;
        } catch (error) {
          console.log(`Ping attempt ${attempt + 1} failed:`, error);
          if (attempt < 2) {
            await new Promise(resolve => setTimeout(resolve, 500)); // Wait 500ms before retry
          }
        }
      }
      
      if (connected && statusInfo) {
        if (statusInfo.initialized) {
          statusText.textContent = 'Analyzer Active & Connected';
          // Update stats with real-time data from content script
          if (statusInfo.stats) {
            this.stats.enhancedLoads = statusInfo.stats.enhancedLoads || 0;
            this.stats.totalLoads = statusInfo.stats.totalProcessed || 0;
            this.stats.lastScan = new Date().toISOString();
            this.updatePerformanceMetrics();
          }
        } else {
          statusText.textContent = 'Analyzer Active (Initializing...)';
        }
      } else {
        statusText.textContent = 'Analyzer Active (Loading...)';
        // Try to get status from background script
        try {
          const bgResponse = await chrome.runtime.sendMessage({ type: 'GET_STATS' });
          if (bgResponse && bgResponse.stats) {
            statusText.textContent = 'Analyzer Ready';
            this.stats = { ...this.stats, ...bgResponse.stats };
            this.updatePerformanceMetrics();
          }
        } catch (error) {
          console.log('Background script ping failed:', error);
        }
      }
    } else {
      statusDot.className = 'status-dot inactive';
      statusText.textContent = 'Not on DAT One page';
      this.disableControls();
    }
  }

  // Force scan action
  async forceScan() {
    if (!this.isDATPage()) {
      this.showNotification('Please navigate to DAT One load search page');
      return;
    }

    try {
      const button = document.getElementById('force-scan');
      button.textContent = 'Scanning...';
      button.disabled = true;

      await chrome.tabs.sendMessage(this.currentTab.id, { type: 'FORCE_SCAN' });
      
      setTimeout(() => {
        button.textContent = 'Force Scan';
        button.disabled = false;
        this.refreshData();
      }, 1000);

      console.log('🔍 Force scan triggered');
    } catch (error) {
      console.error('Force scan failed:', error);
      this.showNotification('Scan failed - content script not ready');
    }
  }

  // Export data action
  async exportData() {
    try {
      const data = {
        timestamp: new Date().toISOString(),
        stats: this.stats,
        config: this.config,
        url: this.currentTab?.url
      };

      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      
      await chrome.downloads.download({
        url: url,
        filename: `dat-analyzer-export-${new Date().toISOString().split('T')[0]}.json`
      });

      URL.revokeObjectURL(url);
      this.showNotification('Data exported successfully');
      console.log('📊 Data exported');
    } catch (error) {
      console.error('Export failed:', error);
      this.showNotification('Export failed');
    }
  }

  // Clear all action
  async clearAll() {
    if (!this.isDATPage()) {
      this.showNotification('Please navigate to DAT One load search page');
      return;
    }

    try {
      // Reset configuration to defaults
      const defaultConfig = {
        minRatePerMile: 0.50,
        maxDeadhead: 500,
        minTotalRate: 0
      };

      await chrome.runtime.sendMessage({
        type: 'UPDATE_CONFIG',
        data: defaultConfig
      });

      // Reset statistics
      this.stats = {
        totalLoads: 0,
        bestDeals: 0,
        avgScore: 0,
        scanRate: 0
      };

      this.config = defaultConfig;
      this.updateUI();
      this.showNotification('All filters and highlights cleared');
      console.log('🔄 All data cleared');
    } catch (error) {
      console.error('Clear all failed:', error);
      this.showNotification('Clear operation failed');
    }
  }

  // Open options page
  openOptions() {
    chrome.runtime.openOptionsPage();
    window.close();
  }

  // Update filters
  async updateFilters() {
    const newConfig = {
      minRatePerMile: parseFloat(document.getElementById('min-rate').value) || 0,
      maxDeadhead: parseInt(document.getElementById('max-deadhead').value) || 1000,
      minTotalRate: parseFloat(document.getElementById('min-total').value) || 0
    };

    try {
      await chrome.runtime.sendMessage({
        type: 'UPDATE_CONFIG',
        data: newConfig
      });

      this.config = { ...this.config, ...newConfig };
      console.log('🔧 Filters updated:', newConfig);
    } catch (error) {
      console.error('Filter update failed:', error);
    }
  }

  // Refresh data from background
  async refreshData() {
    if (this.isLoading) return;

    try {
      // Refresh statistics
      const statsResponse = await chrome.runtime.sendMessage({ type: 'GET_STATS' });
      if (statsResponse?.stats) {
        this.stats = statsResponse.stats;
      }

      // Update UI
      this.updateUI();
    } catch (error) {
      // Ignore errors during refresh - likely popup was closed
    }
  }

  // Update performance metrics
  updatePerformanceMetrics() {
    const metrics = document.getElementById('performance-metrics');
    const lastScan = this.stats.lastScan ? 
      new Date(this.stats.lastScan).toLocaleTimeString() : 
      'Never';
    
    const memory = performance.memory ? 
      `${Math.round(performance.memory.usedJSHeapSize / 1024 / 1024)}MB` : 
      'N/A';

    metrics.innerHTML = `
      Last scan: ${lastScan}<br>
      Memory usage: ${memory}<br>
      Enhanced loads: ${this.stats.enhancedLoads || this.stats.bestDeals || 0}
    `;
  }

  // Show loading state
  showLoading() {
    document.getElementById('loading').classList.add('show');
    document.getElementById('main-content').style.display = 'none';
  }

  // Hide loading state
  hideLoading() {
    document.getElementById('loading').classList.remove('show');
    document.getElementById('main-content').style.display = 'block';
  }

  // Show notification
  showNotification(message) {
    // Create temporary notification
    const notification = document.createElement('div');
    notification.style.cssText = `
      position: fixed;
      top: 10px;
      left: 50%;
      transform: translateX(-50%);
      background: #007bff;
      color: white;
      padding: 10px 20px;
      border-radius: 6px;
      font-size: 12px;
      z-index: 10000;
      box-shadow: 0 4px 12px rgba(0,0,0,0.2);
    `;
    notification.textContent = message;
    document.body.appendChild(notification);

    setTimeout(() => {
      notification.remove();
    }, 3000);
  }

  // Show error state
  showError(message) {
    const content = document.getElementById('main-content');
    content.innerHTML = `
      <div style="text-align: center; padding: 40px 20px; color: #dc3545;">
        <h3>Error</h3>
        <p style="margin-top: 10px; font-size: 14px;">${message}</p>
        <button onclick="location.reload()" style="margin-top: 20px; padding: 10px 20px; background: #007bff; color: white; border: none; border-radius: 6px; cursor: pointer;">
          Retry
        </button>
      </div>
    `;
    this.hideLoading();
  }

  // Disable controls when not on DAT page
  disableControls() {
    const controls = ['force-scan', 'clear-all'];
    controls.forEach(id => {
      const element = document.getElementById(id);
      if (element) {
        element.disabled = true;
        element.style.opacity = '0.5';
      }
    });
  }

  // Check if current page is DAT One
  isDATPage() {
    return this.currentTab?.url?.includes('one.dat.com/search-loads');
  }

  // Utility: Debounce function
  debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }
}

// Initialize popup when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  const popupManager = new PopupManager();
  popupManager.initialize();
});

console.log('🚀 DAT Ultimate Load Analyzer popup script loaded');
