// Fix script to replace HighPerformanceLoadDetector with LoadDetector
const fs = require('fs');

// Read the file
let content = fs.readFileSync('content-script-enterprise.js', 'utf8');

// Replace all occurrences
content = content.replace(/HighPerformanceLoadDetector/g, 'LoadDetector');

// Add initialization for load detector after the constructor calls
const searchPattern = /this\.loadDetector = new LoadDetector\(\);/g;
const replacementPattern = `this.loadDetector = new LoadDetector();
      
      // Initialize load detector
      if (this.loadDetector && typeof this.loadDetector.initialize === 'function') {
        this.loadDetector.initialize();
        this.loadDetector.onLoadDetected((loadData) => {
          this.handleDetectedLoad(loadData);
        });
      }`;

// Find the first occurrence and replace it with initialization
let firstReplace = true;
content = content.replace(searchPattern, (match) => {
  if (firstReplace) {
    firstReplace = false;
    return replacementPattern;
  }
  return match;
});

// Write the fixed file
fs.writeFileSync('content-script-enterprise.js', content, 'utf8');

console.log('✅ Fixed LoadDetector references in content-script-enterprise.js');
