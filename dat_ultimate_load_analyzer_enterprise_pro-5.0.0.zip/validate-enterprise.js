/**
 * DAT Ultimate Load Analyzer Enterprise - Comprehensive Validation Script
 * Enterprise-grade validation with security, performance, and compliance checks
 * Version: 4.0.0
 */

const fs = require('fs');
const path = require('path');

class EnterpriseValidator {
  constructor() {
    this.errors = [];
    this.warnings = [];
    this.info = [];
    this.validationResults = {
      coreFiles: false,
      enterpriseFiles: false,
      security: false,
      performance: false,
      compliance: false,
      dependencies: false
    };
  }

  /**
   * Run comprehensive enterprise validation
   */
  async validate() {
    console.log('\n🏢 DAT Ultimate Load Analyzer Enterprise - Validation Suite v4.0.0');
    console.log('================================================================================\n');

    try {
      // Core validation checks
      await this.validateCoreFiles();
      await this.validateEnterpriseFiles();
      await this.validateManifest();
      await this.validateSecurity();
      await this.validatePerformance();
      await this.validateCompliance();
      await this.validateDependencies();
      await this.validateConfiguration();
      
      // Generate final report
      this.generateValidationReport();
      
    } catch (error) {
      this.errors.push(`Critical validation error: ${error.message}`);
      this.generateValidationReport();
      process.exit(1);
    }
  }

  /**
   * Validate core extension files
   */
  async validateCoreFiles() {
    console.log('📁 Validating Core Files...');
    
    const requiredFiles = [
      'manifest.json',
      'background.js',
      'content-script-enterprise.js',
      'package.json',
      'README.md'
    ];

    const optionalFiles = [
      'content-script.js', // Legacy file
      'PROJECT-SUMMARY.md',
      'FIREFOX_INSTALL.md'
    ];

    let coreValid = true;

    requiredFiles.forEach(file => {
      if (this.fileExists(file)) {
        this.info.push(`✅ ${file} - Present`);
      } else {
        this.errors.push(`❌ ${file} - Missing (Required)`);
        coreValid = false;
      }
    });

    optionalFiles.forEach(file => {
      if (this.fileExists(file)) {
        this.info.push(`ℹ️  ${file} - Present (Optional)`);
      } else {
        this.warnings.push(`⚠️  ${file} - Missing (Optional)`);
      }
    });

    this.validationResults.coreFiles = coreValid;
  }

  /**
   * Validate enterprise-specific files
   */
  async validateEnterpriseFiles() {
    console.log('🏢 Validating Enterprise Files...');
    
    const enterpriseFiles = [
      'libs/enterprise-analytics.js',
      'libs/enterprise-dashboard.js',
      'libs/enterprise-security.js',
      'libs/analytics-engine.js',
      'libs/load-detector.js',
      'libs/ui-enhancer.js',
      'styles/enterprise-dashboard.css',
      'styles/content.css'
    ];

    const enterpriseDirectories = [
      'libs',
      'styles',
      'popup',
      'options',
      'icons'
    ];

    let enterpriseValid = true;

    // Check directories
    enterpriseDirectories.forEach(dir => {
      if (this.directoryExists(dir)) {
        this.info.push(`✅ ${dir}/ - Directory exists`);
      } else {
        this.errors.push(`❌ ${dir}/ - Directory missing`);
        enterpriseValid = false;
      }
    });

    // Check enterprise files
    enterpriseFiles.forEach(file => {
      if (this.fileExists(file)) {
        this.info.push(`✅ ${file} - Present`);
        
        // Validate file content
        this.validateFileContent(file);
      } else {
        this.errors.push(`❌ ${file} - Missing (Enterprise Required)`);
        enterpriseValid = false;
      }
    });

    this.validationResults.enterpriseFiles = enterpriseValid;
  }

  /**
   * Validate manifest.json for enterprise features
   */
  async validateManifest() {
    console.log('📋 Validating Enterprise Manifest...');
    
    try {
      const manifestContent = fs.readFileSync('manifest.json', 'utf8');
      const manifest = JSON.parse(manifestContent);

      // Check version
      if (manifest.version === '4.0.0') {
        this.info.push('✅ Manifest version 4.0.0');
      } else {
        this.warnings.push(`⚠️  Manifest version is ${manifest.version}, expected 4.0.0`);
      }

      // Check enterprise name
      if (manifest.name.includes('Enterprise')) {
        this.info.push('✅ Enterprise branding in name');
      } else {
        this.warnings.push('⚠️  Missing enterprise branding in name');
      }

      // Check permissions
      const requiredPermissions = [
        'activeTab', 'storage', 'notifications', 'scripting', 
        'background', 'tabs', 'webRequest', 'unlimitedStorage'
      ];

      requiredPermissions.forEach(permission => {
        if (manifest.permissions && manifest.permissions.includes(permission)) {
          this.info.push(`✅ Permission: ${permission}`);
        } else {
          this.warnings.push(`⚠️  Missing permission: ${permission}`);
        }
      });

      // Check host permissions
      const requiredHosts = [
        'https://one.dat.com/*',
        'https://mail.google.com/*'
      ];

      requiredHosts.forEach(host => {
        if (manifest.host_permissions && manifest.host_permissions.includes(host)) {
          this.info.push(`✅ Host permission: ${host}`);
        } else {
          this.errors.push(`❌ Missing host permission: ${host}`);
        }
      });

      // Check content scripts
      if (manifest.content_scripts && manifest.content_scripts.length > 0) {
        const contentScript = manifest.content_scripts[0];
        
        if (contentScript.js.includes('content-script-enterprise.js')) {
          this.info.push('✅ Enterprise content script configured');
        } else {
          this.errors.push('❌ Enterprise content script not configured');
        }

        if (contentScript.css.includes('styles/enterprise-dashboard.css')) {
          this.info.push('✅ Enterprise CSS configured');
        } else {
          this.warnings.push('⚠️  Enterprise CSS not configured');
        }
      }

    } catch (error) {
      this.errors.push(`❌ Manifest validation error: ${error.message}`);
    }
  }

  /**
   * Validate security implementation
   */
  async validateSecurity() {
    console.log('🛡️  Validating Security Features...');
    
    let securityValid = true;

    // Check enterprise security file
    if (this.fileExists('libs/enterprise-security.js')) {
      const content = this.readFile('libs/enterprise-security.js');
      
      // Check for security classes
      const securityClasses = [
        'EnterpriseDataProcessor',
        'AuditLogger',
        'ComplianceManager',
        'DataValidator'
      ];

      securityClasses.forEach(className => {
        if (content.includes(`class ${className}`)) {
          this.info.push(`✅ Security class: ${className}`);
        } else {
          this.errors.push(`❌ Missing security class: ${className}`);
          securityValid = false;
        }
      });

      // Check for encryption methods
      const encryptionMethods = ['encrypt', 'decrypt', 'generateEncryptionKey'];
      encryptionMethods.forEach(method => {
        if (content.includes(method)) {
          this.info.push(`✅ Encryption method: ${method}`);
        } else {
          this.warnings.push(`⚠️  Missing encryption method: ${method}`);
        }
      });

      // Check for audit logging
      if (content.includes('logDataProcessing') && content.includes('logError')) {
        this.info.push('✅ Audit logging implemented');
      } else {
        this.warnings.push('⚠️  Incomplete audit logging');
      }

    } else {
      this.errors.push('❌ Enterprise security file missing');
      securityValid = false;
    }

    this.validationResults.security = securityValid;
  }

  /**
   * Validate performance optimizations
   */
  async validatePerformance() {
    console.log('⚡ Validating Performance Features...');
    
    let performanceValid = true;

    // Check for performance monitoring
    if (this.fileExists('content-script-enterprise.js')) {
      const content = this.readFile('content-script-enterprise.js');
      
      const performanceFeatures = [
        'performanceMetrics',
        'debounce',
        'throttle',
        'updatePerformanceMetrics',
        'WeakMap',
        'requestAnimationFrame'
      ];

      performanceFeatures.forEach(feature => {
        if (content.includes(feature)) {
          this.info.push(`✅ Performance feature: ${feature}`);
        } else {
          this.warnings.push(`⚠️  Missing performance feature: ${feature}`);
        }
      });

      // Check for memory optimization
      if (content.includes('WeakMap') || content.includes('WeakSet')) {
        this.info.push('✅ Memory optimization implemented');
      } else {
        this.warnings.push('⚠️  Memory optimization missing');
      }

    } else {
      this.errors.push('❌ Enterprise content script missing');
      performanceValid = false;
    }

    this.validationResults.performance = performanceValid;
  }

  /**
   * Validate compliance features
   */
  async validateCompliance() {
    console.log('📊 Validating Compliance Features...');
    
    let complianceValid = true;

    if (this.fileExists('libs/enterprise-security.js')) {
      const content = this.readFile('libs/enterprise-security.js');
      
      const complianceFeatures = [
        'ComplianceManager',
        'DOT',
        'FMCSA',
        'checkComplianceRequirements',
        'validateProcessing'
      ];

      complianceFeatures.forEach(feature => {
        if (content.includes(feature)) {
          this.info.push(`✅ Compliance feature: ${feature}`);
        } else {
          this.warnings.push(`⚠️  Missing compliance feature: ${feature}`);
        }
      });

    }

    this.validationResults.compliance = complianceValid;
  }

  /**
   * Validate dependencies
   */
  async validateDependencies() {
    console.log('📦 Validating Dependencies...');
    
    try {
      const packageContent = fs.readFileSync('package.json', 'utf8');
      const packageJson = JSON.parse(packageContent);

      // Check enterprise dependencies
      const enterpriseDeps = [
        'chart.js',
        'tensorflow',
        'crypto-js',
        'ml-matrix',
        'd3'
      ];

      if (packageJson.dependencies) {
        enterpriseDeps.forEach(dep => {
          if (packageJson.dependencies[dep]) {
            this.info.push(`✅ Enterprise dependency: ${dep}`);
          } else {
            this.warnings.push(`⚠️  Missing enterprise dependency: ${dep}`);
          }
        });
      }

      // Check version
      if (packageJson.version === '4.0.0') {
        this.info.push('✅ Package version 4.0.0');
      } else {
        this.warnings.push(`⚠️  Package version mismatch: ${packageJson.version}`);
      }

      this.validationResults.dependencies = true;

    } catch (error) {
      this.errors.push(`❌ Package.json validation error: ${error.message}`);
    }
  }

  /**
   * Validate configuration files
   */
  async validateConfiguration() {
    console.log('⚙️  Validating Configuration...');
    
    // Check popup files
    const popupFiles = ['popup/popup.html', 'popup/popup.js'];
    popupFiles.forEach(file => {
      if (this.fileExists(file)) {
        this.info.push(`✅ Popup file: ${file}`);
      } else {
        this.warnings.push(`⚠️  Missing popup file: ${file}`);
      }
    });

    // Check options files
    const optionsFiles = ['options/options.html', 'options/options.js'];
    optionsFiles.forEach(file => {
      if (this.fileExists(file)) {
        this.info.push(`✅ Options file: ${file}`);
      } else {
        this.warnings.push(`⚠️  Missing options file: ${file}`);
      }
    });

    // Check icon files
    const iconFiles = ['icons/icon-16.png', 'icons/icon-32.png', 'icons/icon-48.png', 'icons/icon-128.png'];
    iconFiles.forEach(file => {
      if (this.fileExists(file)) {
        this.info.push(`✅ Icon file: ${file}`);
      } else {
        this.warnings.push(`⚠️  Missing icon file: ${file}`);
      }
    });
  }

  /**
   * Validate file content for enterprise features
   */
  validateFileContent(filePath) {
    try {
      const content = this.readFile(filePath);
      
      // Check for enterprise patterns
      if (content.includes('Enterprise') && content.includes('4.0.0')) {
        // File contains enterprise markers
      } else {
        this.warnings.push(`⚠️  ${filePath} may not be enterprise-ready`);
      }

      // Check for modern JavaScript
      if (content.includes('class ') && content.includes('async ')) {
        // Modern ES6+ syntax
      } else {
        this.warnings.push(`⚠️  ${filePath} may use outdated JavaScript`);
      }

    } catch (error) {
      this.warnings.push(`⚠️  Could not validate content of ${filePath}`);
    }
  }

  /**
   * Generate comprehensive validation report
   */
  generateValidationReport() {
    console.log('\n📊 Enterprise Validation Report');
    console.log('================================================================================');
    
    // Overall status
    const overallValid = Object.values(this.validationResults).every(result => result);
    
    if (overallValid && this.errors.length === 0) {
      console.log('🎉 ENTERPRISE VALIDATION PASSED - Ready for production deployment!');
    } else if (this.errors.length === 0) {
      console.log('✅ VALIDATION PASSED - Minor warnings present');
    } else {
      console.log('❌ VALIDATION FAILED - Critical errors must be resolved');
    }

    // Validation results summary
    console.log('\n🔍 Validation Results:');
    Object.entries(this.validationResults).forEach(([category, result]) => {
      const status = result ? '✅' : '❌';
      const categoryName = category.replace(/([A-Z])/g, ' $1').toLowerCase();
      console.log(`   ${status} ${categoryName}`);
    });

    // Error summary
    if (this.errors.length > 0) {
      console.log('\n❌ Critical Errors:');
      this.errors.forEach(error => console.log(`   ${error}`));
    }

    // Warning summary
    if (this.warnings.length > 0) {
      console.log('\n⚠️  Warnings:');
      this.warnings.forEach(warning => console.log(`   ${warning}`));
    }

    // Success summary
    if (this.info.length > 0) {
      console.log('\n✅ Validated Features:');
      this.info.slice(0, 10).forEach(info => console.log(`   ${info}`));
      if (this.info.length > 10) {
        console.log(`   ... and ${this.info.length - 10} more features`);
      }
    }

    // Enterprise features summary
    console.log('\n🏢 Enterprise Features Status:');
    console.log('   🧠 Advanced AI Analytics: ' + (this.validationResults.enterpriseFiles ? 'Ready' : 'Needs attention'));
    console.log('   📊 Real-time Dashboard: ' + (this.validationResults.enterpriseFiles ? 'Ready' : 'Needs attention'));
    console.log('   🛡️  Enterprise Security: ' + (this.validationResults.security ? 'Ready' : 'Needs attention'));
    console.log('   ⚡ Performance Optimization: ' + (this.validationResults.performance ? 'Ready' : 'Needs attention'));
    console.log('   📋 Compliance Framework: ' + (this.validationResults.compliance ? 'Ready' : 'Needs attention'));

    // Installation instructions
    console.log('\n🚀 Next Steps:');
    if (overallValid && this.errors.length === 0) {
      console.log('   1. Open Firefox and navigate to about:debugging');
      console.log('   2. Click "This Firefox" and "Load Temporary Add-on"');
      console.log('   3. Select the manifest.json file');
      console.log('   4. Navigate to https://one.dat.com/search-loads');
      console.log('   5. Experience enterprise-grade load analysis!');
    } else {
      console.log('   1. Resolve critical errors listed above');
      console.log('   2. Address warnings for optimal performance');
      console.log('   3. Re-run validation: npm run validate');
      console.log('   4. Deploy after successful validation');
    }

    console.log('\n================================================================================');
    console.log('🏢 DAT Ultimate Load Analyzer Enterprise v4.0.0 - Validation Complete');
    console.log('================================================================================\n');
  }

  /**
   * Utility methods
   */
  fileExists(filePath) {
    try {
      return fs.existsSync(filePath) && fs.statSync(filePath).isFile();
    } catch {
      return false;
    }
  }

  directoryExists(dirPath) {
    try {
      return fs.existsSync(dirPath) && fs.statSync(dirPath).isDirectory();
    } catch {
      return false;
    }
  }

  readFile(filePath) {
    try {
      return fs.readFileSync(filePath, 'utf8');
    } catch {
      return '';
    }
  }
}

// Run enterprise validation
const validator = new EnterpriseValidator();
validator.validate();
