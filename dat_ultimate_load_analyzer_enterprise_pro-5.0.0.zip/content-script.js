/**
 * DAT Ultimate Load Analyzer - Main Content Script
 * High-performance freight load analysis for Firefox
 */

// Main application class
class DATUltimateAnalyzer {
  constructor() {
    this.isInitialized = false;
    this.loadDetector = null;
    this.analyticsEngine = null;
    this.uiEnhancer = null;
    this.config = null;
    this.stats = {
      totalLoads: 0,
      bestDeals: 0,
      avgScore: 0,
      scanRate: 0,
      lastScanTime: Date.now()
    };
    this.scanInterval = null;
    this.performanceMonitor = {
      startTime: Date.now(),
      scanCount: 0,
      lastScanCount: 0
    };
  }

  // Initialize the analyzer
  async initialize() {
    if (this.isInitialized) {
      console.log('⚠️ DATUltimateAnalyzer: Already initialized');
      return;
    }

    console.log('🚀 DATUltimateAnalyzer: Starting initialization');
    
    try {
      // Wait for page to be ready
      await this.waitForPageReady();
      
      // Get configuration from background script
      await this.loadConfiguration();
      
      // Initialize components
      this.initializeComponents();
      
      // Setup message listeners
      this.setupMessageListeners();
      
      // Start scanning
      this.startScanning();
      
      // Setup performance monitoring
      this.setupPerformanceMonitoring();
      
      this.isInitialized = true;
      console.log('✅ DATUltimateAnalyzer: Initialization complete');
      
      // Notify background script
      chrome.runtime.sendMessage({
        type: 'ANALYZER_READY',
        data: { timestamp: Date.now(), url: window.location.href }
      });
      
    } catch (error) {
      console.error('❌ DATUltimateAnalyzer: Initialization failed:', error);
    }
  }

  // Wait for page to be ready
  waitForPageReady() {
    return new Promise((resolve) => {
      if (document.readyState === 'complete') {
        resolve();
      } else {
        const checkReady = () => {
          if (document.readyState === 'complete') {
            resolve();
          } else {
            setTimeout(checkReady, 100);
          }
        };
        checkReady();
      }
    });
  }

  // Load configuration from background script
  async loadConfiguration() {
    try {
      const response = await chrome.runtime.sendMessage({ type: 'GET_CONFIG' });
      this.config = response.config || {
        minRatePerMile: 1.80,
        maxDeadhead: 150,
        minTotalRate: 2000,
        maxTotalRate: 15000,
        scoringMode: 'advanced'
      };
      console.log('📋 Configuration loaded:', this.config);
    } catch (error) {
      console.error('Configuration loading failed:', error);
      // Use default configuration
      this.config = {
        minRatePerMile: 1.80,
        maxDeadhead: 150,
        minTotalRate: 2000,
        maxTotalRate: 15000,
        scoringMode: 'advanced'
      };
    }
  }

  // Initialize all components
  initializeComponents() {
    console.log('🔧 Initializing components...');
    
    // Initialize analytics engine
    this.analyticsEngine = new AdvancedAnalyticsEngine();
    console.log('✅ Analytics engine initialized');
    
    // Initialize UI enhancer
    this.uiEnhancer = new UIEnhancer();
    this.uiEnhancer.initialize();
    console.log('✅ UI enhancer initialized');
    
    // Initialize load detector
    this.loadDetector = new LoadDetector();
    this.loadDetector.onLoadDetected((loadData) => {
      this.processDetectedLoad(loadData);
    });
    this.loadDetector.initialize();
    console.log('✅ Load detector initialized');
  }

  // Setup message listeners
  setupMessageListeners() {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      switch (message.type) {
        case 'CONFIG_UPDATED':
          this.handleConfigUpdate(message.config);
          sendResponse({ success: true });
          break;
          
        case 'PING':
          sendResponse({ status: 'ready', initialized: this.isInitialized });
          break;
          
        case 'ANALYZE_SELECTION':
          this.analyzeSelection(message.text);
          sendResponse({ success: true });
          break;
          
        case 'GET_STATS':
          sendResponse({ stats: this.stats });
          break;
          
        case 'FORCE_SCAN':
          this.performForcedScan();
          sendResponse({ success: true });
          break;
      }
    });
  }

  // Handle configuration updates
  handleConfigUpdate(newConfig) {
    console.log('🔄 Configuration updated:', newConfig);
    this.config = { ...this.config, ...newConfig };
    
    // Reprocess all current loads with new configuration
    this.reprocessAllLoads();
  }

  // Process a detected load
  async processDetectedLoad(loadData) {
    try {
      performance.mark('load-processing-start');
      
      // Perform analytics
      const analytics = this.analyticsEngine.analyzeLoad(loadData, this.config);
      
      // Check if load meets criteria
      const meetsRequirements = this.checkLoadRequirements(loadData, analytics);
      
      if (meetsRequirements) {
        // Enhance the UI element
        this.uiEnhancer.enhanceLoad(loadData, analytics);
        
        // Update statistics
        this.updateStatistics(loadData, analytics);
        
        // Notify background script of valuable load
        if (analytics.score >= 90) {
          chrome.runtime.sendMessage({
            type: 'LOAD_DETECTED',
            data: { loadData, analytics, timestamp: Date.now() }
          });
        }
        
        console.log(`🎯 High-value load processed: ${analytics.tier} (${analytics.score}%) - $${loadData.ratePerMileValue}/mi`);
      }
      
      performance.mark('load-processing-end');
      performance.measure('load-processing', 'load-processing-start', 'load-processing-end');
      
    } catch (error) {
      console.error('Load processing error:', error);
    }
  }

  // Check if load meets requirements
  checkLoadRequirements(loadData, analytics) {
    // Basic filters
    if (loadData.ratePerMileValue < this.config.minRatePerMile) return false;
    if (loadData.deadhead > this.config.maxDeadhead) return false;
    if (loadData.rateValue < this.config.minTotalRate) return false;
    if (loadData.rateValue > this.config.maxTotalRate) return false;
    
    // Score-based filter
    if (analytics.score < 60) return false;
    
    return true;
  }

  // Update statistics
  updateStatistics(loadData, analytics) {
    this.stats.totalLoads++;
    
    if (analytics.score >= 80) {
      this.stats.bestDeals++;
    }
    
    // Update running average score
    this.stats.avgScore = (this.stats.avgScore * (this.stats.totalLoads - 1) + analytics.score) / this.stats.totalLoads;
    
    // Update UI stats
    this.uiEnhancer.updateStats(this.stats);
    
    // Send stats to background
    chrome.runtime.sendMessage({
      type: 'UPDATE_STATS',
      data: this.stats
    });
  }

  // Start scanning process
  startScanning() {
    console.log('🔍 Starting continuous scanning...');
    
    // Perform initial scan
    this.performScan();
    
    // Set up interval scanning
    this.scanInterval = setInterval(() => {
      this.performScan();
    }, 2000); // Scan every 2 seconds
  }

  // Perform a scan
  performScan() {
    try {
      const scanStart = performance.now();
      this.performanceMonitor.scanCount++;
      
      // Trigger load detection
      if (this.loadDetector) {
        this.loadDetector.scanForLoads(document.body);
      }
      
      const scanEnd = performance.now();
      const scanTime = scanEnd - scanStart;
      
      if (scanTime > 50) { // Log slow scans
        console.warn(`⚠️ Slow scan detected: ${scanTime.toFixed(2)}ms`);
      }
      
    } catch (error) {
      console.error('Scan error:', error);
    }
  }

  // Perform forced scan
  performForcedScan() {
    console.log('🔍 Performing forced scan...');
    this.performScan();
  }

  // Reprocess all current loads
  reprocessAllLoads() {
    console.log('🔄 Reprocessing all loads with new configuration...');
    
    // Clear current enhancements
    this.uiEnhancer.clearFilters();
    
    // Reset stats
    this.stats = {
      totalLoads: 0,
      bestDeals: 0,
      avgScore: 0,
      scanRate: 0,
      lastScanTime: Date.now()
    };
    
    // Perform fresh scan
    setTimeout(() => {
      this.performForcedScan();
    }, 500);
  }

  // Analyze selected text
  analyzeSelection(selectedText) {
    console.log('🔍 Analyzing selected text:', selectedText);
    
    try {
      // Extract patterns from selected text
      const patterns = this.extractPatternsFromText(selectedText);
      
      if (patterns.hasRate) {
        const mockLoadData = {
          element: null,
          source: 'SELECTION',
          rateValue: patterns.rateValue,
          ratePerMileValue: patterns.ratePerMileValue,
          deadhead: patterns.deadhead
        };
        
        const analytics = this.analyticsEngine.analyzeLoad(mockLoadData, this.config);
        
        // Show analysis in console or notification
        console.log('📊 Selection Analysis:', {
          score: analytics.score,
          tier: analytics.tier,
          recommendation: analytics.recommendation
        });
        
        // Could show a popup with results
        alert(`Load Analysis:\nScore: ${analytics.score}%\nTier: ${analytics.tier}\nRecommendation: ${analytics.recommendation}`);
      }
    } catch (error) {
      console.error('Selection analysis error:', error);
    }
  }

  // Extract patterns from text (helper method)
  extractPatternsFromText(text) {
    const patterns = {
      hasRate: false,
      hasDeadhead: false,
      rateValue: 0,
      ratePerMileValue: 0,
      deadhead: 0
    };
    
    // Money pattern
    const moneyMatches = text.match(/\$[\d,]+(?:\.\d{2})?/g);
    if (moneyMatches) {
      patterns.hasRate = true;
      patterns.rateValue = parseFloat(moneyMatches[0].replace(/[$,]/g, ''));
    }
    
    // Rate per mile pattern
    const rpmMatch = text.match(/\$(\d+\.?\d*)\s*(?:\/mi|per mile)/i);
    if (rpmMatch) {
      patterns.ratePerMileValue = parseFloat(rpmMatch[1]);
    }
    
    // Deadhead pattern
    const dhMatch = text.match(/(?:DH[:\s]*|deadhead[:\s]*)(\d+)|(\d+)\s*(?:DH|mi\s*DH)/i);
    if (dhMatch) {
      patterns.hasDeadhead = true;
      patterns.deadhead = parseInt(dhMatch[1] || dhMatch[2]);
    }
    
    return patterns;
  }

  // Setup performance monitoring
  setupPerformanceMonitoring() {
    // Monitor scan rate
    setInterval(() => {
      const currentTime = Date.now();
      const timeDiff = (currentTime - this.performanceMonitor.startTime) / 1000;
      const scanDiff = this.performanceMonitor.scanCount - this.performanceMonitor.lastScanCount;
      
      this.stats.scanRate = Math.round(scanDiff / Math.max(1, timeDiff));
      this.performanceMonitor.lastScanCount = this.performanceMonitor.scanCount;
      this.performanceMonitor.startTime = currentTime;
      
      // Update UI
      this.uiEnhancer.updateStats(this.stats);
      
    }, 5000); // Update every 5 seconds
    
    // Monitor memory usage
    if (performance.memory) {
      setInterval(() => {
        const memoryMB = Math.round(performance.memory.usedJSHeapSize / 1024 / 1024);
        if (memoryMB > 100) { // Alert if memory usage is high
          console.warn(`⚠️ High memory usage: ${memoryMB}MB`);
        }
      }, 30000); // Check every 30 seconds
    }
  }

  // Cleanup and destroy
  destroy() {
    console.log('🔄 Destroying DATUltimateAnalyzer...');
    
    if (this.scanInterval) {
      clearInterval(this.scanInterval);
      this.scanInterval = null;
    }
    
    if (this.loadDetector) {
      this.loadDetector.destroy();
      this.loadDetector = null;
    }
    
    if (this.uiEnhancer) {
      this.uiEnhancer.destroy();
      this.uiEnhancer = null;
    }
    
    this.isInitialized = false;
    console.log('✅ DATUltimateAnalyzer destroyed');
  }
}

// Global instance
let datAnalyzer = null;

// Initialize when page loads
function initializeAnalyzer() {
  // Check if we're on a DAT One load search page
  if (!window.location.href.includes('one.dat.com/search-loads')) {
    console.log('ℹ️ Not on DAT One load search page, skipping initialization');
    return;
  }
  
  // Prevent multiple initializations
  if (datAnalyzer && datAnalyzer.isInitialized) {
    console.log('ℹ️ Analyzer already initialized');
    return;
  }
  
  // Create and initialize analyzer
  datAnalyzer = new DATUltimateAnalyzer();
  datAnalyzer.initialize();
}

// Handle page navigation
let lastUrl = window.location.href;
function handleNavigation() {
  const currentUrl = window.location.href;
  if (currentUrl !== lastUrl) {
    lastUrl = currentUrl;
    console.log('🔄 Page navigation detected:', currentUrl);
    
    // Destroy existing analyzer if it exists
    if (datAnalyzer) {
      datAnalyzer.destroy();
      datAnalyzer = null;
    }
    
    // Reinitialize if on DAT page
    setTimeout(() => {
      initializeAnalyzer();
    }, 1000);
  }
}

// Watch for navigation changes
setInterval(handleNavigation, 1000);

// Initialize on page load
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initializeAnalyzer);
} else {
  // Page already loaded
  setTimeout(initializeAnalyzer, 1000);
}

// Handle page unload
window.addEventListener('beforeunload', () => {
  if (datAnalyzer) {
    datAnalyzer.destroy();
  }
});

console.log('🚀 DAT Ultimate Load Analyzer content script loaded');
