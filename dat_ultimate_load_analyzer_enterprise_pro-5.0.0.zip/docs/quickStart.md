# Quick Start Guide

## Get Started in 5 Minutes

1. Install the extension in Firefox
2. Navigate to DAT One
3. Watch loads get analyzed automatically
4. Use Ctrl+Shift+D for dashboard
5. Export reports with Ctrl+Shift+E

## Key Features
- AI-powered load scoring
- Real-time market analysis  
- Enterprise security
- Compliance tracking
- Performance optimization
