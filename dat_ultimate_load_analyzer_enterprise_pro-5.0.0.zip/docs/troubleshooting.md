# Troubleshooting Guide

## Node.js Requirements - IMPORTANT! 🚨

### For End Users (Installing Extension)
**❌ NO Node.js required!**
- Users only need Firefox browser
- Extension runs entirely in browser
- All code is bundled and self-contained
- No additional installations needed

### For Developers (Building/Modifying Extension)
**✅ Node.js required!**
- Node.js 16+ needed for development
- npm packages required for building
- Run `npm install` to get dependencies
- Use `npm run package` to build extension

### Distribution Options
1. **Firefox Add-ons Store** - Users install directly, no Node.js needed
2. **Manual Installation** - Provide built .zip file, no Node.js needed
3. **Development Mode** - Only for developers, Node.js required

## Common Issues

### Extension Not Loading
- Check Firefox version (100+)
- Verify manifest.json selected
- Restart Firefox
- Ensure extension is properly built (developers: run `npm run package`)

### Node.js/npm Errors (Developers Only)
- Install Node.js 16+ from nodejs.org
- Run `npm install` in project directory
- Check for permission issues
- Clear npm cache: `npm cache clean --force`

### Performance Issues
- Close unnecessary tabs
- Check memory usage
- Restart browser
- Disable conflicting extensions

### Feature Problems
- Refresh DAT One page
- Check browser console (F12)
- Verify configuration in extension popup
- Clear browser cache and cookies

### Extension Build Process (For Developers)
```bash
# 1. Install Node.js dependencies
npm install

# 2. Build extension for distribution
npm run package

# 3. Result: dist/dat-ultimate-load-analyzer-enterprise-pro-5.0.0.zip
# This .zip file is what users install - no Node.js needed for them!
```

### Manual Installation Instructions (For Users)
1. Download the .zip file from developer
2. Open Firefox → Add-ons → Extensions
3. Click gear icon → "Install Add-on From File"
4. Select the .zip file
5. Extension installs automatically - **No Node.js required!**

## Support
- Email: enterprise@datanalyzer.com
- Phone: 1-800-DAT-ENTERPRISE
- Documentation: docs.datanalyzer.com
