"""
DAT Load Analyzer - Streamlit Dashboard
Live dashboard for monitoring and managing DAT loads
"""
import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
import time
import sys
import os

# Add project root to Python path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    from scraper.rates import RateAnalyzer
    from scraper.monitor import LiveMonitor
    from email.gmail import GmailAutomation
    from alerts.notify import DealNotifier
    import sqlite3
    import yaml
except ImportError as e:
    st.error(f"Missing dependencies: {e}")
    st.error("Please run: pip install -r requirements.txt")
    st.stop()

# Page configuration
st.set_page_config(
    page_title="DAT Load Analyzer",
    page_icon="🚛",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for better styling
st.markdown("""
<style>
    .metric-card {
        background-color: #f0f2f6;
        padding: 1rem;
        border-radius: 0.5rem;
        border-left: 4px solid #ff6b6b;
    }
    .profit-score-high { color: #28a745; font-weight: bold; }
    .profit-score-medium { color: #ffc107; font-weight: bold; }
    .profit-score-low { color: #dc3545; font-weight: bold; }
    .load-card {
        border: 1px solid #ddd;
        border-radius: 8px;
        padding: 1rem;
        margin: 0.5rem 0;
        background-color: white;
    }
</style>
""", unsafe_allow_html=True)

@st.cache_data
def load_config():
    """Load configuration"""
    try:
        with open('config.yaml', 'r') as file:
            return yaml.safe_load(file)
    except Exception as e:
        st.error(f"Error loading config: {e}")
        return {}

@st.cache_data(ttl=60)  # Cache for 1 minute
def get_loads_from_db(limit=100):
    """Get loads from database"""
    try:
        conn = sqlite3.connect('data/loads.db')
        query = """
            SELECT load_id, origin, destination, pickup_date, delivery_date,
                   equipment_type, rate, miles, rate_per_mile, broker_name,
                   broker_email, broker_phone, special_requirements,
                   posted_date, scraped_at, profit_score
            FROM loads
            ORDER BY scraped_at DESC
            LIMIT ?
        """
        df = pd.read_sql_query(query, conn, params=[limit])
        conn.close()
        return df
    except Exception as e:
        st.error(f"Error loading loads: {e}")
        return pd.DataFrame()

@st.cache_data(ttl=300)  # Cache for 5 minutes
def get_alert_history(limit=50):
    """Get alert history"""
    try:
        conn = sqlite3.connect('data/loads.db')
        query = """
            SELECT a.*, l.origin, l.destination, l.rate, l.miles
            FROM alerts a
            LEFT JOIN loads l ON a.load_id = l.load_id
            ORDER BY a.sent_at DESC
            LIMIT ?
        """
        df = pd.read_sql_query(query, conn, params=[limit])
        conn.close()
        return df
    except Exception as e:
        st.error(f"Error loading alerts: {e}")
        return pd.DataFrame()

def format_profit_score(score):
    """Format profit score with color"""
    if score >= 8:
        return f'<span class="profit-score-high">{score:.1f}/10</span>'
    elif score >= 6:
        return f'<span class="profit-score-medium">{score:.1f}/10</span>'
    else:
        return f'<span class="profit-score-low">{score:.1f}/10</span>'

def main():
    # Header
    st.title("🚛 DAT Load Analyzer Dashboard")
    st.markdown("Real-time load monitoring and analysis from DAT.com")
    
    # Initialize session state
    if 'monitor' not in st.session_state:
        st.session_state.monitor = None
    if 'gmail' not in st.session_state:
        st.session_state.gmail = None
    
    # Sidebar
    st.sidebar.header("🔧 Control Panel")
    
    # Load configuration
    config = load_config()
    
    # Live Monitoring Controls
    st.sidebar.subheader("📡 Live Monitoring")
    
    col1, col2 = st.sidebar.columns(2)
    
    with col1:
        if st.button("▶️ Start Monitor", type="primary"):
            try:
                if st.session_state.monitor is None:
                    st.session_state.monitor = LiveMonitor()
                
                if st.session_state.monitor.start_monitoring():
                    st.success("✅ Monitoring started!")
                else:
                    st.error("❌ Failed to start monitoring")
            except Exception as e:
                st.error(f"Error: {e}")
    
    with col2:
        if st.button("⏹️ Stop Monitor"):
            try:
                if st.session_state.monitor:
                    st.session_state.monitor.stop_monitoring()
                    st.success("✅ Monitoring stopped!")
                else:
                    st.warning("⚠️ Monitor not running")
            except Exception as e:
                st.error(f"Error: {e}")
    
    # Monitor status
    if st.session_state.monitor:
        status = st.session_state.monitor.get_monitoring_status()
        if status['is_monitoring']:
            st.sidebar.success("🟢 Live monitoring active")
            if status['last_scan_time']:
                last_scan = datetime.fromisoformat(status['last_scan_time'])
                st.sidebar.info(f"Last scan: {last_scan.strftime('%H:%M:%S')}")
        else:
            st.sidebar.warning("🔴 Monitoring inactive")
    
    # Quick Actions
    st.sidebar.subheader("⚡ Quick Actions")
    
    if st.sidebar.button("🔄 Force Scan"):
        try:
            if st.session_state.monitor and st.session_state.monitor.is_monitoring:
                new_loads = st.session_state.monitor.force_scan()
                st.sidebar.success(f"✅ Found {new_loads} new loads")
            else:
                st.sidebar.error("❌ Start monitoring first")
        except Exception as e:
            st.sidebar.error(f"Error: {e}")
    
    if st.sidebar.button("📧 Test Gmail"):
        try:
            if st.session_state.gmail is None:
                st.session_state.gmail = GmailAutomation()
            
            # Test with sample data
            sample_load = {
                'load_id': 'TEST001',
                'origin': 'Chicago, IL',
                'destination': 'Atlanta, GA',
                'rate': 2500,
                'miles': 1000,
                'broker_email': 'test@example.com'
            }
            
            preview = st.session_state.gmail.preview_email('load_inquiry', sample_load)
            st.sidebar.success("✅ Gmail connection OK")
            
        except Exception as e:
            st.sidebar.error(f"Gmail error: {e}")
    
    # Main content
    tab1, tab2, tab3, tab4 = st.tabs(["📊 Dashboard", "📋 Load List", "🔔 Alerts", "📈 Analytics"])
    
    with tab1:
        # Dashboard Overview
        st.header("📊 Live Dashboard")
        
        # Load data
        df_loads = get_loads_from_db(200)
        
        if not df_loads.empty:
            # Key metrics
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                total_loads = len(df_loads)
                st.metric("🚛 Total Loads", total_loads)
            
            with col2:
                profitable_loads = len(df_loads[df_loads['profit_score'] >= 7.0])
                st.metric("💰 Profitable Loads", profitable_loads)
            
            with col3:
                avg_rate = df_loads['rate'].mean() if 'rate' in df_loads.columns else 0
                st.metric("💵 Avg Rate", f"${avg_rate:,.0f}")
            
            with col4:
                avg_score = df_loads['profit_score'].mean() if 'profit_score' in df_loads.columns else 0
                st.metric("⭐ Avg Score", f"{avg_score:.1f}/10")
            
            # Recent activity chart
            st.subheader("📈 Recent Load Activity")
            
            # Convert scraped_at to datetime if it exists
            if 'scraped_at' in df_loads.columns:
                df_loads['scraped_at'] = pd.to_datetime(df_loads['scraped_at'])
                
                # Group by hour for the chart
                hourly_loads = df_loads.groupby(df_loads['scraped_at'].dt.floor('H')).size().reset_index()
                hourly_loads.columns = ['Hour', 'Count']
                
                fig = px.line(hourly_loads, x='Hour', y='Count', 
                             title="Loads Scraped per Hour",
                             labels={'Count': 'Number of Loads'})
                st.plotly_chart(fig, use_container_width=True)
            
            # Top profitable loads
            st.subheader("🏆 Top Profitable Loads")
            
            top_loads = df_loads.nlargest(5, 'profit_score') if 'profit_score' in df_loads.columns else df_loads.head(5)
            
            for idx, load in top_loads.iterrows():
                with st.container():
                    col1, col2, col3, col4 = st.columns([3, 2, 2, 1])
                    
                    with col1:
                        st.write(f"**{load.get('origin', 'N/A')} → {load.get('destination', 'N/A')}**")
                        st.write(f"Broker: {load.get('broker_name', 'N/A')}")
                    
                    with col2:
                        st.write(f"Rate: ${load.get('rate', 0):,.0f}")
                        st.write(f"Miles: {load.get('miles', 0):,}")
                    
                    with col3:
                        st.write(f"Rate/Mile: ${load.get('rate_per_mile', 0):.2f}")
                        score = load.get('profit_score', 0)
                        st.markdown(f"Score: {format_profit_score(score)}", unsafe_allow_html=True)
                    
                    with col4:
                        if st.button(f"📧", key=f"email_{idx}"):
                            # Email button logic would go here
                            st.info("Email feature coming soon!")
                    
                    st.divider()
        
        else:
            st.info("🔍 No loads found. Start monitoring to see live data!")
            st.markdown("""
            **Getting Started:**
            1. Configure your DAT.com credentials in `config.yaml`
            2. Click "Start Monitor" in the sidebar
            3. Watch as loads appear in real-time!
            """)
    
    with tab2:
        # Load List
        st.header("📋 All Loads")
        
        df_loads = get_loads_from_db(500)
        
        if not df_loads.empty:
            # Filters
            col1, col2, col3 = st.columns(3)
            
            with col1:
                min_score = st.slider("Min Profit Score", 0.0, 10.0, 0.0, 0.1)
            
            with col2:
                equipment_filter = st.selectbox("Equipment Type", 
                                               ['All'] + list(df_loads['equipment_type'].dropna().unique()))
            
            with col3:
                min_rate = st.number_input("Min Rate ($)", 0, 10000, 0, 100)
            
            # Apply filters
            filtered_df = df_loads.copy()
            
            if 'profit_score' in filtered_df.columns:
                filtered_df = filtered_df[filtered_df['profit_score'] >= min_score]
            
            if equipment_filter != 'All':
                filtered_df = filtered_df[filtered_df['equipment_type'] == equipment_filter]
            
            if 'rate' in filtered_df.columns:
                filtered_df = filtered_df[filtered_df['rate'] >= min_rate]
            
            st.write(f"Showing {len(filtered_df)} loads")
            
            # Display loads table
            if not filtered_df.empty:
                # Format the dataframe for display
                display_df = filtered_df[['origin', 'destination', 'rate', 'miles', 
                                        'rate_per_mile', 'profit_score', 'broker_name']].copy()
                
                display_df['rate'] = display_df['rate'].apply(lambda x: f"${x:,.0f}")
                display_df['miles'] = display_df['miles'].apply(lambda x: f"{x:,}")
                display_df['rate_per_mile'] = display_df['rate_per_mile'].apply(lambda x: f"${x:.2f}")
                display_df['profit_score'] = display_df['profit_score'].apply(lambda x: f"{x:.1f}/10")
                
                st.dataframe(display_df, use_container_width=True)
            else:
                st.info("No loads match the current filters.")
        
        else:
            st.info("No loads available. Start monitoring to see data!")
    
    with tab3:
        # Alerts
        st.header("🔔 Alert History")
        
        df_alerts = get_alert_history(100)
        
        if not df_alerts.empty:
            # Alert summary
            col1, col2, col3 = st.columns(3)
            
            with col1:
                total_alerts = len(df_alerts)
                st.metric("📢 Total Alerts", total_alerts)
            
            with col2:
                today_alerts = len(df_alerts[df_alerts['sent_at'].str.contains(datetime.now().strftime('%Y-%m-%d'))])
                st.metric("📅 Today's Alerts", today_alerts)
            
            with col3:
                avg_alert_score = df_alerts['profit_score'].mean()
                st.metric("⭐ Avg Alert Score", f"{avg_alert_score:.1f}/10")
            
            # Recent alerts
            st.subheader("🕐 Recent Alerts")
            
            for idx, alert in df_alerts.head(10).iterrows():
                with st.container():
                    col1, col2, col3 = st.columns([2, 2, 1])
                    
                    with col1:
                        st.write(f"**{alert.get('origin', 'N/A')} → {alert.get('destination', 'N/A')}**")
                        st.write(f"Alert Type: {alert.get('alert_type', 'N/A').title()}")
                    
                    with col2:
                        st.write(f"Score: {alert.get('profit_score', 0):.1f}/10")
                        st.write(f"Sent: {alert.get('sent_at', 'N/A')}")
                    
                    with col3:
                        if st.button(f"View Load", key=f"view_{idx}"):
                            st.info("Load details coming soon!")
                    
                    st.divider()
        
        else:
            st.info("No alerts yet. Alerts will appear here when profitable loads are found!")
    
    with tab4:
        # Analytics
        st.header("📈 Analytics")
        
        df_loads = get_loads_from_db(1000)
        
        if not df_loads.empty and len(df_loads) > 10:
            # Rate distribution
            col1, col2 = st.columns(2)
            
            with col1:
                if 'rate_per_mile' in df_loads.columns:
                    fig = px.histogram(df_loads, x='rate_per_mile', nbins=20,
                                     title="Rate per Mile Distribution")
                    st.plotly_chart(fig, use_container_width=True)
            
            with col2:
                if 'profit_score' in df_loads.columns:
                    fig = px.histogram(df_loads, x='profit_score', nbins=10,
                                     title="Profit Score Distribution")
                    st.plotly_chart(fig, use_container_width=True)
            
            # Equipment type analysis
            if 'equipment_type' in df_loads.columns:
                equipment_stats = df_loads.groupby('equipment_type').agg({
                    'rate': 'mean',
                    'rate_per_mile': 'mean',
                    'profit_score': 'mean'
                }).round(2)
                
                st.subheader("📊 Equipment Type Analysis")
                st.dataframe(equipment_stats, use_container_width=True)
            
            # Market trends
            if 'scraped_at' in df_loads.columns:
                df_loads['scraped_at'] = pd.to_datetime(df_loads['scraped_at'])
                daily_avg = df_loads.groupby(df_loads['scraped_at'].dt.date).agg({
                    'rate_per_mile': 'mean',
                    'profit_score': 'mean'
                }).reset_index()
                
                st.subheader("📈 Market Trends")
                
                fig = px.line(daily_avg, x='scraped_at', y='rate_per_mile',
                             title="Average Rate per Mile Over Time")
                st.plotly_chart(fig, use_container_width=True)
        
        else:
            st.info("Not enough data for analytics. Keep monitoring to build your dataset!")
    
    # Auto-refresh
    if st.session_state.monitor and st.session_state.monitor.is_monitoring:
        time.sleep(30)  # Refresh every 30 seconds when monitoring
        st.rerun()

if __name__ == "__main__":
    main()
