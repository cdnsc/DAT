"""
DAT Load Analyzer - Dashboard Components
Reusable components for the Streamlit dashboard
"""
import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
import sqlite3

def render_load_card(load_data):
    """Render a single load card"""
    with st.container():
        # Load card styling
        card_color = "#e8f5e8" if load_data.get('profit_score', 0) >= 7 else "#fff3cd" if load_data.get('profit_score', 0) >= 5 else "#f8d7da"
        
        st.markdown(f"""
        <div style="border: 2px solid #ddd; border-radius: 10px; padding: 15px; margin: 10px 0; background-color: {card_color};">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <h4 style="margin: 0; color: #333;">🚛 {load_data.get('load_id', 'N/A')}</h4>
                <div style="text-align: right;">
                    <span style="font-size: 1.2em; font-weight: bold; color: #28a745;">${load_data.get('rate', 0):,.0f}</span>
                    <br>
                    <span style="color: #666;">${load_data.get('rate_per_mile', 0):.2f}/mi</span>
                </div>
            </div>
            <hr style="margin: 10px 0;">
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                <div>
                    <strong>📍 Origin:</strong> {load_data.get('origin', 'N/A')}<br>
                    <strong>🎯 Destination:</strong> {load_data.get('destination', 'N/A')}<br>
                    <strong>📏 Miles:</strong> {load_data.get('miles', 0):,}
                </div>
                <div>
                    <strong>📅 Pickup:</strong> {load_data.get('pickup_date', 'N/A')}<br>
                    <strong>🚚 Equipment:</strong> {load_data.get('equipment_type', 'N/A')}<br>
                    <strong>⭐ Score:</strong> {load_data.get('profit_score', 0):.1f}/10
                </div>
            </div>
        </div>
        """, unsafe_allow_html=True)
        
        # Action buttons
        col1, col2, col3 = st.columns(3)
        
        with col1:
            if st.button(f"📧 Contact Broker", key=f"contact_{load_data.get('load_id')}"):
                st.session_state[f"show_email_{load_data.get('load_id')}"] = True
        
        with col2:
            if st.button(f"📊 View Details", key=f"details_{load_data.get('load_id')}"):
                st.session_state[f"show_details_{load_data.get('load_id')}"] = True
        
        with col3:
            if st.button(f"⭐ Mark Favorite", key=f"favorite_{load_data.get('load_id')}"):
                mark_load_favorite(load_data.get('load_id'))
                st.success("Added to favorites!")

def render_performance_metrics():
    """Render performance metrics cards"""
    # Get metrics from database
    try:
        conn = sqlite3.connect('data/loads.db')
        
        # Today's metrics
        today = datetime.now().strftime('%Y-%m-%d')
        
        # Total loads today
        total_loads_query = "SELECT COUNT(*) FROM loads WHERE DATE(scraped_at) = ?"
        total_loads = conn.execute(total_loads_query, [today]).fetchone()[0]
        
        # High-profit loads today
        high_profit_query = "SELECT COUNT(*) FROM loads WHERE DATE(scraped_at) = ? AND profit_score >= 7.0"
        high_profit_loads = conn.execute(high_profit_query, [today]).fetchone()[0]
        
        # Average rate per mile today
        avg_rpm_query = "SELECT AVG(rate_per_mile) FROM loads WHERE DATE(scraped_at) = ?"
        avg_rpm = conn.execute(avg_rpm_query, [today]).fetchone()[0] or 0
        
        # Alerts sent today
        alerts_query = "SELECT COUNT(*) FROM alerts WHERE DATE(sent_at) = ?"
        alerts_sent = conn.execute(alerts_query, [today]).fetchone()[0]
        
        conn.close()
        
        # Display metrics
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric(
                label="📊 Total Loads Today",
                value=total_loads,
                delta=f"Since midnight"
            )
        
        with col2:
            st.metric(
                label="⭐ High-Profit Loads",
                value=high_profit_loads,
                delta=f"{(high_profit_loads/total_loads*100) if total_loads > 0 else 0:.1f}% of total"
            )
        
        with col3:
            st.metric(
                label="💰 Avg Rate/Mile",
                value=f"${avg_rpm:.2f}",
                delta="Today's average"
            )
        
        with col4:
            st.metric(
                label="🔔 Alerts Sent",
                value=alerts_sent,
                delta="Notifications today"
            )
            
    except Exception as e:
        st.error(f"Error loading metrics: {e}")

def render_rate_analysis_chart(df):
    """Render rate analysis chart"""
    if df.empty:
        st.warning("No data available for chart")
        return
    
    # Rate per mile distribution
    fig = px.histogram(
        df, 
        x='rate_per_mile', 
        title='Rate Per Mile Distribution',
        nbins=30,
        color_discrete_sequence=['#ff6b6b']
    )
    fig.update_layout(
        xaxis_title="Rate per Mile ($)",
        yaxis_title="Number of Loads",
        showlegend=False
    )
    st.plotly_chart(fig, use_container_width=True)

def render_profit_score_chart(df):
    """Render profit score distribution chart"""
    if df.empty:
        st.warning("No data available for chart")
        return
    
    # Profit score distribution
    fig = px.box(
        df, 
        y='profit_score',
        title='Profit Score Distribution',
        color_discrete_sequence=['#4ecdc4']
    )
    fig.update_layout(
        yaxis_title="Profit Score (0-10)",
        showlegend=False
    )
    st.plotly_chart(fig, use_container_width=True)

def render_geographic_map(df):
    """Render geographic distribution of loads"""
    if df.empty:
        st.warning("No data available for map")
        return
    
    try:
        # Create a simple scatter plot (would need geocoding for real map)
        # For now, show origin states frequency
        if 'origin' in df.columns:
            # Extract state from origin (assumes format "City, ST")
            df['origin_state'] = df['origin'].str.extract(r', ([A-Z]{2})$')
            state_counts = df['origin_state'].value_counts().head(10)
            
            fig = px.bar(
                x=state_counts.index,
                y=state_counts.values,
                title='Top 10 Origin States',
                labels={'x': 'State', 'y': 'Number of Loads'},
                color_discrete_sequence=['#95e1d3']
            )
            fig.update_layout(showlegend=False)
            st.plotly_chart(fig, use_container_width=True)
            
    except Exception as e:
        st.error(f"Error creating geographic chart: {e}")

def render_time_series_chart(df):
    """Render time series of load postings"""
    if df.empty:
        st.warning("No data available for time series")
        return
    
    try:
        # Convert scraped_at to datetime
        df['scraped_at'] = pd.to_datetime(df['scraped_at'])
        
        # Group by hour
        hourly_counts = df.groupby(df['scraped_at'].dt.floor('H')).size().reset_index()
        hourly_counts.columns = ['hour', 'count']
        
        fig = px.line(
            hourly_counts,
            x='hour',
            y='count',
            title='Load Posting Activity Over Time',
            color_discrete_sequence=['#f38ba8']
        )
        fig.update_layout(
            xaxis_title="Time",
            yaxis_title="Number of Loads",
            showlegend=False
        )
        st.plotly_chart(fig, use_container_width=True)
        
    except Exception as e:
        st.error(f"Error creating time series chart: {e}")

def render_load_filters():
    """Render load filtering controls"""
    st.subheader("🔍 Filter Loads")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        min_rate = st.number_input("Minimum Rate ($)", min_value=0, value=1000, step=100)
        min_rpm = st.number_input("Minimum Rate/Mile ($)", min_value=0.0, value=1.5, step=0.1)
    
    with col2:
        equipment_types = ["Any", "Van", "Reefer", "Flatbed", "Step Deck", "RGN"]
        equipment_filter = st.selectbox("Equipment Type", equipment_types)
        
        origin_state = st.text_input("Origin State (e.g., IL)")
    
    with col3:
        min_score = st.slider("Minimum Profit Score", 0.0, 10.0, 5.0, 0.5)
        
        days_back = st.number_input("Days Back", min_value=1, max_value=30, value=7)
    
    return {
        'min_rate': min_rate,
        'min_rpm': min_rpm,
        'equipment_filter': equipment_filter if equipment_filter != "Any" else None,
        'origin_state': origin_state if origin_state else None,
        'min_score': min_score,
        'days_back': days_back
    }

def apply_load_filters(df, filters):
    """Apply filters to load dataframe"""
    if df.empty:
        return df
    
    filtered_df = df.copy()
    
    # Rate filter
    if filters['min_rate']:
        filtered_df = filtered_df[filtered_df['rate'] >= filters['min_rate']]
    
    # Rate per mile filter
    if filters['min_rpm']:
        filtered_df = filtered_df[filtered_df['rate_per_mile'] >= filters['min_rpm']]
    
    # Equipment filter
    if filters['equipment_filter']:
        filtered_df = filtered_df[filtered_df['equipment_type'].str.contains(filters['equipment_filter'], case=False, na=False)]
    
    # Origin state filter
    if filters['origin_state']:
        filtered_df = filtered_df[filtered_df['origin'].str.contains(filters['origin_state'], case=False, na=False)]
    
    # Profit score filter
    if filters['min_score']:
        filtered_df = filtered_df[filtered_df['profit_score'] >= filters['min_score']]
    
    # Date filter
    if filters['days_back']:
        cutoff_date = datetime.now() - timedelta(days=filters['days_back'])
        filtered_df['scraped_at'] = pd.to_datetime(filtered_df['scraped_at'])
        filtered_df = filtered_df[filtered_df['scraped_at'] >= cutoff_date]
    
    return filtered_df

def render_alert_settings():
    """Render alert configuration settings"""
    st.subheader("🔔 Alert Settings")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.write("**Profit Score Thresholds**")
        high_score = st.slider("High Priority Alert", 7.0, 10.0, 8.0, 0.1)
        medium_score = st.slider("Medium Priority Alert", 5.0, 8.0, 6.5, 0.1)
        
        st.write("**Rate Thresholds**")
        min_alert_rate = st.number_input("Minimum Rate for Alert ($)", min_value=0, value=2000, step=100)
        min_alert_rpm = st.number_input("Minimum RPM for Alert ($)", min_value=0.0, value=2.0, step=0.1)
    
    with col2:
        st.write("**Notification Methods**")
        email_alerts = st.checkbox("Email Alerts", value=True)
        desktop_alerts = st.checkbox("Desktop Notifications", value=True)
        sound_alerts = st.checkbox("Sound Alerts", value=False)
        
        st.write("**Alert Frequency**")
        alert_cooldown = st.number_input("Alert Cooldown (minutes)", min_value=1, max_value=60, value=5)
    
    if st.button("💾 Save Alert Settings"):
        settings = {
            'high_score_threshold': high_score,
            'medium_score_threshold': medium_score,
            'min_alert_rate': min_alert_rate,
            'min_alert_rpm': min_alert_rpm,
            'email_alerts': email_alerts,
            'desktop_alerts': desktop_alerts,
            'sound_alerts': sound_alerts,
            'alert_cooldown': alert_cooldown
        }
        save_alert_settings(settings)
        st.success("✅ Alert settings saved!")

def save_alert_settings(settings):
    """Save alert settings to database"""
    try:
        conn = sqlite3.connect('data/loads.db')
        
        # Create settings table if not exists
        conn.execute("""
            CREATE TABLE IF NOT EXISTS alert_settings (
                id INTEGER PRIMARY KEY,
                setting_name TEXT UNIQUE,
                setting_value TEXT,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Save each setting
        for key, value in settings.items():
            conn.execute("""
                INSERT OR REPLACE INTO alert_settings (setting_name, setting_value, updated_at)
                VALUES (?, ?, CURRENT_TIMESTAMP)
            """, [key, str(value)])
        
        conn.commit()
        conn.close()
        
    except Exception as e:
        st.error(f"Error saving settings: {e}")

def mark_load_favorite(load_id):
    """Mark a load as favorite"""
    try:
        conn = sqlite3.connect('data/loads.db')
        
        # Create favorites table if not exists
        conn.execute("""
            CREATE TABLE IF NOT EXISTS favorites (
                id INTEGER PRIMARY KEY,
                load_id TEXT UNIQUE,
                added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Add to favorites
        conn.execute("INSERT OR IGNORE INTO favorites (load_id) VALUES (?)", [load_id])
        conn.commit()
        conn.close()
        
    except Exception as e:
        st.error(f"Error marking favorite: {e}")

def render_email_template_editor():
    """Render email template editor"""
    st.subheader("📧 Email Templates")
    
    # Load existing templates
    try:
        import json
        with open('templates/email_templates.json', 'r') as f:
            templates = json.load(f)
    except:
        templates = {}
    
    # Template selector
    template_names = list(templates.keys()) + ["Create New"]
    selected_template = st.selectbox("Select Template", template_names)
    
    if selected_template == "Create New":
        template_name = st.text_input("Template Name")
        template_data = {"subject": "", "body": ""}
    else:
        template_name = selected_template
        template_data = templates.get(selected_template, {"subject": "", "body": ""})
    
    # Template editor
    subject = st.text_input("Subject Line", value=template_data.get("subject", ""))
    body = st.text_area("Email Body", value=template_data.get("body", ""), height=200)
    
    # Template variables help
    st.info("""
    **Available Variables:**
    - {load_id} - Load ID
    - {origin} - Origin location
    - {destination} - Destination location
    - {rate} - Load rate
    - {miles} - Miles
    - {pickup_date} - Pickup date
    - {equipment_type} - Equipment type
    """)
    
    col1, col2 = st.columns(2)
    
    with col1:
        if st.button("💾 Save Template"):
            if template_name:
                templates[template_name] = {"subject": subject, "body": body}
                try:
                    with open('templates/email_templates.json', 'w') as f:
                        json.dump(templates, f, indent=2)
                    st.success("✅ Template saved!")
                except Exception as e:
                    st.error(f"Error saving template: {e}")
    
    with col2:
        if st.button("🗑️ Delete Template") and selected_template != "Create New":
            if selected_template in templates:
                del templates[selected_template]
                try:
                    with open('templates/email_templates.json', 'w') as f:
                        json.dump(templates, f, indent=2)
                    st.success("✅ Template deleted!")
                    st.experimental_rerun()
                except Exception as e:
                    st.error(f"Error deleting template: {e}")
