"""
DAT Load Analyzer - Main Application
Entry point for the DAT Load Analyzer system
"""
import sys
import os
import logging
from datetime import datetime

# Add project root to Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

try:
    import yaml
    from scraper.dat import DATScraper
    from scraper.rates import RateAnalyzer
    from scraper.monitor import LiveMonitor
    from email.gmail import GmailAutomation
    from alerts.notify import DealNotifier
except ImportError as e:
    print(f"Missing dependencies: {e}")
    print("Please run: pip install -r requirements.txt")
    sys.exit(1)

class DATLoadAnalyzer:
    def __init__(self, config_path="config.yaml"):
        """Initialize DAT Load Analyzer"""
        self.config_path = config_path
        
        # Load configuration
        try:
            with open(config_path, 'r') as file:
                self.config = yaml.safe_load(file)
        except Exception as e:
            print(f"Error loading configuration: {str(e)}")
            sys.exit(1)
        
        # Setup logging
        self.setup_logging()
        
        # Initialize components
        self.scraper = None
        self.analyzer = None
        self.monitor = None
        self.gmail = None
        self.notifier = None
        
        self.logger.info("DAT Load Analyzer initialized")
    
    def setup_logging(self):
        """Setup logging configuration"""
        log_level = logging.INFO
        
        # Ensure logs directory exists
        os.makedirs('data/logs', exist_ok=True)
        
        logging.basicConfig(
            level=log_level,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler('data/logs/dat_analyzer.log'),
                logging.StreamHandler(sys.stdout)
            ]
        )
        
        self.logger = logging.getLogger(__name__)
    
    def initialize_components(self):
        """Initialize all system components"""
        try:
            self.logger.info("Initializing system components...")
            
            # Initialize scraper
            self.scraper = DATScraper(self.config_path)
            self.logger.info("DAT scraper initialized")
            
            # Initialize analyzer
            self.analyzer = RateAnalyzer(self.config_path)
            self.logger.info("Rate analyzer initialized")
            
            # Initialize monitor
            self.monitor = LiveMonitor(self.config_path)
            self.logger.info("Live monitor initialized")
            
            # Initialize Gmail automation
            self.gmail = GmailAutomation(self.config_path)
            self.logger.info("Gmail automation initialized")
            
            # Initialize notifier
            self.notifier = DealNotifier(self.config_path)
            self.logger.info("Deal notifier initialized")
            
            return True
            
        except Exception as e:
            self.logger.error(f"Error initializing components: {str(e)}")
            return False
    
    def check_configuration(self):
        """Check if configuration is complete"""
        required_fields = [
            ('dat_login', 'username'),
            ('dat_login', 'password'),
            ('email', 'gmail_username')
        ]
        
        missing_fields = []
        
        for section, field in required_fields:
            if not self.config.get(section, {}).get(field):
                missing_fields.append(f"{section}.{field}")
        
        if missing_fields:
            self.logger.warning(f"Missing configuration fields: {', '.join(missing_fields)}")
            self.logger.warning("Please update config.yaml with your credentials")
            return False
        
        return True
    
    def run_one_time_scan(self):
        """Run a one-time scan of DAT loads"""
        try:
            self.logger.info("Starting one-time DAT scan...")
            
            if not self.scraper:
                self.scraper = DATScraper(self.config_path)
            
            # Scrape loads
            loads = self.scraper.scrape_loads()
            self.logger.info(f"Scraped {len(loads)} loads")
            
            # Analyze loads
            if not self.analyzer:
                self.analyzer = RateAnalyzer(self.config_path)
            
            analyzed_loads = self.analyzer.analyze_loads_from_database()
            self.logger.info(f"Analyzed {len(analyzed_loads)} loads")
            
            # Show top profitable loads
            profitable_loads = [load for load in analyzed_loads if load.get('profit_score', 0) >= 7.0]
            self.logger.info(f"Found {len(profitable_loads)} highly profitable loads")
            
            return analyzed_loads
            
        except Exception as e:
            self.logger.error(f"Error during one-time scan: {str(e)}")
            return []
    
    def start_live_monitoring(self):
        """Start live monitoring of DAT loads"""
        try:
            self.logger.info("Starting live monitoring...")
            
            if not self.monitor:
                self.monitor = LiveMonitor(self.config_path)
            
            success = self.monitor.start_monitoring()
            
            if success:
                self.logger.info("Live monitoring started successfully")
                return True
            else:
                self.logger.error("Failed to start live monitoring")
                return False
                
        except Exception as e:
            self.logger.error(f"Error starting live monitoring: {str(e)}")
            return False
    
    def stop_live_monitoring(self):
        """Stop live monitoring"""
        try:
            if self.monitor:
                success = self.monitor.stop_monitoring()
                if success:
                    self.logger.info("Live monitoring stopped")
                    return True
            return False
            
        except Exception as e:
            self.logger.error(f"Error stopping live monitoring: {str(e)}")
            return False
    
    def cleanup(self):
        """Cleanup resources"""
        try:
            self.logger.info("Cleaning up resources...")
            
            # Stop monitoring
            if self.monitor:
                self.monitor.stop_monitoring()
            
            # Close scraper
            if self.scraper:
                self.scraper.close()
            
            # Close Gmail
            if self.gmail:
                self.gmail.close()
            
            self.logger.info("Cleanup completed")
            
        except Exception as e:
            self.logger.error(f"Error during cleanup: {str(e)}")

def main():
    """Main entry point"""
    print("🚛 DAT Load Analyzer Starting...")
    print("=" * 50)
    
    # Initialize analyzer
    analyzer = DATLoadAnalyzer()
    
    try:
        # Check configuration
        if not analyzer.check_configuration():
            print("\n❌ Configuration incomplete!")
            print("Please update config.yaml with your DAT.com and Gmail credentials")
            return 1
        
        # Initialize components
        if not analyzer.initialize_components():
            print("\n❌ Failed to initialize components!")
            return 1
        
        print("\n✅ DAT Load Analyzer ready!")
        print("\nOptions:")
        print("1. Run one-time scan")
        print("2. Start live monitoring")
        print("3. Launch dashboard")
        print("4. Exit")
        
        while True:
            choice = input("\nEnter your choice (1-4): ").strip()
            
            if choice == '1':
                print("\n🔍 Running one-time scan...")
                loads = analyzer.run_one_time_scan()
                print(f"✅ Scan completed! Found {len(loads)} loads")
                
            elif choice == '2':
                print("\n🔴 Starting live monitoring...")
                if analyzer.start_live_monitoring():
                    print("✅ Live monitoring started!")
                    print("Press Ctrl+C to stop monitoring")
                    try:
                        while True:
                            import time
                            time.sleep(1)
                    except KeyboardInterrupt:
                        print("\n🛑 Stopping live monitoring...")
                        analyzer.stop_live_monitoring()
                else:
                    print("❌ Failed to start live monitoring")
                    
            elif choice == '3':
                print("\n🌐 Starting dashboard...")
                print("Run: streamlit run dashboard/app.py")
                break
                
            elif choice == '4':
                print("\n👋 Goodbye!")
                break
                
            else:
                print("❌ Invalid choice. Please enter 1-4.")
    
    except KeyboardInterrupt:
        print("\n\n🛑 Interrupted by user")
    except Exception as e:
        print(f"\n❌ Error: {str(e)}")
        return 1
    finally:
        analyzer.cleanup()
    
    return 0

if __name__ == "__main__":
    sys.exit(main())
