"""
Rate Analysis Engine
Analyzes load profitability using DAT.com data only
"""
import sqlite3
import yaml
import logging
from datetime import datetime
import math

class RateAnalyzer:
    def __init__(self, config_path="config.yaml"):
        """Initialize rate analyzer with configuration"""
        with open(config_path, 'r') as file:
            self.config = yaml.safe_load(file)
        
        self.analysis_config = self.config['analysis']
        
        # Setup logging
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
        self.logger = logging.getLogger(__name__)
    
    def calculate_deadhead_miles(self, current_location, load_origin):
        """
        Calculate deadhead miles from current location to load origin
        For now, use a simple estimation - in production, could use mapping API
        """
        # This is a simplified calculation
        # In a real implementation, you might use Google Maps API or similar
        # For now, we'll estimate based on coordinates or use user input
        
        # Placeholder - user should input their location manually
        # or we can implement a simple distance calculation
        return 0  # User will input deadhead manually in dashboard
    
    def analyze_load(self, load_data, current_location=None, deadhead_miles=0):
        """
        Analyze a single load for profitability
        
        Args:
            load_data: Dictionary containing load information from DAT
            current_location: Current truck location (optional)
            deadhead_miles: Manual deadhead miles input
        
        Returns:
            Dictionary with analysis results
        """
        try:
            # Extract basic data
            rate = float(load_data.get('rate', 0))
            miles = int(load_data.get('miles', 0))
            
            if rate <= 0 or miles <= 0:
                return self.create_empty_analysis("Invalid rate or miles data")
            
            # Get configuration values
            fuel_cost_per_gallon = self.analysis_config['fuel_cost_per_gallon']
            truck_mpg = self.analysis_config['truck_mpg']
            operating_cost_per_mile = self.analysis_config['operating_cost_per_mile']
            target_profit_margin = self.analysis_config['target_profit_margin']
            
            # Calculate metrics
            rate_per_mile = rate / miles
            total_miles = miles + deadhead_miles
            
            # Cost calculations
            fuel_cost = (total_miles / truck_mpg) * fuel_cost_per_gallon
            operating_cost = total_miles * operating_cost_per_mile
            total_costs = fuel_cost + operating_cost
            
            # Profit calculations
            gross_profit = rate - total_costs
            profit_margin = gross_profit / rate if rate > 0 else 0
            
            # Scoring (1-10 scale)
            profit_score = self.calculate_profit_score(profit_margin, rate_per_mile)
            
            # Recommendations
            recommendation = self.generate_recommendation(profit_margin, rate_per_mile, target_profit_margin)
            
            analysis = {
                'load_id': load_data.get('load_id'),
                'analysis_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                
                # Basic metrics
                'rate': rate,
                'miles': miles,
                'deadhead_miles': deadhead_miles,
                'total_miles': total_miles,
                'rate_per_mile': round(rate_per_mile, 2),
                
                # Cost breakdown
                'fuel_cost': round(fuel_cost, 2),
                'operating_cost': round(operating_cost, 2),
                'total_costs': round(total_costs, 2),
                
                # Profitability
                'gross_profit': round(gross_profit, 2),
                'profit_margin': round(profit_margin * 100, 2),  # Convert to percentage
                'profit_score': round(profit_score, 1),
                
                # Analysis
                'recommendation': recommendation,
                'meets_target': profit_margin >= target_profit_margin,
                'is_profitable': gross_profit > 0
            }
            
            return analysis
            
        except Exception as e:
            self.logger.error(f"Error analyzing load {load_data.get('load_id', 'unknown')}: {str(e)}")
            return self.create_empty_analysis(f"Analysis error: {str(e)}")
    
    def calculate_profit_score(self, profit_margin, rate_per_mile):
        """
        Calculate profit score (1-10 scale) based on profit margin and rate per mile
        
        Args:
            profit_margin: Profit margin as decimal (0.25 = 25%)
            rate_per_mile: Rate per mile in dollars
        
        Returns:
            Score from 1-10
        """
        # Base score from profit margin
        if profit_margin <= 0:
            margin_score = 1
        elif profit_margin >= 0.4:  # 40% or higher
            margin_score = 10
        else:
            margin_score = 1 + (profit_margin / 0.4) * 9
        
        # Rate per mile bonus/penalty
        if rate_per_mile >= 3.0:  # Excellent rate
            rate_bonus = 1.0
        elif rate_per_mile >= 2.5:  # Good rate
            rate_bonus = 0.5
        elif rate_per_mile >= 2.0:  # Average rate
            rate_bonus = 0
        elif rate_per_mile >= 1.5:  # Below average
            rate_bonus = -0.5
        else:  # Poor rate
            rate_bonus = -1.0
        
        final_score = margin_score + rate_bonus
        return max(1, min(10, final_score))  # Clamp between 1 and 10
    
    def generate_recommendation(self, profit_margin, rate_per_mile, target_margin):
        """Generate recommendation based on analysis"""
        if profit_margin >= target_margin and rate_per_mile >= 2.5:
            return "EXCELLENT - Take this load immediately!"
        elif profit_margin >= target_margin:
            return "GOOD - Profitable load, consider taking"
        elif profit_margin > 0.1:  # 10% margin
            return "MARGINAL - Low profit, negotiate higher rate"
        elif profit_margin > 0:
            return "BREAK EVEN - Covers costs only, avoid if possible"
        else:
            return "REJECT - This load will lose money"
    
    def create_empty_analysis(self, error_message):
        """Create empty analysis result with error"""
        return {
            'error': error_message,
            'profit_score': 0,
            'recommendation': 'ERROR - Cannot analyze',
            'is_profitable': False,
            'meets_target': False
        }
    
    def analyze_loads_from_database(self, limit=None):
        """
        Analyze all loads from database
        
        Args:
            limit: Maximum number of loads to analyze
        
        Returns:
            List of analyzed loads
        """
        conn = sqlite3.connect('data/loads.db')
        cursor = conn.cursor()
        
        query = """
            SELECT load_id, origin, destination, pickup_date, delivery_date,
                   equipment_type, rate, miles, rate_per_mile, broker_name,
                   broker_email, broker_phone, special_requirements,
                   posted_date, scraped_at
            FROM loads
            ORDER BY scraped_at DESC
        """
        
        if limit:
            query += f" LIMIT {limit}"
        
        cursor.execute(query)
        rows = cursor.fetchall()
        
        # Convert to dictionaries
        columns = [desc[0] for desc in cursor.description]
        loads = [dict(zip(columns, row)) for row in rows]
        
        conn.close()
        
        # Analyze each load
        analyzed_loads = []
        for load in loads:
            analysis = self.analyze_load(load)
            analyzed_load = {**load, **analysis}
            analyzed_loads.append(analyzed_load)
        
        # Update database with profit scores
        self.update_profit_scores(analyzed_loads)
        
        return analyzed_loads
    
    def update_profit_scores(self, analyzed_loads):
        """Update profit scores in database"""
        conn = sqlite3.connect('data/loads.db')
        cursor = conn.cursor()
        
        for load in analyzed_loads:
            if 'profit_score' in load and load['load_id']:
                cursor.execute(
                    "UPDATE loads SET profit_score = ? WHERE load_id = ?",
                    (load['profit_score'], load['load_id'])
                )
        
        conn.commit()
        conn.close()
    
    def get_market_analysis(self, equipment_type=None, origin_state=None):
        """
        Get market analysis from historical DAT data
        
        Args:
            equipment_type: Filter by equipment type
            origin_state: Filter by origin state
        
        Returns:
            Market analysis dictionary
        """
        conn = sqlite3.connect('data/loads.db')
        cursor = conn.cursor()
        
        # Build query with filters
        query = """
            SELECT AVG(rate_per_mile) as avg_rate_per_mile,
                   AVG(rate) as avg_rate,
                   AVG(miles) as avg_miles,
                   COUNT(*) as total_loads,
                   MIN(rate_per_mile) as min_rate_per_mile,
                   MAX(rate_per_mile) as max_rate_per_mile
            FROM loads
            WHERE rate_per_mile IS NOT NULL AND rate_per_mile > 0
        """
        
        params = []
        if equipment_type:
            query += " AND equipment_type = ?"
            params.append(equipment_type)
        
        if origin_state:
            query += " AND origin LIKE ?"
            params.append(f"%{origin_state}%")
        
        cursor.execute(query, params)
        result = cursor.fetchone()
        
        if result and result[0]:  # Check if we have data
            columns = [desc[0] for desc in cursor.description]
            market_data = dict(zip(columns, result))
            
            # Add analysis
            market_data['analysis_date'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            market_data['equipment_filter'] = equipment_type
            market_data['origin_filter'] = origin_state
            
        else:
            market_data = {
                'error': 'No market data available for the specified filters',
                'total_loads': 0
            }
        
        conn.close()
        return market_data
    
    def get_top_profitable_loads(self, limit=10):
        """Get top profitable loads from database"""
        conn = sqlite3.connect('data/loads.db')
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT * FROM loads
            WHERE profit_score IS NOT NULL
            ORDER BY profit_score DESC
            LIMIT ?
        """, (limit,))
        
        rows = cursor.fetchall()
        columns = [desc[0] for desc in cursor.description]
        loads = [dict(zip(columns, row)) for row in rows]
        
        conn.close()
        return loads

if __name__ == "__main__":
    analyzer = RateAnalyzer()
    
    # Example usage
    sample_load = {
        'load_id': 'TEST001',
        'rate': 2500,
        'miles': 1000,
        'origin': 'Chicago, IL',
        'destination': 'Atlanta, GA'
    }
    
    analysis = analyzer.analyze_load(sample_load, deadhead_miles=100)
    print("Sample Analysis:")
    for key, value in analysis.items():
        print(f"{key}: {value}")
