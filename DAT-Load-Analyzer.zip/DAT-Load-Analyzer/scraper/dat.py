"""
DAT.com Load Board Scraper
Extracts load data directly from DAT.com load board
"""
import time
import logging
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.firefox.options import Options
from selenium.common.exceptions import TimeoutException, NoSuchElementException
from webdriver_manager.firefox import GeckoDriverManager
from selenium.webdriver.firefox.service import Service
import yaml
import sqlite3
import pandas as pd
from bs4 import BeautifulSoup

class DATScraper:
    def __init__(self, config_path="config.yaml"):
        """Initialize DAT scraper with configuration"""
        with open(config_path, 'r') as file:
            self.config = yaml.safe_load(file)
        
        self.dat_config = self.config['dat_login']
        self.scraping_config = self.config['scraping']
        self.browser_config = self.config['browser']
        
        self.driver = None
        self.wait = None
        self.logged_in = False
        
        # Setup logging
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler('data/logs/dat.log'),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(__name__)
        
        # Initialize database
        self.init_database()
    
    def init_database(self):
        """Initialize SQLite database for storing load data"""
        conn = sqlite3.connect('data/loads.db')
        cursor = conn.cursor()
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS loads (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                load_id TEXT UNIQUE,
                origin TEXT,
                destination TEXT,
                pickup_date TEXT,
                delivery_date TEXT,
                equipment_type TEXT,
                rate REAL,
                miles INTEGER,
                rate_per_mile REAL,
                broker_name TEXT,
                broker_email TEXT,
                broker_phone TEXT,
                special_requirements TEXT,
                posted_date TEXT,
                scraped_at TEXT,
                profit_score REAL
            )
        ''')
        
        conn.commit()
        conn.close()
        self.logger.info("Database initialized successfully")
    
    def setup_driver(self):
        """Setup Firefox WebDriver with options"""
        firefox_options = Options()
        
        if self.scraping_config.get('headless_browser', True):
            firefox_options.add_argument('--headless')
        
        # Set user agent using Firefox preference
        firefox_options.set_preference("general.useragent.override", self.browser_config["user_agent"])
        
        # Disable automation indicators
        firefox_options.set_preference("dom.webdriver.enabled", False)
        firefox_options.set_preference('useAutomationExtension', False)
        
        # Set window size
        window_size = self.browser_config["window_size"].split(",")
        firefox_options.add_argument(f'--width={window_size[0]}')
        firefox_options.add_argument(f'--height={window_size[1]}')
        
        # Add privacy and performance settings
        firefox_options.set_preference("network.http.pipelining", True)
        firefox_options.set_preference("network.http.proxy.pipelining", True)
        firefox_options.set_preference("dom.disable_open_during_load", False)
        
        service = Service(GeckoDriverManager().install())
        self.driver = webdriver.Firefox(service=service, options=firefox_options)
        
        # Execute script to hide webdriver property
        self.driver.execute_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
        
        self.wait = WebDriverWait(self.driver, self.browser_config['wait_timeout'])
        self.logger.info("Firefox driver setup completed")
    
    def login_to_dat(self):
        """Login to DAT.com"""
        try:
            self.logger.info("Attempting to login to DAT.com")
            self.driver.get("https://power.dat.com/")
            
            # Wait for login form
            username_field = self.wait.until(
                EC.presence_of_element_located((By.ID, "username"))
            )
            password_field = self.driver.find_element(By.ID, "password")
            
            # Enter credentials
            username_field.clear()
            username_field.send_keys(self.dat_config['username'])
            
            password_field.clear()
            password_field.send_keys(self.dat_config['password'])
            
            # Click login button
            login_button = self.driver.find_element(By.XPATH, "//button[@type='submit']")
            login_button.click()
            
            # Wait for successful login (dashboard or load board)
            self.wait.until(
                EC.any_of(
                    EC.presence_of_element_located((By.CLASS_NAME, "dashboard")),
                    EC.presence_of_element_located((By.CLASS_NAME, "load-board")),
                    EC.url_contains("loadboard")
                )
            )
            
            self.logged_in = True
            self.logger.info("Successfully logged into DAT.com")
            return True
            
        except TimeoutException:
            self.logger.error("Login timeout - check credentials or DAT.com status")
            return False
        except Exception as e:
            self.logger.error(f"Login failed: {str(e)}")
            return False
    
    def navigate_to_load_board(self):
        """Navigate to the load board section"""
        try:
            self.logger.info("Navigating to load board")
            
            # Look for load board link
            load_board_link = self.wait.until(
                EC.element_to_be_clickable((By.XPATH, "//a[contains(text(), 'Load Board') or contains(@href, 'loadboard')]"))
            )
            load_board_link.click()
            
            # Wait for load board to load
            self.wait.until(
                EC.presence_of_element_located((By.CLASS_NAME, "load-results"))
            )
            
            self.logger.info("Load board loaded successfully")
            return True
            
        except TimeoutException:
            self.logger.error("Could not navigate to load board")
            return False
        except Exception as e:
            self.logger.error(f"Navigation failed: {str(e)}")
            return False
    
    def extract_load_data(self):
        """Extract load data from current page"""
        loads = []
        
        try:
            # Get page source and parse with BeautifulSoup
            page_source = self.driver.page_source
            soup = BeautifulSoup(page_source, 'html.parser')
            
            # Find load containers (adapt selectors based on DAT.com structure)
            load_containers = soup.find_all(['div', 'tr'], class_=lambda x: x and ('load' in x.lower() or 'row' in x.lower()))
            
            for container in load_containers:
                try:
                    load_data = self.parse_load_container(container)
                    if load_data:
                        loads.append(load_data)
                except Exception as e:
                    self.logger.warning(f"Error parsing load container: {str(e)}")
                    continue
            
            self.logger.info(f"Extracted {len(loads)} loads from current page")
            return loads
            
        except Exception as e:
            self.logger.error(f"Error extracting load data: {str(e)}")
            return []
    
    def parse_load_container(self, container):
        """Parse individual load container"""
        # This method needs to be adapted based on DAT.com's actual HTML structure
        # The following is a template that should be modified
        
        try:
            load_data = {
                'load_id': self.extract_text(container, ['data-load-id', 'load-id']),
                'origin': self.extract_text(container, ['.origin', '.pickup-city']),
                'destination': self.extract_text(container, ['.destination', '.delivery-city']),
                'pickup_date': self.extract_text(container, ['.pickup-date', '.date']),
                'delivery_date': self.extract_text(container, ['.delivery-date', '.del-date']),
                'equipment_type': self.extract_text(container, ['.equipment', '.truck-type']),
                'rate': self.extract_rate(container),
                'miles': self.extract_miles(container),
                'broker_name': self.extract_text(container, ['.broker', '.company']),
                'broker_email': self.extract_text(container, ['.email', '.contact-email']),
                'broker_phone': self.extract_text(container, ['.phone', '.contact-phone']),
                'special_requirements': self.extract_text(container, ['.requirements', '.notes']),
                'posted_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'scraped_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }
            
            # Calculate rate per mile
            if load_data['rate'] and load_data['miles']:
                load_data['rate_per_mile'] = load_data['rate'] / load_data['miles']
            
            return load_data
            
        except Exception as e:
            self.logger.warning(f"Error parsing load: {str(e)}")
            return None
    
    def extract_text(self, container, selectors):
        """Extract text using multiple possible selectors"""
        for selector in selectors:
            try:
                if selector.startswith('.'):
                    element = container.select_one(selector)
                elif selector.startswith('['):
                    element = container.find(attrs={selector[1:-1].split('=')[0]: selector[1:-1].split('=')[1]})
                else:
                    element = container.find(attrs={selector: True})
                
                if element:
                    return element.get_text(strip=True)
            except:
                continue
        return None
    
    def extract_rate(self, container):
        """Extract rate and convert to float"""
        rate_text = self.extract_text(container, ['.rate', '.price', '.amount'])
        if rate_text:
            # Clean rate text and convert to float
            import re
            rate_match = re.search(r'[\d,]+\.?\d*', rate_text.replace(',', ''))
            if rate_match:
                return float(rate_match.group())
        return None
    
    def extract_miles(self, container):
        """Extract miles and convert to integer"""
        miles_text = self.extract_text(container, ['.miles', '.distance'])
        if miles_text:
            import re
            miles_match = re.search(r'\d+', miles_text.replace(',', ''))
            if miles_match:
                return int(miles_match.group())
        return None
    
    def save_loads_to_database(self, loads):
        """Save loads to SQLite database"""
        if not loads:
            return
        
        conn = sqlite3.connect('data/loads.db')
        
        for load in loads:
            try:
                # Insert or ignore if load_id already exists
                conn.execute('''
                    INSERT OR IGNORE INTO loads 
                    (load_id, origin, destination, pickup_date, delivery_date, 
                     equipment_type, rate, miles, rate_per_mile, broker_name, 
                     broker_email, broker_phone, special_requirements, 
                     posted_date, scraped_at, profit_score)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    load['load_id'], load['origin'], load['destination'],
                    load['pickup_date'], load['delivery_date'], load['equipment_type'],
                    load['rate'], load['miles'], load['rate_per_mile'],
                    load['broker_name'], load['broker_email'], load['broker_phone'],
                    load['special_requirements'], load['posted_date'],
                    load['scraped_at'], load.get('profit_score')
                ))
            except Exception as e:
                self.logger.error(f"Error saving load {load.get('load_id', 'unknown')}: {str(e)}")
        
        conn.commit()
        conn.close()
        self.logger.info(f"Saved {len(loads)} loads to database")
    
    def scrape_loads(self, max_pages=None):
        """Main scraping method"""
        if not self.driver:
            self.setup_driver()
        
        if not self.logged_in and not self.login_to_dat():
            return []
        
        if not self.navigate_to_load_board():
            return []
        
        all_loads = []
        max_pages = max_pages or self.scraping_config.get('max_pages', 10)
        
        for page in range(max_pages):
            self.logger.info(f"Scraping page {page + 1}")
            
            # Extract loads from current page
            page_loads = self.extract_load_data()
            all_loads.extend(page_loads)
            
            # Save to database
            self.save_loads_to_database(page_loads)
            
            # Try to go to next page
            if not self.go_to_next_page():
                self.logger.info("No more pages available")
                break
            
            # Delay between requests
            time.sleep(self.scraping_config.get('delay_between_requests', 2))
        
        self.logger.info(f"Scraping completed. Total loads: {len(all_loads)}")
        return all_loads
    
    def go_to_next_page(self):
        """Navigate to next page"""
        try:
            next_button = self.driver.find_element(
                By.XPATH, "//button[contains(@class, 'next') or contains(text(), 'Next')]"
            )
            if next_button.is_enabled():
                next_button.click()
                time.sleep(2)
                return True
        except NoSuchElementException:
            pass
        return False
    
    def close(self):
        """Close the browser"""
        if self.driver:
            self.driver.quit()
            self.logger.info("Browser closed")

if __name__ == "__main__":
    scraper = DATScraper()
    try:
        loads = scraper.scrape_loads()
        print(f"Scraped {len(loads)} loads successfully")
    finally:
        scraper.close()
