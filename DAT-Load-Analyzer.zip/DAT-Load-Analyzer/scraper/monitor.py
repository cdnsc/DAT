"""
Live DAT.com Deal Monitor
Continuously monitors DAT.com for new loads in real-time
"""
import time
import threading
import logging
from datetime import datetime, timedelta
import sqlite3
import yaml
from scraper.dat import DATScraper
from scraper.rates import RateAnalyzer
from alerts.notify import DealNotifier

class LiveMonitor:
    def __init__(self, config_path="config.yaml"):
        """Initialize live monitor"""
        with open(config_path, 'r') as file:
            self.config = yaml.safe_load(file)
        
        self.monitoring_config = self.config['live_monitoring']
        self.alert_config = self.config['alerts']
        
        # Components
        self.scraper = DATScraper(config_path)
        self.analyzer = RateAnalyzer(config_path)
        self.notifier = DealNotifier(config_path)
        
        # State
        self.is_monitoring = False
        self.monitor_thread = None
        self.last_scan_time = None
        self.known_load_ids = set()
        
        # Setup logging
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler('data/logs/monitor.log'),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(__name__)
        
        # Load existing load IDs to avoid duplicate alerts
        self.load_existing_load_ids()
    
    def load_existing_load_ids(self):
        """Load existing load IDs from database to avoid duplicate alerts"""
        try:
            conn = sqlite3.connect('data/loads.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT load_id FROM loads WHERE load_id IS NOT NULL")
            rows = cursor.fetchall()
            
            self.known_load_ids = {row[0] for row in rows if row[0]}
            conn.close()
            
            self.logger.info(f"Loaded {len(self.known_load_ids)} existing load IDs")
            
        except Exception as e:
            self.logger.error(f"Error loading existing load IDs: {str(e)}")
            self.known_load_ids = set()
    
    def start_monitoring(self):
        """Start the live monitoring process"""
        if self.is_monitoring:
            self.logger.warning("Monitoring is already running")
            return False
        
        self.logger.info("Starting live DAT monitoring...")
        self.is_monitoring = True
        
        # Start monitoring in separate thread
        self.monitor_thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self.monitor_thread.start()
        
        return True
    
    def stop_monitoring(self):
        """Stop the live monitoring process"""
        if not self.is_monitoring:
            self.logger.warning("Monitoring is not running")
            return False
        
        self.logger.info("Stopping live DAT monitoring...")
        self.is_monitoring = False
        
        # Wait for thread to finish
        if self.monitor_thread and self.monitor_thread.is_alive():
            self.monitor_thread.join(timeout=30)
        
        # Close scraper
        self.scraper.close()
        
        return True
    
    def _monitor_loop(self):
        """Main monitoring loop"""
        scan_interval = self.monitoring_config.get('scan_interval', 45)
        
        try:
            while self.is_monitoring:
                start_time = time.time()
                
                try:
                    # Perform scan
                    self.logger.info("Starting new scan...")
                    new_loads = self.scan_for_new_loads()
                    
                    if new_loads:
                        self.logger.info(f"Found {len(new_loads)} new loads")
                        self.process_new_loads(new_loads)
                    else:
                        self.logger.info("No new loads found")
                    
                    self.last_scan_time = datetime.now()
                    
                except Exception as e:
                    self.logger.error(f"Error during scan: {str(e)}")
                
                # Calculate sleep time
                elapsed_time = time.time() - start_time
                sleep_time = max(0, scan_interval - elapsed_time)
                
                self.logger.info(f"Scan completed in {elapsed_time:.1f}s. Next scan in {sleep_time:.1f}s")
                
                # Sleep until next scan
                time.sleep(sleep_time)
                
        except Exception as e:
            self.logger.error(f"Fatal error in monitor loop: {str(e)}")
        finally:
            self.is_monitoring = False
    
    def scan_for_new_loads(self):
        """Scan DAT.com for new loads"""
        try:
            # Get current loads from DAT
            current_loads = self.scraper.scrape_loads(max_pages=3)  # Limit pages for real-time
            
            if not current_loads:
                return []
            
            # Filter for truly new loads
            new_loads = []
            for load in current_loads:
                load_id = load.get('load_id')
                if load_id and load_id not in self.known_load_ids:
                    new_loads.append(load)
                    self.known_load_ids.add(load_id)
            
            return new_loads
            
        except Exception as e:
            self.logger.error(f"Error scanning for new loads: {str(e)}")
            return []
    
    def process_new_loads(self, new_loads):
        """Process and analyze new loads"""
        alert_threshold = self.monitoring_config.get('alert_threshold_score', 7.5)
        min_profit_margin = self.alert_config.get('min_profit_margin', 0.20)
        
        profitable_loads = []
        
        for load in new_loads:
            try:
                # Analyze load profitability
                analysis = self.analyzer.analyze_load(load)
                
                # Check if load meets alert criteria
                profit_score = analysis.get('profit_score', 0)
                profit_margin = analysis.get('profit_margin', 0) / 100  # Convert from percentage
                
                if (profit_score >= alert_threshold or 
                    profit_margin >= min_profit_margin):
                    
                    profitable_load = {**load, **analysis}
                    profitable_loads.append(profitable_load)
                    
                    self.logger.info(f"Found profitable load: {load.get('load_id')} "
                                   f"(Score: {profit_score}, Margin: {profit_margin:.1%})")
            
            except Exception as e:
                self.logger.error(f"Error analyzing load {load.get('load_id', 'unknown')}: {str(e)}")
        
        # Send alerts for profitable loads
        if profitable_loads:
            self.send_alerts(profitable_loads)
    
    def send_alerts(self, profitable_loads):
        """Send alerts for profitable loads"""
        try:
            for load in profitable_loads:
                # Send desktop notification
                if self.alert_config.get('desktop_notifications', True):
                    self.notifier.send_desktop_notification(load)
                
                # Send email alert
                if self.alert_config.get('email_notifications', True):
                    self.notifier.send_email_alert(load)
                
                # Play sound alert
                if self.alert_config.get('sound_alerts', True):
                    self.notifier.play_sound_alert()
                
                self.logger.info(f"Sent alerts for load: {load.get('load_id')}")
                
        except Exception as e:
            self.logger.error(f"Error sending alerts: {str(e)}")
    
    def get_monitoring_status(self):
        """Get current monitoring status"""
        return {
            'is_monitoring': self.is_monitoring,
            'last_scan_time': self.last_scan_time.isoformat() if self.last_scan_time else None,
            'known_loads_count': len(self.known_load_ids),
            'scan_interval': self.monitoring_config.get('scan_interval', 45),
            'alert_threshold': self.monitoring_config.get('alert_threshold_score', 7.5)
        }
    
    def get_recent_activity(self, hours=24):
        """Get recent load activity from database"""
        try:
            conn = sqlite3.connect('data/loads.db')
            cursor = conn.cursor()
            
            # Get loads from last N hours
            since_time = datetime.now() - timedelta(hours=hours)
            since_str = since_time.strftime('%Y-%m-%d %H:%M:%S')
            
            cursor.execute("""
                SELECT load_id, origin, destination, rate, miles, rate_per_mile,
                       profit_score, scraped_at
                FROM loads
                WHERE scraped_at >= ?
                ORDER BY scraped_at DESC
                LIMIT 100
            """, (since_str,))
            
            rows = cursor.fetchall()
            columns = [desc[0] for desc in cursor.description]
            loads = [dict(zip(columns, row)) for row in rows]
            
            conn.close()
            
            return loads
            
        except Exception as e:
            self.logger.error(f"Error getting recent activity: {str(e)}")
            return []
    
    def force_scan(self):
        """Force an immediate scan"""
        if not self.is_monitoring:
            self.logger.warning("Cannot force scan - monitoring is not running")
            return False
        
        self.logger.info("Forcing immediate scan...")
        
        try:
            new_loads = self.scan_for_new_loads()
            if new_loads:
                self.process_new_loads(new_loads)
                return len(new_loads)
            return 0
            
        except Exception as e:
            self.logger.error(f"Error during forced scan: {str(e)}")
            return False
    
    def update_alert_criteria(self, alert_threshold=None, min_profit_margin=None):
        """Update alert criteria dynamically"""
        if alert_threshold is not None:
            self.monitoring_config['alert_threshold_score'] = alert_threshold
            self.logger.info(f"Updated alert threshold to {alert_threshold}")
        
        if min_profit_margin is not None:
            self.alert_config['min_profit_margin'] = min_profit_margin
            self.logger.info(f"Updated min profit margin to {min_profit_margin:.1%}")

if __name__ == "__main__":
    monitor = LiveMonitor()
    
    try:
        # Start monitoring
        monitor.start_monitoring()
        
        # Keep running
        print("Live monitoring started. Press Ctrl+C to stop...")
        while True:
            time.sleep(1)
            
    except KeyboardInterrupt:
        print("\nStopping monitor...")
        monitor.stop_monitoring()
        print("Monitor stopped.")
    except Exception as e:
        print(f"Error: {e}")
        monitor.stop_monitoring()
