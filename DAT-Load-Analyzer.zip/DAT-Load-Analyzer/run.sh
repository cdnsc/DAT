#!/bin/bash
# DAT Load Analyzer - Run Script
# Starts the DAT Load Analyzer system

set -e  # Exit on any error

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "🚛 Starting DAT Load Analyzer..."
echo "================================"

# Check if virtual environment exists
if [ ! -d "venv" ]; then
    echo "❌ Virtual environment not found!"
    echo "   Please run ./install.sh first"
    exit 1
fi

# Activate virtual environment
echo "🔧 Activating virtual environment..."
source venv/bin/activate

# Check if config exists
if [ ! -f "config.yaml" ]; then
    echo "❌ Configuration file not found!"
    echo "   Please create and configure config.yaml"
    exit 1
fi

# Check if dependencies are installed
echo "📦 Checking dependencies..."
python3 -c "
import sys
try:
    import selenium
    import streamlit
    import pandas
    import plotly
    import yaml
    import sqlite3
    print('✅ All dependencies available')
except ImportError as e:
    print(f'❌ Missing dependency: {e}')
    print('   Please run ./install.sh or pip install -r requirements.txt')
    sys.exit(1)
"

# Check ChromeDriver
if [ ! -f "drivers/chromedriver" ]; then
    echo "⚠️  ChromeDriver not found. Attempting to download..."
    mkdir -p drivers
    
    # Try to download ChromeDriver
    CHROME_VERSION=$(chromium --version 2>/dev/null | grep -oP '\d+' | head -1 || echo "114")
    echo "   Downloading ChromeDriver for Chrome $CHROME_VERSION..."
    
    wget -O drivers/chromedriver.zip "https://chromedriver.storage.googleapis.com/LATEST_RELEASE_${CHROME_VERSION}/chromedriver_linux64.zip" 2>/dev/null || {
        echo "❌ Failed to download ChromeDriver"
        echo "   Please download manually from https://chromedriver.chromium.org/"
        exit 1
    }
    
    cd drivers
    unzip -o chromedriver.zip
    chmod +x chromedriver
    cd ..
    echo "✅ ChromeDriver installed"
fi

# Check database
if [ ! -f "data/loads.db" ]; then
    echo "🗄️  Initializing database..."
    mkdir -p data/logs
    python3 -c "
import sys
import os
sys.path.append('.')
from scraper.dat_scraper import DATScraper
try:
    scraper = DATScraper()
    scraper.init_database()
    print('✅ Database initialized')
except Exception as e:
    print(f'❌ Database initialization failed: {e}')
    sys.exit(1)
"
fi

# Function to show menu
show_menu() {
    echo ""
    echo "🚛 DAT Load Analyzer - Main Menu"
    echo "================================"
    echo "1. 🔍 Run one-time scan"
    echo "2. 📡 Start live monitoring"
    echo "3. 🌐 Launch dashboard"
    echo "4. ⚙️  Configuration"
    echo "5. 📊 View logs"
    echo "6. 🔄 Update system"
    echo "7. ❌ Exit"
    echo ""
}

# Function to run one-time scan
run_scan() {
    echo "🔍 Running one-time DAT scan..."
    python3 main.py << EOF
1
4
EOF
}

# Function to start live monitoring
start_monitoring() {
    echo "📡 Starting live monitoring..."
    echo "   Press Ctrl+C to stop"
    python3 main.py << EOF
2
EOF
}

# Function to launch dashboard
launch_dashboard() {
    echo "🌐 Launching Streamlit dashboard..."
    echo "   Dashboard will open at: http://localhost:8501"
    echo "   Press Ctrl+C to stop"
    streamlit run dashboard/app.py --server.port 8501 --server.address 0.0.0.0
}

# Function to show configuration
show_config() {
    echo "⚙️  Current Configuration:"
    echo "========================="
    
    if [ -f "config.yaml" ]; then
        # Show config without sensitive data
        python3 -c "
import yaml
with open('config.yaml', 'r') as f:
    config = yaml.safe_load(f)

# Mask sensitive fields
if 'dat_login' in config:
    if 'password' in config['dat_login']:
        config['dat_login']['password'] = '***HIDDEN***'

if 'email' in config:
    if 'gmail_password' in config['email']:
        config['email']['gmail_password'] = '***HIDDEN***'

print(yaml.dump(config, default_flow_style=False))
"
    else
        echo "❌ config.yaml not found"
    fi
    
    echo ""
    echo "To edit configuration:"
    echo "   nano config.yaml"
}

# Function to view logs
view_logs() {
    echo "📊 Recent logs:"
    echo "==============="
    
    if [ -f "data/logs/dat_analyzer.log" ]; then
        tail -20 data/logs/dat_analyzer.log
    else
        echo "No logs found"
    fi
    
    echo ""
    echo "To view full logs:"
    echo "   tail -f data/logs/dat_analyzer.log"
}

# Function to update system
update_system() {
    echo "🔄 Updating DAT Load Analyzer..."
    
    # Update Python packages
    pip install --upgrade -r requirements.txt
    
    # Update ChromeDriver if needed
    echo "   Checking ChromeDriver..."
    CHROME_VERSION=$(chromium --version 2>/dev/null | grep -oP '\d+' | head -1 || echo "114")
    CURRENT_VERSION=$(drivers/chromedriver --version 2>/dev/null | grep -oP '\d+\.\d+\.\d+' | head -1 || echo "0")
    
    echo "   Chrome: $CHROME_VERSION, ChromeDriver: $CURRENT_VERSION"
    
    echo "✅ Update completed"
}

# Main execution
echo "✅ System ready!"

# If arguments provided, run directly
if [ $# -gt 0 ]; then
    case $1 in
        "scan")
            run_scan
            ;;
        "monitor")
            start_monitoring
            ;;
        "dashboard")
            launch_dashboard
            ;;
        "config")
            show_config
            ;;
        "logs")
            view_logs
            ;;
        "update")
            update_system
            ;;
        *)
            echo "❌ Unknown command: $1"
            echo "   Available: scan, monitor, dashboard, config, logs, update"
            exit 1
            ;;
    esac
    exit 0
fi

# Interactive menu
while true; do
    show_menu
    read -p "Select option (1-7): " choice
    
    case $choice in
        1)
            run_scan
            ;;
        2)
            start_monitoring
            ;;
        3)
            launch_dashboard
            ;;
        4)
            show_config
            ;;
        5)
            view_logs
            ;;
        6)
            update_system
            ;;
        7)
            echo "👋 Goodbye!"
            exit 0
            ;;
        *)
            echo "❌ Invalid option. Please select 1-7."
            ;;
    esac
    
    echo ""
    read -p "Press Enter to continue..."
done
