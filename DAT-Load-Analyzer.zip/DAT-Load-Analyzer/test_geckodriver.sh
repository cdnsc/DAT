#!/bin/bash
# Quick test script for geckodriver installation

echo "🔧 Testing geckodriver installation..."
echo "======================================"

# Test 1: Check if geckodriver command exists
echo "🔍 Test 1: Checking if geckodriver command exists..."
if command -v geckodriver &> /dev/null; then
    echo "✅ geckodriver command found"
    echo "📍 Location: $(which geckodriver)"
    echo "📋 Version: $(geckodriver --version | head -1)"
else
    echo "❌ geckodriver command not found"
fi

# Test 2: Test download function manually
echo ""
echo "🔍 Test 2: Testing download of specific geckodriver version..."

# Function to safely download files (same as in install.sh)
safe_download() {
    local url="$1"
    local output="$2"
    local max_attempts=3
    local attempt=1
    
    while [ $attempt -le $max_attempts ]; do
        echo "ℹ️ Download attempt $attempt/$max_attempts: $url"
        if wget -O "$output" "$url"; then
            if [ -s "$output" ]; then
                echo "✅ Download successful"
                return 0
            else
                echo "❌ Downloaded file is empty"
                rm -f "$output"
            fi
        else
            echo "❌ Download failed"
        fi
        
        attempt=$((attempt + 1))
        if [ $attempt -le $max_attempts ]; then
            echo "ℹ️ Retrying in 3 seconds..."
            sleep 3
        fi
    done
    
    return 1
}

# Test downloading v0.33.0 (known working version)
TEST_URL="https://github.com/mozilla/geckodriver/releases/download/v0.33.0/geckodriver-v0.33.0-linux64.tar.gz"
TEST_FILE="/tmp/test_geckodriver.tar.gz"

if safe_download "$TEST_URL" "$TEST_FILE"; then
    echo "✅ Test download successful"
    echo "📊 File size: $(ls -lh $TEST_FILE | awk '{print $5}')"
    
    # Test extraction
    echo "🔍 Test 3: Testing extraction..."
    mkdir -p /tmp/test_gecko
    if tar -xzf "$TEST_FILE" -C /tmp/test_gecko/; then
        echo "✅ Extraction successful"
        if [ -f "/tmp/test_gecko/geckodriver" ]; then
            echo "✅ geckodriver binary extracted"
            echo "📋 Version: $(/tmp/test_gecko/geckodriver --version | head -1)"
        else
            echo "❌ geckodriver binary not found after extraction"
        fi
    else
        echo "❌ Extraction failed"
    fi
    
    # Cleanup
    rm -f "$TEST_FILE"
    rm -rf /tmp/test_gecko
else
    echo "❌ Test download failed"
fi

echo ""
echo "🔍 Test 4: Testing GitHub API version detection..."
VERSION_API=$(curl -s https://api.github.com/repos/mozilla/geckodriver/releases/latest | grep '"tag_name":' | sed -E 's/.*"([^"]+)".*/\1/' | head -1)
echo "🐛 GitHub API returned: '$VERSION_API'"

if [ -n "$VERSION_API" ] && [ "$VERSION_API" != "null" ]; then
    echo "✅ GitHub API version detection works"
else
    echo "❌ GitHub API version detection failed"
fi

echo ""
echo "🎯 Test Summary:"
echo "==============="
echo "• Command availability: $(command -v geckodriver &> /dev/null && echo "✅ OK" || echo "❌ FAIL")"
echo "• Download functionality: Test completed above"
echo "• GitHub API: $([ -n "$VERSION_API" ] && [ "$VERSION_API" != "null" ] && echo "✅ OK" || echo "❌ FAIL")"
echo ""
echo "💡 If geckodriver is not working, you can:"
echo "1. Re-run the install script: ./install.sh"
echo "2. Install manually: See firefox-setup.md"
echo "3. Use webdriver-manager: The app will auto-download when needed"
