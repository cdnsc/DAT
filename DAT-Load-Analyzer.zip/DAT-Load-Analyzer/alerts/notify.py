"""
Deal Notification System
Sends alerts for profitable DAT loads
"""
import logging
from datetime import datetime
import yaml
try:
    from plyer import notification
    PLYER_AVAILABLE = True
except ImportError:
    PLYER_AVAILABLE = False
    print("plyer not available - desktop notifications disabled")

import sqlite3
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

class DealNotifier:
    def __init__(self, config_path="config.yaml"):
        """Initialize deal notifier"""
        with open(config_path, 'r') as file:
            self.config = yaml.safe_load(file)
        
        self.alert_config = self.config['alerts']
        
        # Setup logging
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)
        
        # Initialize alerts database
        self.init_alerts_database()
    
    def init_alerts_database(self):
        """Initialize database for tracking sent alerts"""
        conn = sqlite3.connect('data/loads.db')
        cursor = conn.cursor()
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS alerts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                load_id TEXT,
                alert_type TEXT,
                sent_at TEXT,
                profit_score REAL,
                profit_margin REAL
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def send_desktop_notification(self, load_data):
        """Send desktop notification for profitable load"""
        if not PLYER_AVAILABLE:
            self.logger.warning("Desktop notifications not available - plyer not installed")
            return False
        
        try:
            origin = load_data.get('origin', 'Unknown')
            destination = load_data.get('destination', 'Unknown')
            rate = load_data.get('rate', 0)
            profit_score = load_data.get('profit_score', 0)
            profit_margin = load_data.get('profit_margin', 0)
            
            title = f"🚛 Profitable Load Alert!"
            message = (f"Score: {profit_score:.1f}/10 | Margin: {profit_margin:.1f}%\n"
                      f"{origin} → {destination}\n"
                      f"Rate: ${rate:,.0f}")
            
            notification.notify(
                title=title,
                message=message,
                app_name="DAT Load Analyzer",
                timeout=10,
                toast=True
            )
            
            # Log the alert
            self.log_alert(load_data.get('load_id'), 'desktop', profit_score, profit_margin)
            
            self.logger.info(f"Desktop notification sent for load {load_data.get('load_id')}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error sending desktop notification: {str(e)}")
            return False
    
    def send_email_alert(self, load_data):
        """Send email alert for profitable load (placeholder)"""
        # For now, just log the alert
        # In a full implementation, this would send actual emails
        try:
            origin = load_data.get('origin', 'Unknown')
            destination = load_data.get('destination', 'Unknown')
            rate = load_data.get('rate', 0)
            profit_score = load_data.get('profit_score', 0)
            profit_margin = load_data.get('profit_margin', 0)
            
            self.logger.info(f"EMAIL ALERT: Profitable load {load_data.get('load_id')} - "
                           f"{origin} to {destination}, Rate: ${rate:,.0f}, "
                           f"Score: {profit_score:.1f}, Margin: {profit_margin:.1f}%")
            
            # Log the alert
            self.log_alert(load_data.get('load_id'), 'email', profit_score, profit_margin)
            
            return True
            
        except Exception as e:
            self.logger.error(f"Error sending email alert: {str(e)}")
            return False
    
    def play_sound_alert(self):
        """Play sound alert (placeholder)"""
        try:
            # For cross-platform compatibility, we'll use a simple approach
            # In a full implementation, you might use pygame or similar
            import sys
            
            if sys.platform == "win32":
                import winsound
                # Play Windows system sound
                winsound.MessageBeep(winsound.MB_ICONEXCLAMATION)
            else:
                # For Linux/Unix systems
                import os
                os.system('echo -e "\a"')  # Terminal bell
            
            self.logger.info("Sound alert played")
            return True
            
        except Exception as e:
            self.logger.warning(f"Could not play sound alert: {str(e)}")
            return False
    
    def log_alert(self, load_id, alert_type, profit_score, profit_margin):
        """Log sent alert to database"""
        try:
            conn = sqlite3.connect('data/loads.db')
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO alerts (load_id, alert_type, sent_at, profit_score, profit_margin)
                VALUES (?, ?, ?, ?, ?)
            ''', (
                load_id,
                alert_type,
                datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                profit_score,
                profit_margin
            ))
            
            conn.commit()
            conn.close()
            
        except Exception as e:
            self.logger.error(f"Error logging alert: {str(e)}")
    
    def get_alert_history(self, limit=50):
        """Get recent alert history"""
        try:
            conn = sqlite3.connect('data/loads.db')
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT a.*, l.origin, l.destination, l.rate, l.miles
                FROM alerts a
                LEFT JOIN loads l ON a.load_id = l.load_id
                ORDER BY a.sent_at DESC
                LIMIT ?
            ''', (limit,))
            
            rows = cursor.fetchall()
            columns = [desc[0] for desc in cursor.description]
            alerts = [dict(zip(columns, row)) for row in rows]
            
            conn.close()
            return alerts
            
        except Exception as e:
            self.logger.error(f"Error getting alert history: {str(e)}")
            return []
    
    def get_alert_stats(self, days=7):
        """Get alert statistics for the last N days"""
        try:
            conn = sqlite3.connect('data/loads.db')
            cursor = conn.cursor()
            
            from datetime import timedelta
            since_date = (datetime.now() - timedelta(days=days)).strftime('%Y-%m-%d')
            
            cursor.execute('''
                SELECT 
                    COUNT(*) as total_alerts,
                    COUNT(DISTINCT load_id) as unique_loads,
                    AVG(profit_score) as avg_profit_score,
                    AVG(profit_margin) as avg_profit_margin,
                    alert_type,
                    COUNT(*) as count_by_type
                FROM alerts
                WHERE sent_at >= ?
                GROUP BY alert_type
            ''', (since_date,))
            
            rows = cursor.fetchall()
            columns = [desc[0] for desc in cursor.description]
            stats = [dict(zip(columns, row)) for row in rows]
            
            conn.close()
            return stats
            
        except Exception as e:
            self.logger.error(f"Error getting alert stats: {str(e)}")
            return []
    
    def test_notifications(self):
        """Test all notification methods"""
        test_load = {
            'load_id': 'TEST001',
            'origin': 'Chicago, IL',
            'destination': 'Atlanta, GA',
            'rate': 2500,
            'miles': 1000,
            'profit_score': 8.5,
            'profit_margin': 25.0
        }
        
        results = {}
        
        # Test desktop notification
        results['desktop'] = self.send_desktop_notification(test_load)
        
        # Test email alert
        results['email'] = self.send_email_alert(test_load)
        
        # Test sound alert
        results['sound'] = self.play_sound_alert()
        
        return results

if __name__ == "__main__":
    notifier = DealNotifier()
    
    # Test notifications
    print("Testing notification system...")
    results = notifier.test_notifications()
    
    for method, success in results.items():
        status = "✓ Success" if success else "✗ Failed"
        print(f"{method.capitalize()} notification: {status}")
    
    # Show alert history
    history = notifier.get_alert_history(10)
    print(f"\nRecent alerts: {len(history)}")
    
    # Show alert stats
    stats = notifier.get_alert_stats(7)
    print(f"Alert stats (7 days): {stats}")
