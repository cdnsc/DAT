#!/bin/bash
# DAT Load Analyzer - Simple Installation (No Virtual Environment)
# Use this if you prefer global Python package installation

echo "🚛 Installing DAT Load Analyzer - Global Installation"
echo "=================================================="

echo "⚠️ WARNING: This will install packages globally on your system"
echo "⚠️ This may cause conflicts with other Python projects"
read -p "Continue? (y/N): " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "❌ Installation cancelled"
    exit 1
fi

cd "$(dirname "$0")"

echo "🦊 Installing Firefox browser..."
sudo dnf install -y firefox

echo "🔧 Installing geckodriver..."
sudo dnf install -y mozilla-geckodriver || {
    echo "📦 System geckodriver not available, installing manually..."
    wget -O /tmp/geckodriver.tar.gz "https://github.com/mozilla/geckodriver/releases/download/v0.33.0/geckodriver-v0.33.0-linux64.tar.gz"
    sudo tar -xzf /tmp/geckodriver.tar.gz -C /usr/local/bin/
    sudo chmod +x /usr/local/bin/geckodriver
    rm -f /tmp/geckodriver.tar.gz
}

echo "🔧 Installing system dependencies..."
sudo dnf install -y \
    python3-pip \
    python3-devel \
    gcc \
    gcc-c++ \
    python3-tkinter \
    libffi-devel \
    openssl-devel \
    sqlite \
    sqlite-devel \
    libnotify \
    libnotify-devel

echo "📦 Installing Python packages globally..."
pip3 install --user -r requirements.txt

echo "✅ Installation complete!"
echo ""
echo "🚀 To run the application:"
echo "   python3 main.py --help"
echo ""
echo "🗑️ To uninstall later:"
echo "   pip3 uninstall -r requirements.txt"
