#!/usr/bin/env python3
"""
Firefox Configuration Test
Tests Firefox WebDriver setup for DAT Load Analyzer
"""

import sys
import os
import yaml
import logging

# Add project root to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def test_firefox_setup():
    """Test Firefox WebDriver configuration"""
    print("🔥 Testing Firefox WebDriver Configuration")
    print("=" * 50)
    
    try:
        # Load configuration
        with open('../config.yaml', 'r') as file:
            config = yaml.safe_load(file)
        print("✅ Configuration loaded successfully")
        
        # Test imports
        print("📦 Testing imports...")
        from selenium import webdriver
        from selenium.webdriver.firefox.options import Options
        from selenium.webdriver.firefox.service import Service
        from webdriver_manager.firefox import GeckoDriverManager
        print("✅ All imports successful")
        
        # Setup Firefox options
        print("⚙️ Setting up Firefox options...")
        firefox_options = Options()
        firefox_options.add_argument('--headless')
        
        # Set user agent
        user_agent = config['browser']['user_agent']
        firefox_options.set_preference("general.useragent.override", user_agent)
        
        # Disable automation indicators
        firefox_options.set_preference("dom.webdriver.enabled", False)
        
        print("✅ Firefox options configured")
        
        # Test geckodriver installation
        print("🔧 Testing geckodriver...")
        try:
            service = Service(GeckoDriverManager().install())
            print("✅ Geckodriver installed successfully")
        except Exception as e:
            print(f"⚠️ Geckodriver auto-install failed: {e}")
            print("   Trying system geckodriver...")
            service = Service('geckodriver')
        
        # Create driver instance
        print("🚗 Creating Firefox driver...")
        driver = webdriver.Firefox(service=service, options=firefox_options)
        
        # Test basic functionality
        print("🌐 Testing web navigation...")
        driver.get("https://httpbin.org/user-agent")
        
        # Check if page loaded
        if "User-Agent" in driver.page_source:
            print("✅ Web navigation successful")
        else:
            print("❌ Web navigation failed")
        
        # Clean up
        driver.quit()
        print("✅ Driver cleanup completed")
        
        print("\n🎉 Firefox configuration test PASSED!")
        return True
        
    except Exception as e:
        print(f"\n❌ Firefox configuration test FAILED: {e}")
        return False

def test_firefox_profiles():
    """Test Firefox profile creation"""
    print("\n🗂️ Testing Firefox profile management...")
    
    try:
        profile_dir = "../data/firefox_profile_test"
        os.makedirs(profile_dir, exist_ok=True)
        print(f"✅ Profile directory created: {profile_dir}")
        
        # Clean up
        import shutil
        shutil.rmtree(profile_dir)
        print("✅ Profile cleanup completed")
        
        return True
        
    except Exception as e:
        print(f"❌ Profile test failed: {e}")
        return False

def check_fedora_deps():
    """Check Fedora-specific dependencies"""
    print("\n🐧 Checking Fedora dependencies...")
    
    import subprocess
    
    checks = [
        ("firefox", "Firefox browser"),
        ("python3", "Python 3"),
        ("pip3", "Python pip")
    ]
    
    all_good = True
    
    for cmd, desc in checks:
        try:
            result = subprocess.run(['which', cmd], capture_output=True, text=True)
            if result.returncode == 0:
                print(f"✅ {desc}: {result.stdout.strip()}")
            else:
                print(f"❌ {desc}: Not found")
                all_good = False
        except Exception as e:
            print(f"❌ {desc}: Error checking - {e}")
            all_good = False
    
    return all_good

if __name__ == "__main__":
    print("🚛 DAT Load Analyzer - Firefox Configuration Test")
    print("=" * 60)
    
    # Change to script directory
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    
    success = True
    
    # Run tests
    success &= check_fedora_deps()
    success &= test_firefox_profiles()
    success &= test_firefox_setup()
    
    print("\n" + "=" * 60)
    if success:
        print("🎉 ALL TESTS PASSED! Firefox configuration is ready.")
        sys.exit(0)
    else:
        print("❌ SOME TESTS FAILED! Check the output above.")
        sys.exit(1)
