#!/usr/bin/env python3
"""
Test script to check if all imports work after file renaming
"""

print("🔍 Testing imports after file renaming...")
print("=" * 50)

# Test main imports
try:
    import main
    print("✅ main.py import successful")
except Exception as e:
    print(f"❌ main.py import failed: {e}")

# Test scraper imports
try:
    from scraper.dat import DATScraper
    print("✅ scraper.dat import successful")
except Exception as e:
    print(f"❌ scraper.dat import failed: {e}")

try:
    from scraper.rates import RateAnalyzer
    print("✅ scraper.rates import successful")
except Exception as e:
    print(f"❌ scraper.rates import failed: {e}")

try:
    from scraper.monitor import LiveMonitor
    print("✅ scraper.monitor import successful")
except Exception as e:
    print(f"❌ scraper.monitor import failed: {e}")

# Test email imports
try:
    from email.gmail import GmailAutomation
    print("✅ email.gmail import successful")
except Exception as e:
    print(f"❌ email.gmail import failed: {e}")

# Test alert imports
try:
    from alerts.notify import DealNotifier
    print("✅ alerts.notify import successful")
except Exception as e:
    print(f"❌ alerts.notify import failed: {e}")

# Test utils imports
try:
    from utils.firefox import FirefoxDriverManager
    print("✅ utils.firefox import successful")
except Exception as e:
    print(f"❌ utils.firefox import failed: {e}")

print("\n🎯 Testing class instantiation...")
print("=" * 50)

# Test basic class instantiation (without config for now)
test_config_content = """
dat_login:
  username: "test"
  password: "test"
  
scraping:
  max_pages: 5
  delay_between_pages: 2
  retry_attempts: 3
  
analysis:
  fuel_cost_per_gallon: 3.50
  mpg: 6.5
  operating_cost_per_mile: 1.75
  minimum_profit_margin: 15.0
  
email:
  gmail_username: "test@gmail.com"
  gmail_password: "test"
  signature: "Test Signature"
  
browser:
  headless: true
  user_agent: "test"
  
live_monitoring:
  scan_interval: 60
  max_scan_pages: 3
"""

# Write test config
with open('test_config.yaml', 'w') as f:
    f.write(test_config_content)

try:
    analyzer = main.DATLoadAnalyzer('test_config.yaml')
    print("✅ DATLoadAnalyzer instantiation successful")
except Exception as e:
    print(f"❌ DATLoadAnalyzer instantiation failed: {e}")

# Cleanup
import os
if os.path.exists('test_config.yaml'):
    os.remove('test_config.yaml')

print("\n🚀 Import testing complete!")
