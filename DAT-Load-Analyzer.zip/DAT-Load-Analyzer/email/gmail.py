"""
Gmail Automation System
Automates Gmail.com for sending emails to brokers
"""
import time
import json
import logging
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.firefox.options import Options
from selenium.common.exceptions import TimeoutException, NoSuchElementException
from webdriver_manager.firefox import GeckoDriverManager
from selenium.webdriver.firefox.service import Service
import yaml

class GmailAutomation:
    def __init__(self, config_path="config.yaml"):
        """Initialize Gmail automation"""
        with open(config_path, 'r') as file:
            self.config = yaml.safe_load(file)
        
        self.email_config = self.config['email']
        self.browser_config = self.config['browser']
        
        self.driver = None
        self.wait = None
        self.logged_in = False
        
        # Setup logging
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler('data/logs/gmail_automation.log'),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(__name__)
        
        # Load email templates
        self.load_email_templates()
    
    def load_email_templates(self):
        """Load email templates from JSON file"""
        try:
            template_path = self.email_config.get('template_folder', './templates/') + 'emails.json'
            with open(template_path, 'r') as file:
                self.templates = json.load(file)
            
            self.logger.info(f"Loaded {len(self.templates['templates'])} email templates")
            
        except Exception as e:
            self.logger.error(f"Error loading email templates: {str(e)}")
            self.templates = {'templates': {}, 'signature': ''}
    
    def setup_driver(self):
        """Setup Firefox WebDriver for Gmail"""
        firefox_options = Options()
        
        # Gmail works better with a visible browser
        # firefox_options.add_argument('--headless')  # Disable for Gmail
        
        # Set user agent
        firefox_options.set_preference("general.useragent.override", self.browser_config["user_agent"])
        
        # Set window size
        window_size = self.browser_config["window_size"].split(",")
        firefox_options.add_argument(f'--width={window_size[0]}')
        firefox_options.add_argument(f'--height={window_size[1]}')
        
        # Disable automation indicators
        firefox_options.set_preference("dom.webdriver.enabled", False)
        firefox_options.set_preference('useAutomationExtension', False)
        
        # Enable profile for maintaining login session
        firefox_options.add_argument('--profile')
        firefox_options.add_argument('./data/firefox_profile')
        
        service = Service(GeckoDriverManager().install())
        self.driver = webdriver.Firefox(service=service, options=firefox_options)
        
        # Execute script to hide webdriver property
        self.driver.execute_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
        
        self.wait = WebDriverWait(self.driver, self.browser_config['wait_timeout'])
        self.logger.info("Firefox driver setup completed for Gmail")
    
    def login_to_gmail(self):
        """Login to Gmail (or use existing session)"""
        try:
            if not self.driver:
                self.setup_driver()
            
            self.logger.info("Navigating to Gmail...")
            self.driver.get("https://mail.google.com")
            
            # Check if already logged in
            try:
                # Look for Gmail interface elements
                self.wait.until(
                    EC.any_of(
                        EC.presence_of_element_located((By.XPATH, "//div[@aria-label='Compose']")),
                        EC.presence_of_element_located((By.XPATH, "//div[contains(@class, 'T-I T-I-KE L3')]")),
                        EC.presence_of_element_located((By.XPATH, "//div[@role='button' and contains(text(), 'Compose')]"))
                    )
                )
                self.logged_in = True
                self.logger.info("Already logged into Gmail")
                return True
                
            except TimeoutException:
                # Need to login
                self.logger.info("Need to login to Gmail")
                
                # Look for email input
                try:
                    email_input = self.wait.until(
                        EC.element_to_be_clickable((By.ID, "identifierId"))
                    )
                    
                    email_input.clear()
                    email_input.send_keys(self.email_config['gmail_username'])
                    
                    # Click Next
                    next_button = self.driver.find_element(By.ID, "identifierNext")
                    next_button.click()
                    
                    # Note: Password entry would require manual intervention
                    # for security. In a production environment, you might use
                    # OAuth2 or app passwords
                    
                    self.logger.warning("Please complete Gmail login manually in the browser window")
                    
                    # Wait for successful login
                    self.wait.until(
                        EC.presence_of_element_located((By.XPATH, "//div[@aria-label='Compose']"))
                    )
                    
                    self.logged_in = True
                    self.logger.info("Successfully logged into Gmail")
                    return True
                    
                except TimeoutException:
                    self.logger.error("Gmail login failed or timed out")
                    return False
                    
        except Exception as e:
            self.logger.error(f"Error logging into Gmail: {str(e)}")
            return False
    
    def compose_email(self, template_name, load_data, broker_email=None):
        """
        Compose and auto-fill email using template and load data
        
        Args:
            template_name: Name of email template to use
            load_data: Load information for auto-filling
            broker_email: Broker's email address (optional, extracted from load_data if not provided)
        
        Returns:
            True if email composed successfully, False otherwise
        """
        try:
            if not self.logged_in and not self.login_to_gmail():
                return False
            
            # Get email template
            template = self.templates['templates'].get(template_name)
            if not template:
                self.logger.error(f"Template '{template_name}' not found")
                return False
            
            # Extract broker email
            if not broker_email:
                broker_email = load_data.get('broker_email', '')
            
            if not broker_email:
                self.logger.error("No broker email provided")
                return False
            
            # Click Compose button
            self.logger.info("Clicking Compose button...")
            compose_button = self.wait.until(
                EC.element_to_be_clickable((By.XPATH, "//div[@aria-label='Compose' or contains(@class, 'T-I-KE') or contains(text(), 'Compose')]"))
            )
            compose_button.click()
            
            time.sleep(2)  # Wait for compose window to open
            
            # Fill in recipient
            self.logger.info(f"Filling recipient: {broker_email}")
            to_field = self.wait.until(
                EC.element_to_be_clickable((By.XPATH, "//input[@aria-label='To' or contains(@name, 'to') or contains(@placeholder, 'Recipients')]"))
            )
            to_field.clear()
            to_field.send_keys(broker_email)
            
            # Fill in subject
            subject_text = self.fill_template(template['subject'], load_data)
            self.logger.info(f"Filling subject: {subject_text}")
            subject_field = self.driver.find_element(By.XPATH, "//input[@aria-label='Subject' or contains(@name, 'subject') or contains(@placeholder, 'Subject')]")
            subject_field.clear()
            subject_field.send_keys(subject_text)
            
            # Fill in body
            body_text = self.fill_template(template['body'], load_data)
            self.logger.info("Filling email body...")
            
            # Find the message body (Gmail uses contenteditable div)
            body_field = self.driver.find_element(By.XPATH, "//div[@aria-label='Message Body' or contains(@role, 'textbox') or contains(@contenteditable, 'true')]")
            
            # Clear and fill body
            body_field.clear()
            body_field.send_keys(body_text)
            
            self.logger.info("Email composed successfully - ready for manual review and sending")
            
            # Log the composed email
            self.log_composed_email(load_data.get('load_id'), template_name, broker_email)
            
            return True
            
        except Exception as e:
            self.logger.error(f"Error composing email: {str(e)}")
            return False
    
    def fill_template(self, template_text, load_data):
        """Fill template with load data"""
        try:
            # Get signature
            signature = self.templates.get('signature', '')
            
            # Prepare template variables
            template_vars = {
                'origin': load_data.get('origin', 'Unknown'),
                'destination': load_data.get('destination', 'Unknown'),
                'pickup_date': load_data.get('pickup_date', 'TBD'),
                'delivery_date': load_data.get('delivery_date', 'TBD'),
                'rate': f"{load_data.get('rate', 0):,.0f}",
                'miles': f"{load_data.get('miles', 0):,}",
                'equipment': load_data.get('equipment_type', 'Dry Van'),
                'broker_name': load_data.get('broker_name', ''),
                'signature': signature,
                'proposed_rate': f"{load_data.get('rate', 0) * 1.1:,.0f}"  # 10% higher for negotiation
            }
            
            # Fill template
            filled_text = template_text.format(**template_vars)
            
            return filled_text
            
        except Exception as e:
            self.logger.error(f"Error filling template: {str(e)}")
            return template_text
    
    def log_composed_email(self, load_id, template_name, broker_email):
        """Log composed email to database"""
        try:
            import sqlite3
            
            conn = sqlite3.connect('data/loads.db')
            cursor = conn.cursor()
            
            # Create emails table if it doesn't exist
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS emails (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    load_id TEXT,
                    template_name TEXT,
                    broker_email TEXT,
                    composed_at TEXT,
                    status TEXT
                )
            ''')
            
            cursor.execute('''
                INSERT INTO emails (load_id, template_name, broker_email, composed_at, status)
                VALUES (?, ?, ?, ?, ?)
            ''', (
                load_id,
                template_name,
                broker_email,
                datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'composed'
            ))
            
            conn.commit()
            conn.close()
            
            self.logger.info(f"Logged composed email for load {load_id}")
            
        except Exception as e:
            self.logger.error(f"Error logging composed email: {str(e)}")
    
    def get_available_templates(self):
        """Get list of available email templates"""
        return list(self.templates['templates'].keys())
    
    def preview_email(self, template_name, load_data):
        """Preview how email will look with load data"""
        template = self.templates['templates'].get(template_name)
        if not template:
            return None
        
        preview = {
            'template_name': template_name,
            'subject': self.fill_template(template['subject'], load_data),
            'body': self.fill_template(template['body'], load_data),
            'broker_email': load_data.get('broker_email', 'No email available')
        }
        
        return preview
    
    def quick_send_inquiry(self, load_data):
        """Quick method to send load inquiry email"""
        return self.compose_email('load_inquiry', load_data)
    
    def send_rate_negotiation(self, load_data):
        """Send rate negotiation email"""
        return self.compose_email('rate_negotiation', load_data)
    
    def send_follow_up(self, load_data):
        """Send follow-up email"""
        return self.compose_email('follow_up', load_data)
    
    def send_quick_response(self, load_data):
        """Send quick response for immediate availability"""
        return self.compose_email('quick_response', load_data)
    
    def close(self):
        """Close the browser"""
        if self.driver:
            self.driver.quit()
            self.logger.info("Gmail browser closed")

if __name__ == "__main__":
    gmail = GmailAutomation()
    
    # Test with sample load data
    sample_load = {
        'load_id': 'TEST001',
        'origin': 'Chicago, IL',
        'destination': 'Atlanta, GA',
        'pickup_date': '2025-08-26',
        'rate': 2500,
        'miles': 1000,
        'equipment_type': 'Dry Van',
        'broker_name': 'ABC Logistics',
        'broker_email': 'broker@abclogistics.com'
    }
    
    try:
        # Preview email
        preview = gmail.preview_email('load_inquiry', sample_load)
        if preview:
            print("Email Preview:")
            print(f"To: {preview['broker_email']}")
            print(f"Subject: {preview['subject']}")
            print(f"Body: {preview['body'][:200]}...")
        
        # Compose email (requires manual intervention for sending)
        gmail.compose_email('load_inquiry', sample_load)
        
        input("Press Enter when done with Gmail...")
        
    finally:
        gmail.close()
