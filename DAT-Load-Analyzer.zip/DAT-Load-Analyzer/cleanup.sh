#!/bin/bash
# DAT Load Analyzer - Cleanup Script
# Use this if you encounter virtual environment issues

echo "🧹 DAT Load Analyzer - Cleanup Script"
echo "======================================"

cd "$(dirname "$0")"

echo "🗑️ Removing virtual environment..."
if [ -d "venv" ]; then
    rm -rf venv
    echo "✅ Virtual environment removed"
else
    echo "ℹ️ No virtual environment found"
fi

echo "🗑️ Removing Python cache files..."
find . -type d -name "__pycache__" -exec rm -rf {} + 2>/dev/null || true
find . -name "*.pyc" -delete 2>/dev/null || true
echo "✅ Python cache files removed"

echo "🗑️ Removing log files..."
if [ -d "data/logs" ]; then
    rm -f data/logs/*.log
    echo "✅ Log files removed"
else
    echo "ℹ️ No log files found"
fi

echo ""
echo "🎯 Cleanup complete! You can now run:"
echo "   ./install.sh"
echo ""
echo "💡 If you still have issues:"
echo "   1. Restart your terminal"
echo "   2. Run: source ~/.bashrc"
echo "   3. Try the installation again"
