"""
Firefox Configuration Utility
Provides standardized Firefox WebDriver setup for all modules
"""
import os
import logging
from selenium import webdriver
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.firefox.service import Service
from webdriver_manager.firefox import GeckoDriverManager

class FirefoxDriverManager:
    """Centralized Firefox WebDriver configuration"""
    
    def __init__(self, config):
        self.config = config
        self.browser_config = config['browser']
        self.logger = logging.getLogger(__name__)
    
    def create_driver(self, headless=None, profile_path=None, for_gmail=False):
        """
        Create a configured Firefox WebDriver instance
        
        Args:
            headless: Override headless setting from config
            profile_path: Custom profile path
            for_gmail: Special configuration for Gmail automation
        
        Returns:
            WebDriver instance
        """
        firefox_options = Options()
        
        # Headless mode
        if headless is None:
            headless = self.browser_config.get('headless', True)
        
        # Gmail works better with visible browser
        if for_gmail:
            headless = False
            
        if headless:
            firefox_options.add_argument('--headless')
        
        # Set user agent
        user_agent = self.browser_config.get('user_agent', 
            'Mozilla/5.0 (X11; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/115.0')
        firefox_options.set_preference("general.useragent.override", user_agent)
        
        # Window size
        window_size = self.browser_config.get('window_size', '1920,1080').split(',')
        firefox_options.add_argument(f'--width={window_size[0]}')
        firefox_options.add_argument(f'--height={window_size[1]}')
        
        # Anti-detection settings
        firefox_options.set_preference("dom.webdriver.enabled", False)
        firefox_options.set_preference('useAutomationExtension', False)
        firefox_options.set_preference("marionette.enabled", True)
        
        # Performance settings
        firefox_options.set_preference("network.http.pipelining", True)
        firefox_options.set_preference("network.http.proxy.pipelining", True)
        firefox_options.set_preference("network.http.pipelining.maxrequests", 8)
        firefox_options.set_preference("content.notify.interval", 500000)
        firefox_options.set_preference("content.notify.ontimer", True)
        firefox_options.set_preference("content.switch.threshold", 250000)
        
        # Security and privacy
        firefox_options.set_preference("security.fileuri.strict_origin_policy", False)
        firefox_options.set_preference("dom.disable_open_during_load", False)
        firefox_options.set_preference("media.peerconnection.enabled", False)
        
        # Profile management
        if profile_path:
            if not os.path.exists(profile_path):
                os.makedirs(profile_path, exist_ok=True)
            firefox_options.add_argument(f'--profile={profile_path}')
        elif for_gmail:
            # Create Gmail-specific profile
            gmail_profile = self.browser_config.get('profile_path', './data/firefox_profile') + '_gmail'
            if not os.path.exists(gmail_profile):
                os.makedirs(gmail_profile, exist_ok=True)
            firefox_options.add_argument(f'--profile={gmail_profile}')
        
        # Disable images for faster loading (except for Gmail)
        if not for_gmail:
            firefox_options.set_preference("permissions.default.image", 2)
        
        # Setup service
        try:
            service = Service(GeckoDriverManager().install())
        except Exception as e:
            self.logger.warning(f"Could not auto-install geckodriver: {e}")
            # Fallback to system geckodriver
            service = Service('geckodriver')
        
        # Create driver
        try:
            driver = webdriver.Firefox(service=service, options=firefox_options)
            
            # Execute anti-detection script
            driver.execute_script("""
                Object.defineProperty(navigator, 'webdriver', {
                    get: () => undefined
                });
                
                Object.defineProperty(navigator, 'languages', {
                    get: () => ['en-US', 'en']
                });
                
                Object.defineProperty(navigator, 'plugins', {
                    get: () => [1, 2, 3, 4, 5]
                });
            """)
            
            self.logger.info(f"Firefox driver created successfully (headless: {headless})")
            return driver
            
        except Exception as e:
            self.logger.error(f"Failed to create Firefox driver: {e}")
            raise
    
    def create_dat_driver(self):
        """Create driver optimized for DAT.com scraping"""
        return self.create_driver(
            headless=True,
            profile_path=self.browser_config.get('profile_path', './data/firefox_profile') + '_dat'
        )
    
    def create_gmail_driver(self):
        """Create driver optimized for Gmail automation"""
        return self.create_driver(
            headless=False,  # Gmail works better with visible browser
            for_gmail=True
        )
    
    def install_geckodriver_fedora(self):
        """Install geckodriver on Fedora systems"""
        import subprocess
        
        try:
            # Check if geckodriver is already installed
            result = subprocess.run(['which', 'geckodriver'], 
                                  capture_output=True, text=True)
            if result.returncode == 0:
                self.logger.info(f"Geckodriver already installed at: {result.stdout.strip()}")
                return True
            
            # Try to install using webdriver-manager
            try:
                driver_path = GeckoDriverManager().install()
                self.logger.info(f"Geckodriver installed via webdriver-manager: {driver_path}")
                return True
            except Exception as e:
                self.logger.warning(f"Webdriver-manager failed: {e}")
            
            # Manual installation
            self.logger.info("Attempting manual geckodriver installation...")
            subprocess.run([
                'bash', '-c',
                '''
                GECKODRIVER_VERSION=$(curl -s https://api.github.com/repos/mozilla/geckodriver/releases/latest | grep '"tag_name":' | sed -E 's/.*"([^"]+)".*/\\1/')
                wget -O /tmp/geckodriver.tar.gz "https://github.com/mozilla/geckodriver/releases/download/${GECKODRIVER_VERSION}/geckodriver-${GECKODRIVER_VERSION}-linux64.tar.gz"
                sudo tar -xzf /tmp/geckodriver.tar.gz -C /usr/local/bin/
                sudo chmod +x /usr/local/bin/geckodriver
                '''
            ], check=True)
            
            self.logger.info("Geckodriver installed successfully via manual method")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to install geckodriver: {e}")
            return False
