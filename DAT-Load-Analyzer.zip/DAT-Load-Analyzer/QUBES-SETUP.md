# DAT Load Analyzer - Qubes OS Setup Guide

## 🔒 **Why Qubes OS is PERFECT for DAT Load Analyzer**

### **Security Architecture**
```
Qubes OS (Dom0)
├── sys-firewall (NetworkVM)
├── sys-whonix (Optional - Tor networking)
├── fedora-37-template (TemplateVM)
└── dat-analyzer (AppVM) ← Your isolated workspace
    ├── Firefox WebDriver
    ├── Python Virtual Environment
    └── DAT Load Analyzer
```

### **Multi-Layer Isolation Benefits**
1. **Hardware Level**: Qubes hypervisor isolation
2. **VM Level**: AppVM isolated from other VMs and Dom0
3. **Process Level**: Python virtual environment within AppVM
4. **Network Level**: Controlled through NetVM/FirewallVM

## 🚀 **Recommended Qubes Setup**

### **Option 1: Dedicated AppVM (Recommended)**
```bash
# In Dom0:
qvm-create --class AppVM --template fedora-37 --label orange dat-analyzer
qvm-prefs dat-analyzer memory 2048
qvm-prefs dat-analyzer vcpus 2
qvm-prefs dat-analyzer netvm sys-firewall
qvm-start dat-analyzer

# In dat-analyzer VM:
cd /home/user/
git clone <your-repo> DAT-Load-Analyzer
cd DAT-Load-Analyzer
./install.sh
```

### **Option 2: High-Anonymity Setup with Whonix**
```bash
# In Dom0:
qvm-create --class AppVM --template fedora-37 --label red dat-analyzer-anon
qvm-prefs dat-analyzer-anon netvm sys-whonix
qvm-prefs dat-analyzer-anon memory 3072  # More memory for Tor
qvm-start dat-analyzer-anon

# This routes all traffic through Tor
```

### **Option 3: Air-Gapped Development (Ultra-Secure)**
```bash
# In Dom0:
qvm-create --class AppVM --template fedora-37 --label black dat-analyzer-dev
qvm-prefs dat-analyzer-dev netvm ""  # No network access
# Transfer files via qvm-copy-to-vm or USB
```

## 🔧 **Virtual Environment Benefits in Qubes**

### **Why venv is CRUCIAL in Qubes:**

#### **1. Template Protection**
```bash
# WITHOUT venv - packages go to template:
pip install selenium  # Installs to fedora-37 template
# ❌ All AppVMs based on fedora-37 now have selenium
# ❌ Template bloat affects all VMs
# ❌ Security risk if package is compromised

# WITH venv - packages stay in AppVM:
python3 -m venv venv
source venv/bin/activate
pip install selenium  # Installs only in this AppVM's venv
# ✅ Template stays clean
# ✅ Other AppVMs unaffected
# ✅ Easy to destroy if compromised
```

#### **2. Easy VM Reset**
```bash
# To completely reset your environment:
rm -rf venv           # Destroys all Python packages
./install.sh          # Fresh installation
# ✅ Clean slate in seconds
```

#### **3. Snapshot-Friendly**
```bash
# In Dom0:
qvm-clone dat-analyzer dat-analyzer-backup
# ✅ Backup includes venv state
# ✅ Can revert to working state instantly
```

## 🌐 **Network Configuration**

### **Basic Setup (sys-firewall)**
```bash
# In Dom0:
qvm-prefs dat-analyzer netvm sys-firewall
```

### **Tor Setup (sys-whonix)**
```bash
# In Dom0:
qvm-prefs dat-analyzer netvm sys-whonix
# ✅ All DAT.com traffic goes through Tor
# ⚠️ Slower but more anonymous
```

### **Custom Firewall Rules**
```bash
# In sys-firewall VM:
sudo iptables -A FORWARD -s <dat-analyzer-ip> -d dat.com -j ACCEPT
sudo iptables -A FORWARD -s <dat-analyzer-ip> -d gmail.com -j ACCEPT
sudo iptables -A FORWARD -s <dat-analyzer-ip> -j DROP
# ✅ Only allows DAT.com and Gmail traffic
```

## 📱 **VM Resource Optimization**

### **Recommended VM Settings:**
```bash
# In Dom0:
qvm-prefs dat-analyzer memory 2048      # 2GB RAM
qvm-prefs dat-analyzer vcpus 2          # 2 CPU cores  
qvm-prefs dat-analyzer maxmem 4096      # Max 4GB if needed
```

### **For Heavy Scraping:**
```bash
qvm-prefs dat-analyzer memory 4096      # 4GB RAM
qvm-prefs dat-analyzer vcpus 4          # 4 CPU cores
```

## 🔐 **Security Best Practices**

### **1. Data Isolation**
```
dat-analyzer VM contains:
├── /home/user/DAT-Load-Analyzer/
│   ├── venv/                    # Python packages (isolated)
│   ├── data/logs/              # Log files (persistent)
│   ├── config.yaml             # Credentials (VM-local)
│   └── scraped_data.db         # DAT data (isolated)
```

### **2. Credential Security**
- ✅ Config files stay in AppVM (never in template)
- ✅ Browser profiles isolated per VM
- ✅ No credential leakage to other VMs

### **3. Browser Isolation**
```bash
# Firefox runs in AppVM with:
# ✅ Separate profile from other VMs
# ✅ No access to Dom0 or other VMs
# ✅ Network controlled by NetVM
```

## 🚨 **Troubleshooting Qubes Issues**

### **VM Won't Start**
```bash
# In Dom0:
qvm-start dat-analyzer --debug
journalctl -f  # Check logs
```

### **No Internet Access**
```bash
# Check network assignment:
qvm-prefs dat-analyzer netvm

# Reset network:
qvm-prefs dat-analyzer netvm ""
qvm-prefs dat-analyzer netvm sys-firewall
```

### **Memory Issues**
```bash
# Increase memory:
qvm-prefs dat-analyzer memory 4096

# Check current usage:
qvm-top
```

### **Firefox/Selenium Issues**
```bash
# In dat-analyzer VM:
# Check if running in Qubes:
ls /usr/bin/qvm-*

# Test Firefox:
firefox --version
geckodriver --version

# Test in headless mode:
export DISPLAY=:0.0
firefox --headless &
```

## 💡 **Why This Setup is Optimal**

### **For Security:**
- 🔒 **VM isolation**: DAT scraper can't access other VMs
- 🔒 **Network control**: Traffic routing through controlled NetVM
- 🔒 **Process isolation**: Python venv adds another layer
- 🔒 **Template protection**: System stays clean

### **For Development:**
- 🚀 **Easy reset**: Destroy and recreate VM quickly
- 🚀 **Snapshots**: Backup working states
- 🚀 **Testing**: Clone VMs for testing changes
- 🚀 **Isolation**: No interference with other projects

### **For Anonymity:**
- 🕵️ **Tor integration**: Route through sys-whonix
- 🕵️ **MAC randomization**: Built into Qubes
- 🕵️ **No persistence**: Data isolated to AppVM
- 🕵️ **Traffic analysis protection**: NetVM layer

## 🎯 **Quick Start Commands**

```bash
# In Dom0 (create and configure VM):
qvm-create --class AppVM --template fedora-37 --label orange dat-analyzer
qvm-prefs dat-analyzer memory 2048
qvm-prefs dat-analyzer netvm sys-firewall
qvm-start dat-analyzer

# In dat-analyzer VM (install and run):
cd /home/user/
git clone <repo> DAT-Load-Analyzer
cd DAT-Load-Analyzer
./install.sh              # Creates venv automatically
source venv/bin/activate   # Enter isolated environment
./run.sh                   # Start the analyzer
```

**Result: Perfect security, isolation, and functionality for DAT load analysis!** 🎉
