#!/bin/bash
# DAT Load Analyzer - Installation Script for Fedora/QubesOS
# This script installs all dependencies and sets up the DAT Load Analyzer

set -e  # Exit on any error

echo "🚛 DAT Load Analyzer - Fedora/QubesOS Installation"
echo "=================================================="

# Check if running on Fedora
if [ ! -f /etc/fedora-release ]; then
    echo "⚠️  Warning: This script is designed for Fedora/QubesOS"
    echo "   It may work on other RPM-based distributions"
    read -p "   Continue anyway? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "❌ Installation cancelled"
        exit 1
    fi
fi

# Update system
echo "📦 Updating system packages..."
sudo dnf update -y

# Install Python and development tools
echo "🐍 Installing Python and development tools..."
sudo dnf install -y python3 python3-pip python3-devel git wget curl

# Install system dependencies for Chrome/Chromium
echo "🌐 Installing browser dependencies..."
sudo dnf install -y chromium chromium-common

# Install additional system libraries
echo "📚 Installing system libraries..."
sudo dnf install -y \
    gcc \
    gcc-c++ \
    sqlite \
    sqlite-devel \
    libffi-devel \
    openssl-devel \
    libjpeg-devel \
    zlib-devel \
    freetype-devel \
    lcms2-devel \
    openjpeg2-devel \
    libtiff-devel \
    tk-devel \
    tcl-devel

# Create virtual environment
echo "🔧 Creating Python virtual environment..."
python3 -m venv venv
source venv/bin/activate

# Upgrade pip
echo "⬆️  Upgrading pip..."
pip install --upgrade pip setuptools wheel

# Install Python dependencies
echo "📦 Installing Python packages..."
pip install -r requirements.txt

# Download ChromeDriver
echo "🚗 Setting up ChromeDriver..."
CHROME_VERSION=$(chromium --version | grep -oP '\d+\.\d+\.\d+')
echo "   Detected Chromium version: $CHROME_VERSION"

# Create drivers directory
mkdir -p drivers

# Download compatible ChromeDriver
CHROMEDRIVER_VERSION=$(curl -s "https://chromedriver.storage.googleapis.com/LATEST_RELEASE_${CHROME_VERSION%%.*}")
wget -O drivers/chromedriver.zip "https://chromedriver.storage.googleapis.com/${CHROMEDRIVER_VERSION}/chromedriver_linux64.zip"

# Extract and setup ChromeDriver
cd drivers
unzip -o chromedriver.zip
chmod +x chromedriver
cd ..

# Create data directories
echo "📁 Creating data directories..."
mkdir -p data/logs
mkdir -p data/backups

# Initialize database
echo "🗄️  Initializing database..."
python3 -c "
import sqlite3
import sys
import os

# Add project root to path
sys.path.append(os.path.dirname(os.path.abspath('.')))

try:
    from scraper.dat_scraper import DATScraper
    scraper = DATScraper()
    scraper.init_database()
    print('✅ Database initialized successfully')
except Exception as e:
    print(f'❌ Database initialization failed: {e}')
    sys.exit(1)
"

# Create desktop shortcut
echo "🖥️  Creating desktop shortcut..."
DESKTOP_FILE="$HOME/Desktop/DAT-Load-Analyzer.desktop"
cat > "$DESKTOP_FILE" << EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=DAT Load Analyzer
Comment=DAT Load Analyzer Dashboard
Exec=bash $(pwd)/run.sh
Icon=$(pwd)/icons/icon.png
Terminal=false
Categories=Office;
EOF

chmod +x "$DESKTOP_FILE"

# Create systemd service for background monitoring (optional)
echo "🔄 Creating systemd service..."
SERVICE_FILE="$HOME/.config/systemd/user/dat-load-analyzer.service"
mkdir -p "$HOME/.config/systemd/user"

cat > "$SERVICE_FILE" << EOF
[Unit]
Description=DAT Load Analyzer Background Monitor
After=network.target

[Service]
Type=simple
WorkingDirectory=$(pwd)
Environment=PATH=$(pwd)/venv/bin:\$PATH
ExecStart=$(pwd)/venv/bin/python main.py
Restart=always
RestartSec=10

[Install]
WantedBy=default.target
EOF

# Enable but don't start the service
systemctl --user daemon-reload
systemctl --user enable dat-load-analyzer.service

# Create firewall rules (if needed)
echo "🔥 Configuring firewall..."
if command -v firewall-cmd &> /dev/null; then
    # Allow Streamlit port (8501)
    sudo firewall-cmd --permanent --add-port=8501/tcp
    sudo firewall-cmd --reload
    echo "   Streamlit port 8501 opened"
fi

# Final setup
echo "⚙️  Final setup..."

# Create config template if it doesn't exist
if [ ! -f config.yaml ]; then
    echo "📝 Creating config template..."
    cat > config.yaml << 'EOF'
# DAT Load Analyzer Configuration
# Please update with your credentials

dat_login:
  username: "your_dat_username"
  password: "your_dat_password"
  
email:
  gmail_username: "your_email@gmail.com"
  
monitoring:
  scan_interval: 30
  max_loads_per_scan: 100
  
rates:
  min_rate_per_mile: 1.5
  preferred_equipment: ["Van", "Reefer"]
  
alerts:
  profit_threshold: 7.0
  email_notifications: true
  desktop_notifications: true
  sound_notifications: false

dashboard:
  auto_refresh: true
  refresh_interval: 60
EOF
fi

echo ""
echo "✅ Installation completed successfully!"
echo ""
echo "📋 Next Steps:"
echo "   1. Edit config.yaml with your DAT.com and Gmail credentials"
echo "   2. Run './run.sh' to start the application"
echo "   3. Or run 'streamlit run dashboard/app.py' for dashboard only"
echo ""
echo "🔧 System Service:"
echo "   • Start: systemctl --user start dat-load-analyzer"
echo "   • Stop:  systemctl --user stop dat-load-analyzer"
echo "   • Logs:  journalctl --user -u dat-load-analyzer -f"
echo ""
echo "🌐 Dashboard will be available at: http://localhost:8501"
echo ""
echo "⚠️  Important:"
echo "   • Configure your credentials in config.yaml before first use"
echo "   • Ensure you have a valid DAT.com account"
echo "   • Gmail automation requires app-specific password (not regular password)"
echo ""
