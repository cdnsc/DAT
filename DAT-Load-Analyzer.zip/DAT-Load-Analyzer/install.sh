#!/bin/bash
# DAT Load Analyzer - Fedora Installation Script

echo "🚛 Installing DAT Load Analyzer on Fedora..."
echo "============================================"

# Update system
echo "📦 Updating system packages..."
sudo dnf update -y

# Install Python and pip
echo "🐍 Installing Python and development tools..."
sudo dnf install -y python3 python3-pip python3-devel

# Install Firefox for Selenium
echo "🦊 Installing Firefox browser and geckodriver..."
sudo dnf install -y firefox

# Verify Firefox installation
if ! command -v firefox &> /dev/null; then
    echo "❌ Firefox installation failed"
    exit 1
fi
echo "✅ Firefox installed: $(firefox --version)"

# Install geckodriver for Firefox
echo "🔧 Installing geckodriver..."
# Try system package first
sudo dnf install -y mozilla-geckodriver || {
    echo "📦 System geckodriver not available, installing manually..."
    # Get latest geckodriver
    GECKODRIVER_VERSION=$(curl -s https://api.github.com/repos/mozilla/geckodriver/releases/latest | grep '"tag_name":' | sed -E 's/.*"([^"]+)".*/\1/')
    wget -O /tmp/geckodriver.tar.gz "https://github.com/mozilla/geckodriver/releases/download/${GECKODRIVER_VERSION}/geckodriver-${GECKODRIVER_VERSION}-linux64.tar.gz"
    sudo tar -xzf /tmp/geckodriver.tar.gz -C /usr/local/bin/
    sudo chmod +x /usr/local/bin/geckodriver
    rm -f /tmp/geckodriver.tar.gz
}

# Verify geckodriver installation
if ! command -v geckodriver &> /dev/null; then
    echo "❌ Geckodriver installation failed"
    exit 1
fi
echo "✅ Geckodriver installed: $(geckodriver --version | head -1)"

# Install system dependencies for Python packages
echo "🔧 Installing system dependencies..."
sudo dnf install -y \
    gcc \
    gcc-c++ \
    python3-tkinter \
    libffi-devel \
    openssl-devel \
    sqlite \
    sqlite-devel \
    alsa-lib-devel \
    portaudio-devel

# Install notification dependencies
sudo dnf install -y \
    libnotify \
    libnotify-devel \
    dbus-python3

# Create virtual environment
echo "🔒 Creating Python virtual environment..."
cd "$(dirname "$0")"
python3 -m venv venv
source venv/bin/activate

# Upgrade pip
echo "⬆️ Upgrading pip..."
pip install --upgrade pip setuptools wheel

# Install Python packages
echo "📚 Installing Python packages..."
pip install selenium==4.15.0
pip install beautifulsoup4==4.12.0
pip install pandas==2.0.3
pip install streamlit==1.28.0
pip install plotly==5.17.0
pip install PyYAML==6.0.1
pip install requests==2.31.0
pip install python-dateutil==2.8.2
pip install webdriver-manager==4.0.1
pip install schedule==1.2.0

# Try to install plyer for notifications
echo "🔔 Installing notification support..."
pip install plyer || echo "⚠️ plyer installation failed - notifications may not work"

# Create desktop entry (optional)
echo "🖥️ Creating desktop entry..."
cat > ~/.local/share/applications/dat-load-analyzer.desktop << EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=DAT Load Analyzer
Comment=Real-time DAT.com load board analyzer
Exec=$(pwd)/run.sh
Icon=applications-internet
Terminal=true
Categories=Network;Office;
EOF

# Make scripts executable
chmod +x run.sh
chmod +x install.sh

echo ""
echo "✅ Installation completed successfully!"
echo ""
echo "📋 Next steps:"
echo "1. Edit config.yaml with your DAT.com and Gmail credentials"
echo "2. Run: ./run.sh"
echo "3. Or start dashboard: streamlit run dashboard/app.py"
echo ""
echo "📁 Project directory: $(pwd)"
echo "🔗 Firefox driver: $(which geckodriver || echo 'Not found - may need manual installation')"
echo ""
echo "🎯 Ready to analyze DAT loads!"
