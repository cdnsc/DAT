#!/bin/bash
# DAT Load Analyzer - Fedora Installation Script (Qubes OS Optimized)

echo "🚛 Installing DAT Load Analyzer on Fedora (Qubes OS)..."
echo "======================================================="

# Detect if running in Qubes VM
if [ -f /usr/bin/qvm-check ] || [ -n "$QUBES_ENV" ] || [ -f /etc/qubes-release ]; then
    log_info "🔒 Qubes OS environment detected"
    QUBES_VM=true
    # Get current VM name if possible
    if command -v qubesdb-read >/dev/null 2>&1; then
        VM_NAME=$(qubesdb-read /name 2>/dev/null || echo "unknown")
        log_info "📱 Running in VM: $VM_NAME"
    fi
else
    QUBES_VM=false
fi

# Qubes-specific optimizations
if [ "$QUBES_VM" = true ]; then
    log_info "🔧 Applying Qubes OS optimizations..."
    
    # Check if this is a template or AppVM
    if [ -f /var/lib/qubes/protected-files ]; then
        log_warning "⚠️ Running in TemplateVM - changes will affect all AppVMs based on this template"
        echo "   Consider running this in an AppVM instead for isolation"
        read -p "   Continue anyway? (y/N): " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            log_info "Installation cancelled. Run this script in an AppVM for better isolation."
            exit 0
        fi
    else
        log_success "✅ Running in AppVM - perfect for isolated installation"
    fi
    
    # Qubes networking check
    if ! ping -c 1 google.com >/dev/null 2>&1; then
        log_error "No internet connection. Make sure the VM has network access:"
        log_info "1. In Dom0: qvm-prefs YOUR_VM_NAME netvm sys-firewall"
        log_info "2. Or use Qubes Manager to enable networking"
        exit 1
    fi
fi

# Error handling functions
log_error() {
    echo "❌ Error: $1" >&2
}

log_success() {
    echo "✅ $1"
}

log_warning() {
    echo "⚠️ Warning: $1"
}

log_info() {
    echo "ℹ️ $1"
}

# Function to check if a command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Function to safely download files
safe_download() {
    local url="$1"
    local output="$2"
    local max_attempts=3
    local attempt=1
    
    while [ $attempt -le $max_attempts ]; do
        log_info "Download attempt $attempt/$max_attempts: $url"
        if wget -O "$output" "$url"; then
            if [ -s "$output" ]; then
                log_success "Download successful"
                return 0
            else
                log_error "Downloaded file is empty"
                rm -f "$output"
            fi
        else
            log_error "Download failed"
        fi
        
        attempt=$((attempt + 1))
        if [ $attempt -le $max_attempts ]; then
            log_info "Retrying in 3 seconds..."
            sleep 3
        fi
    done
    
    return 1
}

# Check for corrupted virtual environment and clean up
echo "🧹 Checking for corrupted installations..."
cd "$(dirname "$0")"

if [ -d "venv" ]; then
    # Check if virtual environment is corrupted (pip not working)
    if [ ! -f "venv/bin/pip" ] || [ ! -f "venv/bin/activate" ]; then
        echo "🗑️ Found corrupted virtual environment. Cleaning up..."
        rm -rf venv
        echo "✅ Corrupted virtual environment removed"
    else
        # Test if pip works
        if ! venv/bin/pip --version &> /dev/null; then
            echo "🗑️ Virtual environment pip is not working. Cleaning up..."
            rm -rf venv
            echo "✅ Corrupted virtual environment removed"
        else
            echo "♻️ Existing virtual environment appears to be working"
        fi
    fi
fi

# Update system
echo "📦 Updating system packages..."
sudo dnf update -y

# Install Python and pip
echo "🐍 Installing Python and development tools..."
sudo dnf install -y python3 python3-pip python3-devel

# Install Firefox for Selenium
echo "🦊 Installing Firefox browser and geckodriver..."
sudo dnf install -y firefox

# Verify Firefox installation
if ! command -v firefox &> /dev/null; then
    echo "❌ Firefox installation failed"
    exit 1
fi
echo "✅ Firefox installed: $(firefox --version)"

# Install geckodriver for Firefox
echo "🔧 Installing geckodriver..."

# Try system package first
sudo dnf install -y mozilla-geckodriver || {
    echo "📦 System geckodriver not available, installing manually..."
    
    # Get latest geckodriver version with better error handling
    echo "🔍 Getting latest geckodriver version..."
    
    # Try to get version from GitHub API
    GECKODRIVER_VERSION=$(curl -s https://api.github.com/repos/mozilla/geckodriver/releases/latest | grep '"tag_name":' | sed -E 's/.*"([^"]+)".*/\1/' | head -1)
    
    # Debug: show what we got
    echo "🐛 Debug: API returned version: '$GECKODRIVER_VERSION'"
    
    # Fallback to known working version if API fails
    if [ -z "$GECKODRIVER_VERSION" ] || [ "$GECKODRIVER_VERSION" = "null" ] || [ "$GECKODRIVER_VERSION" = "" ]; then
        log_warning "Failed to get latest version from GitHub API, using fallback version..."
        GECKODRIVER_VERSION="v0.33.0"
    fi
    
    log_info "Using geckodriver version: $GECKODRIVER_VERSION"
    
    echo "📥 Downloading geckodriver version: $GECKODRIVER_VERSION"
    
    # Download with error checking using safe_download function
    DOWNLOAD_URL="https://github.com/mozilla/geckodriver/releases/download/${GECKODRIVER_VERSION}/geckodriver-${GECKODRIVER_VERSION}-linux64.tar.gz"
    echo "🌐 Download URL: $DOWNLOAD_URL"
    
    if safe_download "$DOWNLOAD_URL" "/tmp/geckodriver.tar.gz"; then
        echo "📦 Extracting geckodriver..."
        if sudo tar -xzf /tmp/geckodriver.tar.gz -C /usr/local/bin/ && \
           sudo chmod +x /usr/local/bin/geckodriver; then
            rm -f /tmp/geckodriver.tar.gz
            log_success "Geckodriver extracted and installed"
        else
            log_error "Failed to extract geckodriver"
            rm -f /tmp/geckodriver.tar.gz
            exit 1
        fi
    else
        log_error "Download failed after multiple attempts. Trying alternative installation..."
        
        # Try alternative: install via Python webdriver-manager
        echo "🐍 Installing geckodriver via Python webdriver-manager..."
        python3 -m pip install webdriver-manager
        python3 -c "
from webdriver_manager.firefox import GeckoDriverManager
import shutil
import os

# Download and get geckodriver path
driver_path = GeckoDriverManager().install()
print(f'Downloaded to: {driver_path}')

# Copy to system location
if os.path.exists(driver_path):
    shutil.copy2(driver_path, '/usr/local/bin/geckodriver')
    os.chmod('/usr/local/bin/geckodriver', 0o755)
    print('✅ Geckodriver installed via webdriver-manager')
else:
    print('❌ Webdriver-manager installation failed')
    exit(1)
        "
    fi
}

# Verify geckodriver installation
echo "🔍 Verifying geckodriver installation..."
if command -v geckodriver &> /dev/null; then
    GECKODRIVER_INSTALLED_VERSION=$(geckodriver --version | head -1)
    echo "✅ Geckodriver installed: $GECKODRIVER_INSTALLED_VERSION"
else
    echo "❌ Geckodriver installation failed"
    echo "🔧 Attempting final fallback installation..."
    
    # Final fallback: try to download a specific working version
    log_info "Trying fallback geckodriver v0.33.0..."
    if safe_download "https://github.com/mozilla/geckodriver/releases/download/v0.33.0/geckodriver-v0.33.0-linux64.tar.gz" "/tmp/geckodriver.tar.gz" && \
       sudo tar -xzf /tmp/geckodriver.tar.gz -C /usr/local/bin/ && \
       sudo chmod +x /usr/local/bin/geckodriver; then
        rm -f /tmp/geckodriver.tar.gz
        log_success "Fallback geckodriver installation successful"
    else
        log_error "All geckodriver installation methods failed"
        log_warning "You may need to install geckodriver manually"
        log_info "The Python webdriver-manager package will handle this automatically when running the application"
        rm -f /tmp/geckodriver.tar.gz
fi

# Install system dependencies for Python packages
echo "🔧 Installing system dependencies..."
sudo dnf install -y \
    gcc \
    gcc-c++ \
    python3-tkinter \
    libffi-devel \
    openssl-devel \
    sqlite \
    sqlite-devel \
    alsa-lib-devel \
    portaudio-devel

# Install notification dependencies
sudo dnf install -y \
    libnotify \
    libnotify-devel \
    dbus-python3

# Create virtual environment
echo "🔒 Creating Python virtual environment..."
cd "$(dirname "$0")"

# Remove existing virtual environment if it exists and is corrupted
if [ -d "venv" ] && [ ! -f "venv/bin/activate" ]; then
    echo "🗑️ Removing corrupted virtual environment..."
    rm -rf venv
fi

# Create fresh virtual environment
if [ ! -d "venv" ]; then
    echo "🆕 Creating new virtual environment..."
    python3 -m venv venv
else
    echo "♻️ Using existing virtual environment..."
fi

# Activate virtual environment
echo "🔓 Activating virtual environment..."
source venv/bin/activate

# Verify pip is working
if [ ! -f "venv/bin/pip" ]; then
    echo "❌ Error: pip not found in virtual environment"
    echo "🔄 Recreating virtual environment..."
    rm -rf venv
    python3 -m venv venv
    source venv/bin/activate
fi

# Upgrade pip
echo "⬆️ Upgrading pip..."
if ! pip install --upgrade pip setuptools wheel; then
    echo "❌ Error upgrading pip. Trying alternative method..."
    python3 -m pip install --upgrade pip setuptools wheel
fi

# Verify pip is working
echo "🔍 Verifying pip installation..."
pip --version || {
    echo "❌ Error: pip is not working properly"
    exit 1
}

# Install Python packages
echo "📚 Installing Python packages..."

# Function to install package with error handling
install_package() {
    local package=$1
    echo "📦 Installing $package..."
    if ! pip install "$package"; then
        echo "❌ Failed to install $package. Trying with --user flag..."
        if ! pip install --user "$package"; then
            echo "❌ Failed to install $package with --user. Continuing..."
            return 1
        fi
    fi
    return 0
}

# Install packages one by one with error handling
install_package "selenium==4.15.0"
install_package "beautifulsoup4==4.12.0"
install_package "pandas==2.0.3"
install_package "streamlit==1.28.0"
install_package "plotly==5.17.0"
install_package "PyYAML==6.0.1"
install_package "requests==2.31.0"
install_package "python-dateutil==2.8.2"
install_package "webdriver-manager==4.0.1"
install_package "schedule==1.2.0"

# Try to install plyer for notifications
echo "🔔 Installing notification support..."
install_package "plyer" || echo "⚠️ plyer installation failed - notifications may not work"

# Create desktop entry (optional)
echo "🖥️ Creating desktop entry..."
cat > ~/.local/share/applications/dat-load-analyzer.desktop << EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=DAT Load Analyzer
Comment=Real-time DAT.com load board analyzer
Exec=$(pwd)/run.sh
Icon=applications-internet
Terminal=true
Categories=Network;Office;
EOF

# Make scripts executable
chmod +x run.sh
chmod +x install.sh

echo ""
echo "✅ Installation completed successfully!"
echo ""

# Qubes-specific post-installation advice
if [ "$QUBES_VM" = true ]; then
    echo "� Qubes OS Specific Recommendations:"
    echo "======================================"
    echo ""
    echo "🔧 VM Configuration:"
    echo "• Consider increasing VM memory: qvm-prefs $VM_NAME memory 2048"
    echo "• For better performance: qvm-prefs $VM_NAME vcpus 2"
    echo "• If scraping fails: qvm-prefs $VM_NAME kernelopts 'nopat iommu=soft'"
    echo ""
    echo "🌐 Network Isolation Options:"
    echo "• Dedicated network VM: qvm-create --class AppVM --template fedora-37 dat-netvm"
    echo "• Route through Whonix: qvm-prefs $VM_NAME netvm sys-whonix"
    echo "• Or use sys-firewall with custom rules"
    echo ""
    echo "💾 Data Persistence:"
    echo "• Logs are stored in: $(pwd)/data/logs/"
    echo "• Configuration: $(pwd)/config.yaml"
    echo "• Virtual environment: $(pwd)/venv/"
    echo "• All data stays in this AppVM - no persistence in TemplateVM"
    echo ""
    echo "🔐 Security Benefits of venv in Qubes:"
    echo "• Double isolation: VM + Python environment"
    echo "• Easy cleanup: rm -rf venv destroys all Python packages"
    echo "• No template contamination"
    echo "• Separate from system Python packages"
    echo ""
fi

echo "�📋 Next steps:"
echo "1. Edit config.yaml with your DAT.com and Gmail credentials"
echo "2. Run: ./run.sh"
echo "3. Or start dashboard: streamlit run dashboard/app.py"
echo ""
echo "📁 Project directory: $(pwd)"
echo "🔗 Firefox driver: $(which geckodriver || echo 'Not found - may need manual installation')"

if [ "$QUBES_VM" = true ]; then
    echo "🔒 VM: $VM_NAME (Qubes OS)"
fi

echo ""
echo "🎯 Ready to analyze DAT loads!"
