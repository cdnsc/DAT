// options.js - Enterprise DAT Speed Extension Configuration Controller
// Handles saving, loading, and managing all extension settings

// Firefox compatibility
const browser_api = chrome || browser;

class DATSpeedOptions {
  constructor() {
    this.initializeEventListeners();
    this.loadSettings();
    this.setupTabs();
  }

  initializeEventListeners() {
    // Form submission
    document.getElementById('settings-form').addEventListener('submit', (e) => {
      e.preventDefault();
      this.saveAllSettings();
    });

    // Reset settings
    document.getElementById('reset-settings').addEventListener('click', () => {
      this.resetToDefaults();
    });

    // Export/Import settings
    document.getElementById('export-settings').addEventListener('click', () => {
      this.exportSettings();
    });

    document.getElementById('import-settings').addEventListener('click', () => {
      this.importSettings();
    });

    // Template management
    document.getElementById('add-template').addEventListener('click', () => {
      this.addTemplate();
    });

    // AI confidence slider
    const confidenceSlider = document.getElementById('ai-confidence');
    const confidenceValue = document.getElementById('confidence-value');
    
    confidenceSlider.addEventListener('input', (e) => {
      confidenceValue.textContent = e.target.value + '%';
    });

    // Real-time validation
    this.setupValidation();
  }

  setupTabs() {
    const tabs = document.querySelectorAll('.tab');
    const tabContents = document.querySelectorAll('.tab-content');

    tabs.forEach(tab => {
      tab.addEventListener('click', () => {
        // Remove active class from all tabs and contents
        tabs.forEach(t => t.classList.remove('active'));
        tabContents.forEach(tc => tc.classList.remove('active'));

        // Add active class to clicked tab
        tab.classList.add('active');
        
        // Show corresponding content
        const targetContent = document.getElementById(tab.dataset.tab);
        if (targetContent) {
          targetContent.classList.add('active');
        }
      });
    });
  }

  async loadSettings() {
    try {
      const settings = await this.getStorageValue('extensionSettings', this.getDefaultSettings());
      this.populateForm(settings);
    } catch (error) {
      console.error('Error loading settings:', error);
      this.showStatus('Error loading settings', 'error');
    }
  }

  populateForm(settings) {
    // Load filters
    document.getElementById('min-rate').value = settings.filters.minRate || '';
    document.getElementById('max-dho').value = settings.filters.maxDHO || '';
    document.getElementById('max-miles').value = settings.filters.maxMiles || '';
    document.getElementById('min-weight').value = settings.filters.minWeight || '';
    document.getElementById('origin-states').value = settings.filters.originStates.join(', ');
    document.getElementById('dest-states').value = settings.filters.destStates.join(', ');
    
    // Equipment types
    const equipmentSelect = document.getElementById('equipment-types');
    Array.from(equipmentSelect.options).forEach(option => {
      option.selected = settings.filters.equipmentTypes.includes(option.value);
    });

    // AI settings
    document.getElementById('ai-scoring').checked = settings.ai.enabled;
    document.getElementById('auto-monitor').checked = settings.ai.autoMonitor;
    document.getElementById('auto-booking').checked = settings.ai.autoBooking;
    document.getElementById('ai-confidence').value = settings.ai.confidenceThreshold;
    document.getElementById('confidence-value').textContent = settings.ai.confidenceThreshold + '%';

    // Profit analysis
    document.getElementById('fuel-cost').value = settings.profit.fuelCost || '';
    document.getElementById('truck-mpg').value = settings.profit.truckMPG || '';
    document.getElementById('driver-pay').value = settings.profit.driverPay || '';
    document.getElementById('other-costs').value = settings.profit.otherCosts || '';

    // Analytics
    document.getElementById('track-performance').checked = settings.analytics.trackPerformance;
    document.getElementById('market-analysis').checked = settings.analytics.marketAnalysis;
    document.getElementById('data-retention').value = settings.analytics.dataRetention;

    // Alerts
    document.getElementById('desktop-notifications').checked = settings.alerts.desktop;
    document.getElementById('sound-alerts').checked = settings.alerts.sound;
    document.getElementById('alert-frequency').value = settings.alerts.frequency;

    // Enterprise
    document.getElementById('crm-integration').value = settings.enterprise.crmIntegration || '';
    document.getElementById('api-key').value = settings.enterprise.apiKey || '';
    document.getElementById('multi-user').checked = settings.enterprise.multiUser;
    document.getElementById('company-name').value = settings.enterprise.companyName || '';

    // Load templates
    this.loadTemplates(settings.templates);
  }

  async saveAllSettings() {
    try {
      const settings = this.collectFormData();
      await browser_api.storage.sync.set({ extensionSettings: settings });
      
      // Notify content scripts and service worker of settings change
      browser_api.runtime.sendMessage({
        action: 'settingsUpdated',
        settings: settings
      });

      this.showStatus('Settings saved successfully!', 'success');
    } catch (error) {
      console.error('Error saving settings:', error);
      this.showStatus('Error saving settings', 'error');
    }
  }

  collectFormData() {
    return {
      filters: {
        minRate: parseFloat(document.getElementById('min-rate').value) || 0,
        maxDHO: parseInt(document.getElementById('max-dho').value) || 999,
        maxMiles: parseInt(document.getElementById('max-miles').value) || 999999,
        minWeight: parseInt(document.getElementById('min-weight').value) || 0,
        originStates: this.parseStates(document.getElementById('origin-states').value),
        destStates: this.parseStates(document.getElementById('dest-states').value),
        equipmentTypes: Array.from(document.getElementById('equipment-types').selectedOptions)
          .map(option => option.value)
      },
      ai: {
        enabled: document.getElementById('ai-scoring').checked,
        autoMonitor: document.getElementById('auto-monitor').checked,
        autoBooking: document.getElementById('auto-booking').checked,
        confidenceThreshold: parseInt(document.getElementById('ai-confidence').value)
      },
      profit: {
        fuelCost: parseFloat(document.getElementById('fuel-cost').value) || 3.50,
        truckMPG: parseFloat(document.getElementById('truck-mpg').value) || 6.5,
        driverPay: parseFloat(document.getElementById('driver-pay').value) || 0.55,
        otherCosts: parseFloat(document.getElementById('other-costs').value) || 0.40
      },
      analytics: {
        trackPerformance: document.getElementById('track-performance').checked,
        marketAnalysis: document.getElementById('market-analysis').checked,
        dataRetention: parseInt(document.getElementById('data-retention').value)
      },
      alerts: {
        desktop: document.getElementById('desktop-notifications').checked,
        sound: document.getElementById('sound-alerts').checked,
        frequency: parseInt(document.getElementById('alert-frequency').value)
      },
      enterprise: {
        crmIntegration: document.getElementById('crm-integration').value,
        apiKey: document.getElementById('api-key').value,
        multiUser: document.getElementById('multi-user').checked,
        companyName: document.getElementById('company-name').value
      },
      templates: this.collectTemplates()
    };
  }

  parseStates(stateString) {
    return stateString.split(',')
      .map(state => state.trim().toUpperCase())
      .filter(state => state.length > 0);
  }

  loadTemplates(templates) {
    const templateList = document.getElementById('template-list');
    templateList.innerHTML = '';

    templates.forEach((template, index) => {
      const templateDiv = document.createElement('div');
      templateDiv.className = 'template-item';
      templateDiv.innerHTML = `
        <div class="template-header">
          <div class="template-name">${template.name}</div>
          <div class="template-actions">
            <button type="button" class="btn btn-small" onclick="options.editTemplate(${index})">Edit</button>
            <button type="button" class="btn btn-secondary btn-small" onclick="options.deleteTemplate(${index})">Delete</button>
          </div>
        </div>
        <textarea readonly>${template.content}</textarea>
      `;
      templateList.appendChild(templateDiv);
    });
  }

  collectTemplates() {
    const templates = [];
    const templateItems = document.querySelectorAll('.template-item');
    
    templateItems.forEach(item => {
      const name = item.querySelector('.template-name').textContent;
      const content = item.querySelector('textarea').value;
      templates.push({ name, content });
    });

    return templates;
  }

  addTemplate() {
    const name = prompt('Template name:');
    if (!name) return;
    
    const content = prompt('Template content (use {origin}, {destination}, {rate} as placeholders):');
    if (!content) return;

    const templateList = document.getElementById('template-list');
    const templateDiv = document.createElement('div');
    templateDiv.className = 'template-item';
    templateDiv.innerHTML = `
      <div class="template-header">
        <div class="template-name">${name}</div>
        <div class="template-actions">
          <button type="button" class="btn btn-small" onclick="options.editTemplate()">Edit</button>
          <button type="button" class="btn btn-secondary btn-small" onclick="options.deleteTemplate()">Delete</button>
        </div>
      </div>
      <textarea readonly>${content}</textarea>
    `;
    templateList.appendChild(templateDiv);
  }

  editTemplate(index) {
    const templateItems = document.querySelectorAll('.template-item');
    const template = templateItems[index];
    const textarea = template.querySelector('textarea');
    
    if (textarea.hasAttribute('readonly')) {
      textarea.removeAttribute('readonly');
      textarea.focus();
    } else {
      textarea.setAttribute('readonly', true);
    }
  }

  deleteTemplate(index) {
    if (confirm('Are you sure you want to delete this template?')) {
      const templateItems = document.querySelectorAll('.template-item');
      templateItems[index].remove();
    }
  }

  async resetToDefaults() {
    if (confirm('Are you sure you want to reset all settings to defaults? This cannot be undone.')) {
      const defaults = this.getDefaultSettings();
      await browser_api.storage.sync.set({ extensionSettings: defaults });
      this.populateForm(defaults);
      this.showStatus('Settings reset to defaults', 'success');
    }
  }

  exportSettings() {
    const settings = this.collectFormData();
    const dataStr = JSON.stringify(settings, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    
    const link = document.createElement('a');
    link.href = URL.createObjectURL(dataBlob);
    link.download = 'dat-speed-settings.json';
    link.click();
  }

  importSettings() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    
    input.onchange = (e) => {
      const file = e.target.files[0];
      if (!file) return;
      
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const settings = JSON.parse(e.target.result);
          this.populateForm(settings);
          this.showStatus('Settings imported successfully', 'success');
        } catch (error) {
          this.showStatus('Error importing settings: Invalid file format', 'error');
        }
      };
      reader.readAsText(file);
    };
    
    input.click();
  }

  setupValidation() {
    // Validate numeric inputs
    const numericInputs = document.querySelectorAll('input[type="number"]');
    numericInputs.forEach(input => {
      input.addEventListener('blur', () => {
        if (input.value && isNaN(parseFloat(input.value))) {
          input.style.borderColor = '#e53935';
          this.showStatus('Please enter a valid number', 'error');
        } else {
          input.style.borderColor = '#e0e0e0';
        }
      });
    });
  }

  showStatus(message, type) {
    const statusDiv = document.getElementById('status-message');
    statusDiv.textContent = message;
    statusDiv.className = `status-message status-${type}`;
    statusDiv.style.display = 'block';
    
    setTimeout(() => {
      statusDiv.style.display = 'none';
    }, 5000);
  }

  getDefaultSettings() {
    return {
      filters: {
        minRate: 2.50,
        maxDHO: 50,
        maxMiles: 500,
        minWeight: 1000,
        originStates: ['TX', 'CA', 'FL', 'GA'],
        destStates: ['TX', 'CA', 'FL', 'GA'],
        equipmentTypes: ['V', 'R', 'F']
      },
      ai: {
        enabled: true,
        autoMonitor: false,
        autoBooking: false,
        confidenceThreshold: 80
      },
      profit: {
        fuelCost: 3.50,
        truckMPG: 6.5,
        driverPay: 0.55,
        otherCosts: 0.40
      },
      analytics: {
        trackPerformance: true,
        marketAnalysis: true,
        dataRetention: 90
      },
      alerts: {
        desktop: true,
        sound: false,
        frequency: 5
      },
      enterprise: {
        crmIntegration: '',
        apiKey: '',
        multiUser: false,
        companyName: ''
      },
      templates: [
        {
          name: 'Rate Inquiry',
          content: 'Hi! I\'m interested in your load from {origin} to {destination}. My rate is ${rate} per mile. Can we work together?'
        },
        {
          name: 'Quick Booking',
          content: 'I can book this load immediately at ${rate}/mile. Equipment ready and available!'
        }
      ]
    };
  }

  async getStorageValue(key, defaultValue) {
    try {
      const result = await browser_api.storage.sync.get(key);
      return result[key] !== undefined ? result[key] : defaultValue;
    } catch (error) {
      return defaultValue;
    }
  }
}

// Initialize options page when DOM is loaded
let options;
document.addEventListener('DOMContentLoaded', () => {
  options = new DATSpeedOptions();
});
