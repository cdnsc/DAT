#!/bin/bash
# 🚛 DAT Real-Time Load Analyzer - Complete Setup and Run (Fedora Linux)
# One-click installation and startup optimized for Fedora 38+

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

# Configuration
PROJECT_NAME="DAT Real-Time Load Analyzer"
VENV_NAME="dat-analyzer-env"
PYTHON_MIN_VERSION="3.9"

print_banner() {
    echo -e "${BLUE}============================================================${NC}"
    echo -e "${GREEN}🚛 $PROJECT_NAME - Fedora Linux Edition${NC}"
    echo -e "${BLUE}============================================================${NC}"
    echo -e "${CYAN}Enterprise-grade, real-time, multi-driver load monitoring${NC}"
    echo ""
}

print_step() { echo -e "${YELLOW}📦 $1${NC}"; }
print_success() { echo -e "${GREEN}✅ $1${NC}"; }
print_error() { echo -e "${RED}❌ $1${NC}"; }
print_info() { echo -e "${CYAN}ℹ️  $1${NC}"; }

# Check if running on Fedora
check_fedora() {
    if [ ! -f /etc/fedora-release ]; then
        print_error "This script is optimized for Fedora Linux"
        print_info "Detected system: $(uname -s)"
        read -p "Continue anyway? (y/N): " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            exit 0
        fi
    else
        FEDORA_VERSION=$(cat /etc/fedora-release)
        print_success "Running on: $FEDORA_VERSION"
    fi
}

# Make all shell scripts executable
make_scripts_executable() {
    print_step "Making all shell scripts executable..."
    
    # List of all shell scripts in the project
    SHELL_SCRIPTS=(
        "install.sh"
        "start.sh"
        "setup.sh"
        "fedora-qubes.sh"
        "qubesos-install.sh"
        "super-simple.sh"
    )
    
    for script in "${SHELL_SCRIPTS[@]}"; do
        if [ -f "$script" ]; then
            chmod +x "$script"
            print_success "Made executable: $script"
        else
            print_info "Script not found (skipping): $script"
        fi
    done
    
    print_success "All shell scripts are now executable"
}

# Install system dependencies
install_fedora_deps() {
    print_step "Installing Fedora system dependencies..."
    
    # Update system
    sudo dnf update -y
    
    # Install Python and development tools
    sudo dnf install -y \
        python3 python3-pip python3-devel \
        python3-setuptools python3-wheel \
        git curl wget sqlite \
        gcc gcc-c++ make cmake \
        libffi-devel openssl-devel \
        zlib-devel bzip2-devel readline-devel \
        xz-devel tk-devel ncurses-devel
    
    # Try to install python3-venv, but continue if it fails (might be included in base Python)
    sudo dnf install -y python3-venv || print_info "python3-venv not available as separate package (might be included)"
    
    # Install Chrome for browser automation
    print_step "Installing Google Chrome..."
    
    # Add Google Chrome repository
    sudo tee /etc/yum.repos.d/google-chrome.repo > /dev/null << 'EOF'
[google-chrome]
name=google-chrome
baseurl=http://dl.google.com/linux/chrome/rpm/stable/x86_64
enabled=1
gpgcheck=1
gpgkey=https://dl.google.com/linux/linux_signing_key.pub
EOF
    
    # Install Chrome
    sudo dnf install -y google-chrome-stable || {
        print_info "Chrome installation failed, trying Chromium..."
        sudo dnf install -y chromium
    }
    
    # Install system monitoring tools
    sudo dnf install -y htop iotop nethogs
    
    print_success "Fedora dependencies installed"
}

# Setup Python environment
setup_python_env() {
    print_step "Setting up Python virtual environment..."
    
    # Remove existing environment if present
    if [ -d "$VENV_NAME" ]; then
        rm -rf "$VENV_NAME"
    fi
    
    # Create virtual environment with fallback methods
    if python3 -m venv "$VENV_NAME" 2>/dev/null; then
        print_success "Created virtual environment using python3 -m venv"
    elif command -v virtualenv >/dev/null 2>&1; then
        print_info "Using virtualenv as fallback..."
        pip3 install --user virtualenv
        virtualenv -p python3 "$VENV_NAME"
    else
        print_info "Installing virtualenv and creating environment..."
        pip3 install --user virtualenv
        virtualenv -p python3 "$VENV_NAME"
    fi
    
    # Activate environment
    source "$VENV_NAME/bin/activate"
    
    # Verify Python version
    PYTHON_VERSION=$(python --version 2>&1 | grep -oP '\d+\.\d+')
    print_info "Using Python $PYTHON_VERSION"
    
    # Upgrade pip
    pip install --upgrade pip setuptools wheel
    
    # Install dependencies
    if [ -f "requirements.txt" ]; then
        print_step "Installing Python packages from requirements.txt..."
        pip install -r requirements.txt
    else
        print_info "requirements.txt not found, installing core packages..."
        pip install streamlit pandas plotly selenium undetected-chromedriver \
                   beautifulsoup4 requests geopy pyyaml loguru sqlalchemy \
                   cryptography pillow matplotlib psutil distro
    fi
    
    print_success "Python environment ready"
}

# Create project structure
setup_project() {
    print_step "Setting up project structure..."
    
    # Create directories
    mkdir -p data/logs data/exports config
    
    # Create default configuration if not exists
    if [ ! -f "config/settings.yaml" ]; then
        cat > config/settings.yaml << 'EOF'
company:
  name: "Your Transportation Company"
  contact_name: "Your Name"
  phone: "(555) 123-4567"
  email: "your.email@company.com"
  address: "Your Company Address"

system:
  auto_refresh_interval: 30
  max_loads_to_display: 50
  default_radius_miles: 150
  browser_headless: false

alerts:
  high_profit_threshold: 2000
  excellent_deal_threshold: 3000
  enable_sound_alerts: true

fedora:
  optimize_performance: true
  use_wayland: true
  chrome_path: "/usr/bin/google-chrome"
EOF
    fi
    
    print_success "Project structure created"
}

# Test system
test_system() {
    print_step "Testing system components..."
    
    # Activate environment
    source "$VENV_NAME/bin/activate"
    
    # Test Python imports
    python3 << 'EOF'
try:
    import streamlit
    import pandas
    import selenium
    import undetected_chromedriver
    import geopy
    import loguru
    import psutil
    import distro
    print("✅ All Python packages imported successfully")
except ImportError as e:
    print(f"❌ Import error: {e}")
    exit(1)
EOF
    
    # Test Chrome
    if command -v google-chrome >/dev/null 2>&1; then
        print_success "Google Chrome available"
    elif command -v chromium >/dev/null 2>&1; then
        print_success "Chromium available"
    else
        print_error "No Chrome/Chromium found"
        return 1
    fi
    
    print_success "System test passed"
}

# Create startup script
create_startup_script() {
    print_step "Creating startup script..."
    
    cat > "start_dat_analyzer.sh" << 'EOF'
#!/bin/bash
# 🚛 DAT Load Analyzer - Quick Start

# Check Fedora environment
if [ -f /etc/fedora-release ]; then
    echo "🐧 $(cat /etc/fedora-release)"
fi

# Activate virtual environment
if [ -d "dat-analyzer-env" ]; then
    source dat-analyzer-env/bin/activate
else
    echo "❌ Virtual environment not found"
    exit 1
fi

# Set Fedora optimizations
export PYTHONUNBUFFERED=1
export STREAMLIT_BROWSER_GATHER_USAGE_STATS=false

# Check for Wayland display server
if [ -n "$WAYLAND_DISPLAY" ]; then
    echo "🖥️  Wayland display server detected"
    export GDK_BACKEND=wayland
fi

# Launch application
echo "🚀 Starting DAT Real-Time Load Analyzer..."
echo "================================================"

if [ -f "main.py" ]; then
    python main.py
else
    streamlit run src/dashboard/real_time_dashboard.py \
        --server.port 8501 \
        --server.address localhost \
        --browser.gatherUsageStats false \
        --theme.primaryColor "#007BFF"
fi
EOF
    
    chmod +x "start_dat_analyzer.sh"
    print_success "Startup script created: start_dat_analyzer.sh"
}

# Main setup function
main() {
    print_banner
    
    # Check if already installed
    if [ -d "$VENV_NAME" ] && [ -f "start_dat_analyzer.sh" ]; then
        print_info "Installation already exists"
        read -p "Reinstall? (y/N): " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            print_info "Launching existing installation..."
            ./start_dat_analyzer.sh
            exit 0
        fi
    fi
    
    # Setup process
    make_scripts_executable
    check_fedora
    install_fedora_deps
    setup_python_env
    setup_project
    test_system
    create_startup_script
    
    # Installation complete
    echo ""
    print_success "🎉 Installation completed successfully!"
    echo ""
    echo -e "${CYAN}📋 NEXT STEPS:${NC}"
    echo -e "${YELLOW}   1. Configure your company details in config/settings.yaml${NC}"
    echo -e "${YELLOW}   2. Add your DAT.com credentials when prompted${NC}"
    echo -e "${YELLOW}   3. Run: ./start.sh${NC}"
    echo ""
    echo -e "${CYAN}🚀 QUICK START:${NC}"
    echo -e "${GREEN}   ./start.sh${NC}"
    echo ""
    
    # Ask to start immediately
    read -p "Start the system now? (Y/n): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Nn]$ ]]; then
        ./start.sh
    fi
}

# Error handling
trap 'print_error "Setup failed at line $LINENO"' ERR

# Run setup
main "$@"
