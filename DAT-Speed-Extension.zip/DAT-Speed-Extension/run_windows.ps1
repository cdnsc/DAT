# 🚀 DAT Real-Time Load Analyzer - Windows Quick Start
# Cross-platform compatibility with Fedora Linux integration

Write-Host "🚛 Starting DAT Real-Time Load Analyzer..." -ForegroundColor Green
Write-Host "================================================" -ForegroundColor Blue

# System information
$OSInfo = Get-WmiObject -Class Win32_OperatingSystem
Write-Host "🖥️  System: $($OSInfo.Caption)" -ForegroundColor Cyan
Write-Host "🔧 Architecture: $($OSInfo.OSArchitecture)" -ForegroundColor Cyan

# Check if Python is installed
try {
    $pythonVersion = python --version 2>&1
    if ($pythonVersion -match "Python (\d+\.\d+\.\d+)") {
        $version = $matches[1]
        Write-Host "🐍 Python version: $version" -ForegroundColor Green
        
        # Check if version is 3.9+
        $versionParts = $version.Split('.')
        $major = [int]$versionParts[0]
        $minor = [int]$versionParts[1]
        
        if ($major -lt 3 -or ($major -eq 3 -and $minor -lt 9)) {
            Write-Host "❌ Python 3.9+ is required. Current version: $version" -ForegroundColor Red
            Write-Host "   Download from: https://python.org/downloads/" -ForegroundColor Yellow
            Read-Host "Press Enter to exit"
            exit 1
        }
    }
} catch {
    Write-Host "❌ Python 3 is required but not installed." -ForegroundColor Red
    Write-Host "   Download from: https://python.org/downloads/" -ForegroundColor Yellow
    Read-Host "Press Enter to exit"
    exit 1
}

# Check if virtual environment exists
if (-not (Test-Path "dat-analyzer-env")) {
    Write-Host "❌ Virtual environment not found." -ForegroundColor Red
    Write-Host "   Please run the installation script first: .\install.ps1" -ForegroundColor Yellow
    Read-Host "Press Enter to exit"
    exit 1
}

# Check if main.py exists
if (-not (Test-Path "main.py")) {
    Write-Host "❌ main.py not found. Please ensure you're in the correct directory." -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit 1
}

# Activate virtual environment
Write-Host "🔧 Activating virtual environment..." -ForegroundColor Yellow
try {
    & "dat-analyzer-env\Scripts\Activate.ps1"
    Write-Host "✅ Virtual environment activated" -ForegroundColor Green
} catch {
    Write-Host "❌ Failed to activate virtual environment" -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit 1
}

# Check dependencies
Write-Host "📦 Checking dependencies..." -ForegroundColor Yellow
try {
    python -c "import streamlit, pandas, selenium, undetected_chromedriver" 2>$null
    Write-Host "✅ Core dependencies available" -ForegroundColor Green
} catch {
    Write-Host "❌ Some dependencies are missing." -ForegroundColor Red
    Write-Host "   Installing dependencies..." -ForegroundColor Yellow
    pip install -r requirements.txt
}

# Create data directories
if (-not (Test-Path "data")) { New-Item -ItemType Directory -Path "data" | Out-Null }
if (-not (Test-Path "data\logs")) { New-Item -ItemType Directory -Path "data\logs" | Out-Null }
if (-not (Test-Path "data\exports")) { New-Item -ItemType Directory -Path "data\exports" | Out-Null }
if (-not (Test-Path "config")) { New-Item -ItemType Directory -Path "config" | Out-Null }

# Check Chrome installation
$chromeFound = $false
$chromePaths = @(
    "${env:ProgramFiles}\Google\Chrome\Application\chrome.exe",
    "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
    "${env:LOCALAPPDATA}\Google\Chrome\Application\chrome.exe"
)

foreach ($path in $chromePaths) {
    if (Test-Path $path) {
        $chromeFound = $true
        Write-Host "✅ Google Chrome found: $path" -ForegroundColor Green
        break
    }
}

if (-not $chromeFound) {
    Write-Host "⚠️ Google Chrome not found." -ForegroundColor Yellow
    Write-Host "   Download from: https://chrome.google.com/chrome/" -ForegroundColor Yellow
    $continue = Read-Host "Continue anyway? (y/N)"
    if ($continue -ne "y" -and $continue -ne "Y") {
        Write-Host "Exiting..." -ForegroundColor Yellow
        exit 0
    }
}

# Check system resources
try {
    $memory = Get-WmiObject -Class Win32_ComputerSystem
    $memoryGB = [math]::Round($memory.TotalPhysicalMemory / 1GB, 1)
    
    if ($memoryGB -lt 4) {
        Write-Host "⚠️ Low memory detected: ${memoryGB}GB" -ForegroundColor Yellow
        Write-Host "   For best performance, 4GB+ RAM is recommended" -ForegroundColor Yellow
    } else {
        Write-Host "✅ Memory: ${memoryGB}GB available" -ForegroundColor Green
    }
} catch {
    Write-Host "⚠️ Could not check system memory" -ForegroundColor Yellow
}

# Set environment variables for optimization
$env:PYTHONUNBUFFERED = "1"
$env:STREAMLIT_BROWSER_GATHER_USAGE_STATS = "false"

# Start the application
Write-Host ""
Write-Host "🚀 Launching DAT Real-Time Load Analyzer..." -ForegroundColor Green
Write-Host "================================================" -ForegroundColor Blue
Write-Host "📊 Dashboard will open in your default browser" -ForegroundColor Cyan
Write-Host "📧 Gmail integration ready for broker communication" -ForegroundColor Cyan
Write-Host "📍 Location tracking system active" -ForegroundColor Cyan
Write-Host "🖥️  Windows optimizations enabled" -ForegroundColor Cyan
Write-Host ""
Write-Host "💡 QUICK TIPS:" -ForegroundColor Yellow
Write-Host "   • Update driver location in the 'Driver Location' tab" -ForegroundColor White
Write-Host "   • Use 'Load Sample Data' button to test the system" -ForegroundColor White
Write-Host "   • Click email buttons to compose messages to brokers" -ForegroundColor White
Write-Host "   • Toggle 'Auto Refresh' for live monitoring" -ForegroundColor White
Write-Host ""
Write-Host "🛑 Press Ctrl+C to stop the system" -ForegroundColor Yellow
Write-Host ""

# Handle cleanup on exit
$cleanup = {
    Write-Host ""
    Write-Host "🛑 Shutting down DAT Load Analyzer..." -ForegroundColor Yellow
    
    # Stop any background jobs
    Get-Job | Stop-Job
    Get-Job | Remove-Job
    
    Write-Host "✅ System stopped" -ForegroundColor Green
}

# Set up event handler for Ctrl+C
Register-EngineEvent -SourceIdentifier PowerShell.Exiting -SupportEvent -Action $cleanup

# Launch the application
try {
    if (Test-Path "main.py") {
        python main.py --dashboard-only
    } else {
        # Fallback to direct dashboard launch
        streamlit run src/dashboard/real_time_dashboard.py `
            --server.port 8501 `
            --server.address localhost `
            --browser.gatherUsageStats false `
            --theme.primaryColor "#007BFF" `
            --theme.backgroundColor "#FFFFFF" `
            --theme.secondaryBackgroundColor "#F8F9FA"
    }
} catch {
    Write-Host "❌ Failed to start system: $_" -ForegroundColor Red
    Read-Host "Press Enter to exit"
} finally {
    # Cleanup
    & $cleanup
}
