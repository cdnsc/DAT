#!/bin/bash
# 🚀 Simple Install - Uses System Packages (No Compilation)
# Run this if you want to avoid compiling lxml

echo "🚀 SIMPLE INSTALLATION - USING SYSTEM PACKAGES"
echo ""

# Install system packages including python3-lxml
echo "📦 Installing system packages..."
sudo dnf install -y \
    python3 \
    python3-pip \
    python3-lxml \
    python3-setuptools \
    python3-wheel \
    python3-devel \
    google-chrome-stable

# Install Python packages (without lxml)
echo "📦 Installing Python packages..."
python3 -m pip install --no-cache-dir -r requirements-no-lxml.txt

echo ""
echo "✅ SIMPLE INSTALLATION COMPLETE!"
echo "🧪 Testing lxml..."
python3 -c "import lxml; print('✅ lxml works!')"

echo "🚀 Ready to run: ./start.sh"
