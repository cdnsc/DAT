#!/bin/bash
# 🚀 DAT Real-Time Load Analyzer - Fedora Linux Quick Start
# Optimized for Fedora 38+ with enterprise features

echo "🚛 Starting DAT Real-Time Load Analyzer for Fedora Linux..."
echo "==========================================================="

# Check if we're running on Fedora
if [ ! -f /etc/fedora-release ]; then
    echo "⚠️  This script is optimized for Fedora Linux"
    echo "   It may work on other distributions but is not tested"
    read -p "Continue anyway? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "Exiting..."
        exit 0
    fi
fi

# Display Fedora version
if [ -f /etc/fedora-release ]; then
    FEDORA_VERSION=$(cat /etc/fedora-release)
    echo "🐧 System: $FEDORA_VERSION"
fi

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is required but not installed."
    echo "   Install with: sudo dnf install python3 python3-pip"
    exit 1
fi

# Check Python version
PYTHON_VERSION=$(python3 -c 'import sys; print(".".join(map(str, sys.version_info[:2])))')
echo "🐍 Python version: $PYTHON_VERSION"

if ! python3 -c 'import sys; exit(0 if sys.version_info >= (3, 9) else 1)'; then
    echo "❌ Python 3.9+ is required. Current version: $PYTHON_VERSION"
    echo "   Upgrade with: sudo dnf update python3"
    exit 1
fi

# Check if virtual environment exists
if [ ! -d "dat-analyzer-env" ]; then
    echo "❌ Virtual environment not found."
    echo "   Please run the installation script first: ./install.sh"
    exit 1
fi

# Check if main.py exists
if [ ! -f "main.py" ]; then
    echo "❌ main.py not found. Please ensure you're in the correct directory."
    exit 1
fi

# Activate virtual environment
echo "🔧 Activating virtual environment..."
source dat-analyzer-env/bin/activate

# Check if required packages are installed
echo "📦 Checking dependencies..."
if ! python -c "import streamlit, pandas, selenium, undetected_chromedriver" 2>/dev/null; then
    echo "❌ Some dependencies are missing."
    echo "   Installing dependencies..."
    pip install -r requirements.txt
fi

# Create data directories if they don't exist
mkdir -p data/logs
mkdir -p data/exports
mkdir -p config

# Check Chrome/Chromium installation
CHROME_FOUND=false
for chrome_path in "/usr/bin/google-chrome" "/usr/bin/chromium-browser" "/usr/bin/chromium"; do
    if [ -f "$chrome_path" ]; then
        CHROME_FOUND=true
        echo "✅ Chrome/Chromium found: $chrome_path"
        break
    fi
done

if [ "$CHROME_FOUND" = false ]; then
    echo "⚠️  Chrome/Chromium not found."
    echo "   Install with: sudo dnf install google-chrome-stable"
    echo "   Or install Chromium: sudo dnf install chromium"
    read -p "Continue anyway? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "Exiting..."
        exit 0
    fi
fi

# Check for X11 or Wayland display
if [ -z "$DISPLAY" ] && [ -z "$WAYLAND_DISPLAY" ]; then
    echo "⚠️  No display server detected."
    echo "   The system will run in headless mode."
    export BROWSER_HEADLESS=true
fi

# Set Fedora-specific optimizations
export PYTHONUNBUFFERED=1
export STREAMLIT_BROWSER_GATHER_USAGE_STATS=false

# Check available memory
if command -v free &> /dev/null; then
    MEMORY_GB=$(free -g | awk 'NR==2{print $2}')
    if [ "$MEMORY_GB" -lt 4 ]; then
        echo "⚠️  Low memory detected: ${MEMORY_GB}GB"
        echo "   For best performance, 4GB+ RAM is recommended"
    else
        echo "✅ Memory: ${MEMORY_GB}GB available"
    fi
fi

# Start the application
echo ""
echo "🚀 Launching DAT Real-Time Load Analyzer..."
echo "================================================"
echo "📊 Dashboard will open in your default browser"
echo "📧 Gmail integration ready for broker communication"
echo "📍 Location tracking system active"
echo "🐧 Fedora Linux optimizations enabled"
echo ""
echo "💡 QUICK TIPS:"
echo "   • Update driver location in the 'Driver Location' tab"
echo "   • Use 'Load Sample Data' button to test the system"
echo "   • Click email buttons to compose messages to brokers"
echo "   • Toggle 'Auto Refresh' for live monitoring"
echo ""
echo "🛑 Press Ctrl+C to stop the system"
echo ""

# Handle cleanup on exit
cleanup() {
    echo ""
    echo "🛑 Shutting down DAT Load Analyzer..."
    
    # Kill any background processes
    jobs -p | xargs -r kill
    
    echo "✅ System stopped"
    exit 0
}

# Set up signal handlers
trap cleanup SIGINT SIGTERM

# Launch the application
if [ -f "main.py" ]; then
    python main.py --dashboard-only
else
    # Fallback to direct dashboard launch
    streamlit run src/dashboard/real_time_dashboard.py \
        --server.port 8501 \
        --server.address localhost \
        --browser.gatherUsageStats false \
        --theme.primaryColor "#007BFF" \
        --theme.backgroundColor "#FFFFFF" \
        --theme.secondaryBackgroundColor "#F8F9FA"
fi
