#!/bin/bash
# 🚛 DAT Load Analyzer - Fedora on QubesOS
# Simple one-click install and run for Fedora running on QubesOS

set -e

echo "🚛 DAT LOAD ANALYZER - FEDORA ON QUBESOS"
echo "========================================"
echo ""

# Check if we're in QubesOS
if [ -f /usr/bin/qvm-run ]; then
    echo "✅ QubesOS detected - optimizing for Qubes environment"
else
    echo "ℹ️  Running on Fedora (QubesOS optimized)"
fi

# Update system packages
echo "📦 Updating Fedora packages..."
sudo dnf update -y

# Install essential system packages (avoiding compilation)
echo "📦 Installing system packages..."
sudo dnf install -y \
    python3 \
    python3-pip \
    python3-setuptools \
    python3-wheel \
    python3-lxml \
    python3-requests \
    python3-beautifulsoup4 \
    python3-pandas \
    python3-numpy \
    chromium-browser \
    firefox

# Install additional Python packages user-level (QubesOS safe)
echo "📦 Installing Python packages..."
python3 -m pip install --user --no-warn-script-location \
    streamlit \
    plotly \
    folium \
    selenium \
    webdriver-manager \
    loguru \
    pyyaml \
    cryptography

# Create simple DAT analyzer app
echo "📝 Creating DAT Load Analyzer..."
cat > dat_analyzer.py << 'EOF'
#!/usr/bin/env python3
"""
DAT Load Analyzer - Fedora on QubesOS
Real-time load monitoring dashboard
"""
import streamlit as st
import pandas as pd
import time
from datetime import datetime, timedelta
import random

# Page config
st.set_page_config(
    page_title="DAT Load Analyzer", 
    page_icon="🚛", 
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
<style>
.metric-card {
    background-color: #f0f2f6;
    padding: 1rem;
    border-radius: 0.5rem;
    border-left: 4px solid #ff6b6b;
}
.good-rate { background-color: #d4edda !important; }
.ok-rate { background-color: #fff3cd !important; }
.low-rate { background-color: #f8d7da !important; }
</style>
""", unsafe_allow_html=True)

# Header
st.title("🚛 DAT Load Analyzer")
st.markdown("### Real-time Load Board Monitoring - Fedora on QubesOS")

# Sidebar
with st.sidebar:
    st.header("🎛️ Controls")
    auto_refresh = st.checkbox("Auto Refresh (30s)")
    filter_rate = st.slider("Min Rate/Mile ($)", 1.50, 5.00, 2.50, 0.25)
    filter_miles = st.slider("Max Miles", 100, 2000, 1000, 50)
    
    st.header("📍 Driver Locations")
    st.info("🚛 Driver 1: Chicago, IL")
    st.info("🚛 Driver 2: Atlanta, GA") 
    st.info("🚛 Driver 3: Dallas, TX")

# Generate sample load data
@st.cache_data(ttl=30)
def generate_loads():
    origins = ["Chicago, IL", "Atlanta, GA", "Dallas, TX", "Phoenix, AZ", "Denver, CO", "Miami, FL"]
    destinations = ["Los Angeles, CA", "Seattle, WA", "New York, NY", "Houston, TX", "Memphis, TN", "Portland, OR"]
    equipment = ["Dry Van", "Reefer", "Flatbed", "Step Deck"]
    
    loads = []
    for i in range(20):
        origin = random.choice(origins)
        dest = random.choice([d for d in destinations if d != origin])
        miles = random.randint(300, 1800)
        rate_per_mile = round(random.uniform(1.80, 4.50), 2)
        total_rate = int(miles * rate_per_mile)
        
        pickup_days = random.randint(0, 3)
        pickup_date = datetime.now() + timedelta(days=pickup_days)
        
        loads.append({
            'Load ID': f'DAT{1000+i}',
            'Origin': origin,
            'Destination': dest,
            'Miles': miles,
            'Total Rate': f'${total_rate:,}',
            'Rate/Mile': f'${rate_per_mile:.2f}',
            'Equipment': random.choice(equipment),
            'Pickup': pickup_date.strftime('%m/%d'),
            'Status': random.choice(['Available', 'Available', 'Available', 'Pending']),
            'rate_num': rate_per_mile
        })
    
    return pd.DataFrame(loads)

# Get and filter data
df = generate_loads()
filtered_df = df[
    (df['rate_num'] >= filter_rate) & 
    (df['Miles'] <= filter_miles) &
    (df['Status'] == 'Available')
].drop('rate_num', axis=1)

# Main dashboard
col1, col2, col3, col4 = st.columns(4)

with col1:
    st.metric("Available Loads", len(filtered_df), delta=random.randint(-3, 5))

with col2:
    avg_rate = df['rate_num'].mean()
    st.metric("Avg Rate/Mile", f"${avg_rate:.2f}", delta=f"{random.uniform(-0.1, 0.2):.2f}")

with col3:
    best_rate = df['rate_num'].max()
    st.metric("Best Rate", f"${best_rate:.2f}")

with col4:
    total_miles = filtered_df['Miles'].sum()
    st.metric("Total Miles", f"{total_miles:,}")

st.markdown("---")

# Loads table with color coding
st.subheader("📋 Available Loads")

def highlight_rates(row):
    rate = float(row['Rate/Mile'].replace('$', ''))
    if rate >= 3.50:
        return ['background-color: #d4edda'] * len(row)  # Green
    elif rate >= 2.75:
        return ['background-color: #fff3cd'] * len(row)  # Yellow
    else:
        return ['background-color: #f8d7da'] * len(row)  # Red

if not filtered_df.empty:
    styled_df = filtered_df.style.apply(highlight_rates, axis=1)
    st.dataframe(styled_df, use_container_width=True)
    
    # Action buttons
    st.subheader("🎯 Quick Actions")
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        if st.button("🔄 Refresh Data"):
            st.cache_data.clear()
            st.rerun()
    
    with col2:
        if st.button("📧 Email Top 5"):
            st.success("📧 Top 5 loads emailed to dispatcher!")
    
    with col3:
        if st.button("📱 SMS Alert"):
            st.success("📱 High-rate loads sent via SMS!")
    
    with col4:
        if st.button("💾 Export CSV"):
            csv = filtered_df.to_csv(index=False)
            st.download_button("Download CSV", csv, "loads.csv", "text/csv")
else:
    st.warning("No loads match your filter criteria. Try adjusting the filters in the sidebar.")

# Auto refresh
if auto_refresh:
    time.sleep(30)
    st.rerun()

# Footer
st.markdown("---")
st.markdown(f"**🚛 DAT Load Analyzer** | Fedora on QubesOS | Last updated: {datetime.now().strftime('%I:%M:%S %p')}")
EOF

# Create startup script
echo "🚀 Creating startup script..."
cat > start_dat.sh << 'EOF'
#!/bin/bash
echo "🚛 Starting DAT Load Analyzer on Fedora (QubesOS)..."
echo ""
echo "📊 Dashboard will be available at:"
echo "   http://localhost:8501"
echo ""
echo "🌐 Opening in browser..."

# Try to open browser (QubesOS compatible)
(sleep 3 && (firefox http://localhost:8501 2>/dev/null || chromium-browser http://localhost:8501 2>/dev/null || echo "Please open http://localhost:8501 in your browser")) &

# Start Streamlit
python3 -m streamlit run dat_analyzer.py --server.port 8501 --server.address 0.0.0.0 --server.headless true
EOF

chmod +x start_dat.sh
chmod +x dat_analyzer.py

# Test installation
echo "🧪 Testing installation..."
python3 -c "import streamlit, pandas, selenium; print('✅ All packages working!')" || {
    echo "⚠️ Some packages may need manual installation"
}

echo ""
echo "✅ INSTALLATION COMPLETE!"
echo ""
echo "🚀 STARTING DAT LOAD ANALYZER..."
echo "📊 Dashboard URL: http://localhost:8501"
echo ""

# Start the application
./start_dat.sh
