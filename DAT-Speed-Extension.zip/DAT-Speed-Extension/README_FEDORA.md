# 🚛 DAT Real-Time Load Analyzer - Fedora Linux Edition

**Enterprise-grade, multi-driver, real-time load monitoring system optimized for Fedora Linux**

[![Fedora](https://img.shields.io/badge/Fedora-38+-blue?logo=fedora)](https://getfedora.org/)
[![Python](https://img.shields.io/badge/Python-3.9+-green?logo=python)](https://python.org)
[![Chrome](https://img.shields.io/badge/Chrome-Latest-yellow?logo=google-chrome)](https://chrome.google.com)

---

## 🚀 **One-Click Installation for Fedora**

### **Super Quick Start:**
```bash
# Download and run the complete setup
curl -L https://raw.githubusercontent.com/your-repo/setup_and_run.sh | bash

# OR clone and run locally
git clone [repository-url]
cd DAT-Speed-Extension
chmod +x setup_and_run.sh
./setup_and_run.sh
```

### **Manual Installation:**
```bash
# 1. Install system dependencies
chmod +x install.sh
./install.sh

# 2. Start the system
chmod +x run_fedora.sh
./run_fedora.sh
```

---

## 🐧 **Fedora Linux Optimizations**

This system is specifically optimized for Fedora Linux with:

### **Native Fedora Integration:**
- **DNF Package Management**: Automatic Chrome and dependency installation
- **Wayland Support**: Full compatibility with Fedora's default display server
- **SELinux Compatibility**: Secure operation within Fedora's security framework
- **SystemD Integration**: Background service support
- **Fedora 38+ Optimizations**: Latest Python 3.11 and modern libraries

### **System Requirements:**
- **OS**: Fedora 38+ (also works on 36, 37)
- **RAM**: 4GB+ recommended (2GB minimum)
- **Storage**: 2GB free space
- **Display**: X11 or Wayland (headless mode available)
- **Network**: Internet connection for DAT.com access

---

## 📦 **What Gets Installed**

### **System Packages (via DNF):**
```bash
sudo dnf install -y \
    python3 python3-pip python3-devel python3-venv \
    google-chrome-stable \
    gcc gcc-c++ make cmake \
    libffi-devel openssl-devel \
    sqlite git curl wget \
    htop iotop nethogs
```

### **Python Environment:**
- Virtual environment: `dat-analyzer-env`
- All dependencies from `requirements.txt`
- Fedora-specific packages: `distro`, `psutil`

---

## 🛠️ **Features**

### **🌐 Real-Time DAT.com Integration**
- Browser automation with undetected Chrome
- Live load scraping and analysis
- Location-based filtering
- Deal quality scoring

### **📍 Multi-Driver Location Tracking**
- Support for 4-5 drivers simultaneously
- Real-time GPS integration
- City/state location management
- Route optimization

### **📧 Professional Broker Communication**
- Gmail mailto: integration (no APIs)
- Professional email templates
- Rate negotiation suggestions
- Communication tracking

### **📊 Live Dashboard**
- Real-time load monitoring
- Interactive maps
- Deal highlighting
- Analytics and reporting

---

## 🚀 **Usage**

### **Start the System:**
```bash
./start_dat_analyzer.sh
```

### **Access Dashboard:**
- **URL**: http://localhost:8501
- **Auto-opens**: in your default browser

### **Quick Actions:**
1. **Set Driver Location**: Use "Driver Location" tab
2. **Load Sample Data**: Click "Load Sample Data" button
3. **Email Brokers**: Click email buttons next to loads
4. **Monitor Live**: Toggle "Auto Refresh" for real-time updates

---

## ⚙️ **Configuration**

### **Company Settings** (`config/settings.yaml`):
```yaml
company:
  name: "Your Transportation Company"
  contact_name: "Your Name"
  phone: "(555) 123-4567"
  email: "your.email@company.com"

fedora:
  optimize_performance: true
  use_wayland: true
  chrome_path: "/usr/bin/google-chrome"
```

### **Email Templates** (`config/email_templates.yaml`):
Professional templates for broker communication

---

## 🔧 **Fedora-Specific Troubleshooting**

### **Chrome Installation Issues:**
```bash
# If Chrome fails, install Chromium
sudo dnf install chromium

# Or manually download Chrome
wget https://dl.google.com/linux/direct/google-chrome-stable_current_x86_64.rpm
sudo dnf install google-chrome-stable_current_x86_64.rpm
```

### **Wayland Display Issues:**
```bash
# Force X11 if Wayland causes problems
export GDK_BACKEND=x11
./run_fedora.sh
```

### **SELinux Permission Issues:**
```bash
# Check SELinux status
sestatus

# If needed, set permissive mode temporarily
sudo setenforce 0
```

### **Firewall Configuration:**
```bash
# Allow Streamlit port (if needed)
sudo firewall-cmd --add-port=8501/tcp --permanent
sudo firewall-cmd --reload
```

---

## 📁 **Project Structure**

```
DAT-Speed-Extension/
├── 🚀 setup_and_run.sh         # One-click setup for Fedora
├── 🚀 run_fedora.sh            # Fedora-optimized launcher
├── 🛠️ install.sh               # System dependency installer
├── 🖥️ run_windows.ps1          # Windows launcher
├── 🖥️ install.ps1              # Windows installer
├── 🐍 main.py                  # Main application entry
├── 📋 requirements.txt         # Python dependencies
├── 📖 README.md                # This file
├── 📝 PROJECT_PLAN.md         # Technical details
├── src/
│   ├── 📍 location/            # Multi-driver location management
│   ├── 🌐 scraper/            # DAT.com browser automation
│   ├── 📧 communication/      # Gmail mailto integration
│   ├── 📊 dashboard/          # Real-time dashboard
│   ├── 📊 models/             # Data models
│   └── 🛠️ utils/              # Enterprise utilities
├── config/
│   ├── ⚙️ settings.yaml       # System configuration
│   └── 📧 email_templates.yaml # Email templates
└── data/
    ├── 📊 logs/               # Application logs
    └── 📈 exports/            # Data exports
```

---

## 🆘 **Support**

### **Log Files:**
- **Application**: `data/logs/main_application.log`
- **Scraper**: `data/logs/dat_scraper.log`
- **Location**: `data/logs/location_manager.log`

### **System Information:**
```bash
# Check system status
./run_fedora.sh --check-system

# View logs
tail -f data/logs/main_application.log
```

### **Common Solutions:**
1. **Port in use**: Change port in settings or kill existing process
2. **Chrome not found**: Install Google Chrome or Chromium
3. **Permission denied**: Check file permissions and SELinux
4. **Memory issues**: Close other applications, increase swap

---

## 🔒 **Security & Privacy**

### **Data Protection:**
- ✅ All credentials encrypted locally
- ✅ No data sent to external servers
- ✅ Browser-based operation only
- ✅ Local SQLite database
- ✅ Secure credential storage

### **Network Security:**
- ✅ No API keys required
- ✅ Standard HTTPS connections only
- ✅ Local network operation
- ✅ Firewall-friendly

---

## 📈 **Performance**

### **Fedora Optimizations:**
- **Memory Usage**: ~200-400MB typical
- **CPU Usage**: <5% idle, <20% scraping
- **Startup Time**: 10-15 seconds
- **Response Time**: <500ms dashboard updates

### **Monitoring:**
```bash
# Monitor system resources
htop

# Monitor network usage
nethogs

# Monitor I/O
iotop
```

---

## 🚀 **Quick Commands**

```bash
# Complete setup and start
./setup_and_run.sh

# Start existing installation
./run_fedora.sh

# Install dependencies only
./install.sh

# Check system status
python main.py --setup

# Dashboard only mode
python main.py --dashboard-only

# Debug mode
python main.py --debug
```

---

## 🎯 **Next Steps**

1. **📝 Configure**: Edit `config/settings.yaml` with your company details
2. **🔐 Credentials**: Add DAT.com login when prompted
3. **🚛 Drivers**: Add your drivers in the dashboard
4. **📍 Locations**: Set initial driver locations
5. **🚀 Go Live**: Start monitoring loads and making money!

---

**🚛 Ready to revolutionize your load management on Fedora Linux!**

For technical details, see [PROJECT_PLAN.md](PROJECT_PLAN.md)
