# 🚛 DAT Real-Time Load Analyzer - Complete Installation Script (Windows)
# Enterprise-grade installation for Windows 10/11

param(
    [switch]$SkipPython,
    [switch]$SkipChrome,
    [switch]$Force
)

# Configuration
$PYTHON_MIN_VERSION = "3.9"
$PROJECT_NAME = "DAT Real-Time Load Analyzer"
$VENV_NAME = "dat-analyzer-env"

# Color functions for better output
function Write-ColorOutput {
    param(
        [string]$Message,
        [string]$Color = "White"
    )
    Write-Host $Message -ForegroundColor $Color
}

function Write-Success {
    param([string]$Message)
    Write-ColorOutput "✅ $Message" -Color "Green"
}

function Write-Error {
    param([string]$Message)
    Write-ColorOutput "❌ $Message" -Color "Red"
}

function Write-Warning {
    param([string]$Message)
    Write-ColorOutput "⚠️ $Message" -Color "Yellow"
}

function Write-Info {
    param([string]$Message)
    Write-ColorOutput "ℹ️ $Message" -Color "Cyan"
}

function Write-Step {
    param([string]$Message)
    Write-ColorOutput "📦 $Message" -Color "Yellow"
}

# Print banner
function Write-Banner {
    Write-ColorOutput "============================================================" -Color "Blue"
    Write-ColorOutput "🚛 $PROJECT_NAME - Installation Script" -Color "Green"
    Write-ColorOutput "============================================================" -Color "Blue"
    Write-ColorOutput "Enterprise-grade, multi-driver, real-time load monitoring" -Color "Cyan"
    Write-Host ""
}

# Check if command exists
function Test-Command {
    param([string]$Command)
    try {
        Get-Command $Command -ErrorAction Stop | Out-Null
        return $true
    } catch {
        return $false
    }
}

# Compare version numbers
function Test-Version {
    param(
        [string]$CurrentVersion,
        [string]$MinVersion
    )
    try {
        $current = [System.Version]$CurrentVersion
        $minimum = [System.Version]$MinVersion
        return $current -ge $minimum
    } catch {
        return $false
    }
}

# Check Python installation
function Test-Python {
    Write-Step "Checking Python installation..."
    
    if (Test-Command "python") {
        try {
            $pythonVersion = python --version 2>&1
            if ($pythonVersion -match "Python (\d+\.\d+\.\d+)") {
                $version = $matches[1]
                if (Test-Version $version $PYTHON_MIN_VERSION) {
                    Write-Success "Python $version found (>= $PYTHON_MIN_VERSION required)"
                    return $true
                } else {
                    Write-Error "Python $version found, but $PYTHON_MIN_VERSION+ required"
                    return $false
                }
            }
        } catch {
            Write-Error "Failed to check Python version"
            return $false
        }
    } else {
        Write-Error "Python not found in PATH"
        return $false
    }
}

# Install Python
function Install-Python {
    if (-not $SkipPython -and -not (Test-Python)) {
        Write-Step "Python installation required..."
        Write-Info "Please download and install Python $PYTHON_MIN_VERSION+ from:"
        Write-Info "https://python.org/downloads/"
        Write-Info ""
        Write-Info "Make sure to:"
        Write-Info "✓ Check 'Add Python to PATH'"
        Write-Info "✓ Check 'Install pip'"
        Write-Info ""
        
        $continue = Read-Host "Have you installed Python? (y/N)"
        if ($continue -ne "y" -and $continue -ne "Y") {
            Write-Error "Python installation required. Exiting."
            exit 1
        }
        
        if (-not (Test-Python)) {
            Write-Error "Python still not found. Please restart PowerShell and try again."
            exit 1
        }
    }
}

# Check Chrome installation
function Test-Chrome {
    Write-Step "Checking Chrome installation..."
    
    $chromePaths = @(
        "${env:ProgramFiles}\Google\Chrome\Application\chrome.exe",
        "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
        "${env:LOCALAPPDATA}\Google\Chrome\Application\chrome.exe"
    )
    
    foreach ($path in $chromePaths) {
        if (Test-Path $path) {
            Write-Success "Google Chrome found"
            return $true
        }
    }
    
    Write-Warning "Google Chrome not found"
    return $false
}

# Install Chrome
function Install-Chrome {
    if (-not $SkipChrome -and -not (Test-Chrome)) {
        Write-Step "Chrome installation recommended..."
        Write-Info "Please download and install Google Chrome from:"
        Write-Info "https://chrome.google.com/chrome/"
        Write-Info ""
        Write-Info "Chrome is required for DAT.com automation."
        Write-Info ""
        
        $continue = Read-Host "Continue without Chrome? (y/N)"
        if ($continue -ne "y" -and $continue -ne "Y") {
            Write-Error "Chrome installation recommended. Exiting."
            exit 1
        }
    }
}

# Create virtual environment
function New-VirtualEnvironment {
    Write-Step "Creating Python virtual environment..."
    
    if (Test-Path $VENV_NAME) {
        if ($Force) {
            Write-Info "Removing existing virtual environment..."
            Remove-Item -Recurse -Force $VENV_NAME
        } else {
            Write-Info "Virtual environment already exists."
            $recreate = Read-Host "Recreate virtual environment? (y/N)"
            if ($recreate -eq "y" -or $recreate -eq "Y") {
                Remove-Item -Recurse -Force $VENV_NAME
            } else {
                Write-Info "Using existing virtual environment"
                return
            }
        }
    }
    
    try {
        python -m venv $VENV_NAME
        Write-Success "Virtual environment created: $VENV_NAME"
    } catch {
        Write-Error "Failed to create virtual environment: $_"
        exit 1
    }
}

# Activate virtual environment
function Enter-VirtualEnvironment {
    $activateScript = Join-Path $VENV_NAME "Scripts\Activate.ps1"
    
    if (Test-Path $activateScript) {
        try {
            & $activateScript
            Write-Success "Virtual environment activated"
        } catch {
            Write-Error "Failed to activate virtual environment: $_"
            exit 1
        }
    } else {
        Write-Error "Virtual environment activation script not found"
        exit 1
    }
}

# Install Python dependencies
function Install-PythonDependencies {
    Write-Step "Installing Python dependencies..."
    
    # Upgrade pip first
    try {
        python -m pip install --upgrade pip setuptools wheel
        Write-Success "pip upgraded"
    } catch {
        Write-Warning "Failed to upgrade pip: $_"
    }
    
    # Install from requirements.txt if available
    if (Test-Path "requirements.txt") {
        try {
            pip install -r requirements.txt
            Write-Success "Dependencies installed from requirements.txt"
        } catch {
            Write-Error "Failed to install dependencies from requirements.txt: $_"
            exit 1
        }
    } else {
        Write-Info "requirements.txt not found, installing core dependencies..."
        
        $coreDeps = @(
            "streamlit",
            "pandas",
            "plotly",
            "selenium",
            "undetected-chromedriver",
            "beautifulsoup4",
            "requests",
            "geopy",
            "pyyaml",
            "loguru",
            "sqlalchemy",
            "cryptography",
            "pillow",
            "matplotlib",
            "seaborn"
        )
        
        foreach ($dep in $coreDeps) {
            try {
                pip install $dep
                Write-Success "Installed $dep"
            } catch {
                Write-Warning "Failed to install $dep`: $_"
            }
        }
    }
    
    # Install enterprise dependencies if available
    if (Test-Path "requirements_enterprise.txt") {
        Write-Step "Installing enterprise dependencies..."
        try {
            pip install -r requirements_enterprise.txt
            Write-Success "Enterprise dependencies installed"
        } catch {
            Write-Warning "Some enterprise dependencies failed to install: $_"
        }
    }
}

# Create directory structure
function New-DirectoryStructure {
    Write-Step "Creating directory structure..."
    
    $directories = @("data", "data\logs", "data\exports", "config", "scripts")
    
    foreach ($dir in $directories) {
        if (-not (Test-Path $dir)) {
            New-Item -ItemType Directory -Path $dir -Force | Out-Null
        }
    }
    
    Write-Success "Directory structure created"
}

# Setup configuration
function Initialize-Configuration {
    Write-Step "Setting up configuration files..."
    
    try {
        python main.py --setup
        Write-Success "Configuration files created"
    } catch {
        Write-Warning "Configuration setup failed: $_"
        Write-Info "You can run 'python main.py --setup' later to configure the system"
    }
}

# Create run script
function New-RunScript {
    Write-Step "Creating run script..."
    
    $runScript = @"
# 🚀 DAT Real-Time Load Analyzer - Quick Start Script (Windows)

# Check if virtual environment exists
if (-not (Test-Path "dat-analyzer-env")) {
    Write-Host "❌ Virtual environment not found. Please run install.ps1 first." -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit 1
}

# Check if main.py exists
if (-not (Test-Path "main.py")) {
    Write-Host "❌ main.py not found. Please ensure you're in the correct directory." -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit 1
}

Write-Host "🚛 Starting DAT Real-Time Load Analyzer..." -ForegroundColor Green
Write-Host "================================================" -ForegroundColor Blue
Write-Host "📊 Dashboard will open in your default browser" -ForegroundColor Cyan
Write-Host "📧 Gmail integration ready for broker communication" -ForegroundColor Cyan
Write-Host "📍 Location tracking system active" -ForegroundColor Cyan
Write-Host ""
Write-Host "💡 QUICK TIPS:" -ForegroundColor Yellow
Write-Host "   • Update driver location in the 'Driver Location' tab" -ForegroundColor White
Write-Host "   • Use 'Load Sample Data' button to test the system" -ForegroundColor White
Write-Host "   • Click email buttons to compose messages to brokers" -ForegroundColor White
Write-Host "   • Toggle 'Auto Refresh' for live monitoring" -ForegroundColor White
Write-Host ""
Write-Host "🛑 Press Ctrl+C to stop the system" -ForegroundColor Yellow
Write-Host ""

# Activate virtual environment and run
try {
    & "dat-analyzer-env\Scripts\Activate.ps1"
    python main.py
} catch {
    Write-Host "❌ Failed to start system: `$_" -ForegroundColor Red
    Read-Host "Press Enter to exit"
}
"@

    $runScript | Out-File -FilePath "run_system.ps1" -Encoding UTF8
    Write-Success "Run script created: run_system.ps1"
}

# Test installation
function Test-Installation {
    Write-Step "Testing installation..."
    
    try {
        # Test Python imports
        $testScript = @"
import sys
import streamlit
import pandas
import selenium
import undetected_chromedriver
print('✅ All Python packages imported successfully')
print(f'🐍 Python version: {sys.version}')
"@
        
        $testScript | python
        Write-Success "Python package test passed"
        
        # Test Chrome driver
        $chromeTest = @"
try:
    import undetected_chromedriver as uc
    driver = uc.Chrome(headless=True)
    driver.quit()
    print('✅ Chrome driver test passed')
except Exception as e:
    print(f'❌ Chrome driver test failed: {e}')
    raise
"@
        
        $chromeTest | python
        Write-Success "Chrome driver test passed"
        
    } catch {
        Write-Error "Installation test failed: $_"
        return $false
    }
    
    Write-Success "Installation test completed successfully"
    return $true
}

# Main installation function
function Main {
    Write-Banner
    
    # Check if already installed
    if ((Test-Path $VENV_NAME) -and (Test-Path "main.py") -and -not $Force) {
        Write-Info "Installation already exists."
        $reinstall = Read-Host "Reinstall? (y/N)"
        if ($reinstall -ne "y" -and $reinstall -ne "Y") {
            Write-Info "Installation cancelled"
            exit 0
        }
    }
    
    try {
        # Installation steps
        Write-Step "Starting installation process..."
        
        # Check/install Python
        Install-Python
        
        # Check/install Chrome
        Install-Chrome
        
        # Create virtual environment
        New-VirtualEnvironment
        
        # Activate virtual environment
        Enter-VirtualEnvironment
        
        # Install dependencies
        Install-PythonDependencies
        
        # Create directories
        New-DirectoryStructure
        
        # Setup configuration
        Initialize-Configuration
        
        # Create run script
        New-RunScript
        
        # Test installation
        if (Test-Installation) {
            # Installation complete
            Write-Host ""
            Write-Success "🎉 Installation completed successfully!"
            Write-Host ""
            Write-ColorOutput "📋 NEXT STEPS:" -Color "Cyan"
            Write-ColorOutput "   1. Configure your company details in config\settings.yaml" -Color "Yellow"
            Write-ColorOutput "   2. Add your DAT.com credentials when prompted" -Color "Yellow"
            Write-ColorOutput "   3. Run: .\run_system.ps1" -Color "Yellow"
            Write-Host ""
            Write-ColorOutput "📖 DOCUMENTATION:" -Color "Cyan"
            Write-ColorOutput "   • README.md - Complete usage guide" -Color "Yellow"
            Write-ColorOutput "   • PROJECT_PLAN.md - Technical details" -Color "Yellow"
            Write-Host ""
            Write-ColorOutput "🚀 QUICK START:" -Color "Cyan"
            Write-ColorOutput "   .\run_system.ps1" -Color "Green"
            Write-Host ""
        } else {
            Write-Error "Installation test failed. Please check the error messages above."
            exit 1
        }
        
    } catch {
        Write-Error "Installation failed: $_"
        Write-Info "Please check the error messages above and try again."
        exit 1
    }
}

# Handle Ctrl+C gracefully
$null = Register-EngineEvent -SourceIdentifier PowerShell.Exiting -SupportEvent -Action {
    Write-Host "`n🛑 Installation interrupted by user" -ForegroundColor Yellow
}

# Run main installation
Main
