#!/usr/bin/env python3
"""
🚛 DAT Real-Time Load Analyzer - Main Application Entry Point
Enterprise-grade, multi-driver, real-time load monitoring system

Features:
- Real-time DAT.com load scraping with browser automation
- Multi-driver location tracking and management
- Professional Gmail mailto integration for broker communication
- Live dashboard with deal highlighting and analytics
- Enterprise security and bulletproof error handling

Usage:
    python main.py                    # Launch full system
    python main.py --dashboard-only   # Launch dashboard only
    python main.py --setup           # Initial setup wizard
"""

import sys
import os
import argparse
import threading
import time
import signal
from pathlib import Path
from datetime import datetime

# Add src directory to Python path
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

# Core imports
try:
    from location.location_manager import EnterpriseLocationManager
    from scraper.enterprise_dat_scraper import EnterpriseDATScraper
    from communication.gmail_mailto import EnterpriseGmailSystem  
    from dashboard.real_time_dashboard import RealTimeDashboard
    from dashboard.deal_highlighter import RealTimeDealHighlighter
    from utils.enterprise_utils import check_fedora_dependencies, optimize_for_fedora
except ImportError as e:
    print(f"❌ Import error: {e}")
    print("Please ensure all dependencies are installed and you're in the correct directory")
    print("Run: pip install -r requirements.txt")
    sys.exit(1)

# Utilities
import logging
from loguru import logger
import yaml
import subprocess

class DATLoadAnalyzer:
    """
    🚀 Main Enterprise DAT Load Analyzer Application
    
    Orchestrates all components for real-time load monitoring:
    - Multi-driver location tracking
    - Live DAT.com scraping and analysis
    - Professional broker communication
    - Real-time dashboard and alerts
    """
    
    def __init__(self):
        self.location_manager = None
        self.dat_scraper = None
        self.gmail_system = None
        self.dashboard = None
        self.deal_highlighter = None
        
        self.running = False
        self.threads = []
        
        # Configure enterprise logging
        self._setup_logging()
        
        # Initialize data directories
        self._ensure_directories()
        
        logger.info("🚛 DAT Load Analyzer initializing...")
    
    def _setup_logging(self):
        """Configure enterprise logging system"""
        # Ensure logs directory exists
        os.makedirs("data/logs", exist_ok=True)
        
        # Configure loguru
        logger.add(
            "data/logs/main_application.log",
            rotation="1 day",
            retention="30 days",
            level="INFO",
            format="{time:YYYY-MM-DD HH:mm:ss} | {level} | {module}:{function}:{line} | {message}"
        )
        
        # Also log to console
        logger.add(
            sys.stdout,
            level="INFO",
            format="<green>{time:HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{module}</cyan>:<cyan>{function}</cyan> | <level>{message}</level>"
        )
    
    def _ensure_directories(self):
        """Ensure all required directories exist"""
        directories = [
            "data",
            "data/logs",
            "data/exports",
            "config"
        ]
        
        for directory in directories:
            os.makedirs(directory, exist_ok=True)
            
        logger.info("✅ Directory structure verified")
    
    def initialize_components(self):
        """Initialize all system components"""
        try:
            logger.info("🔧 Initializing system components...")
            
            # Apply Fedora optimizations
            logger.info("🐧 Applying Fedora Linux optimizations...")
            optimize_for_fedora()
            
            # Check system dependencies
            deps_status = check_fedora_dependencies()
            if not deps_status['ready']:
                logger.warning("⚠️ Some system dependencies are missing")
                logger.info("💡 Run the installation script to install missing dependencies")
            
            # Initialize location manager
            self.location_manager = EnterpriseLocationManager()
            logger.info("✅ Location manager initialized")
            
            # Initialize Gmail system
            self.gmail_system = EnterpriseGmailSystem()
            logger.info("✅ Gmail system initialized")
            
            # Initialize deal highlighter
            self.deal_highlighter = RealTimeDealHighlighter()
            logger.info("✅ Deal highlighter initialized")
            
            # Initialize DAT scraper (lazy loading)
            # Will be initialized when needed to avoid browser startup overhead
            logger.info("✅ DAT scraper ready for initialization")
            
            # Initialize dashboard
            self.dashboard = RealTimeDashboard()
            logger.info("✅ Dashboard initialized")
            
            logger.success("🚀 All components initialized successfully!")
            return True
            
        except Exception as e:
            logger.error(f"❌ Component initialization failed: {str(e)}")
            return False
    
    def run_setup_wizard(self):
        """Interactive setup wizard for first-time configuration"""
        logger.info("🔧 Starting setup wizard...")
        
        print("\n" + "="*60)
        print("🚛 DAT REAL-TIME LOAD ANALYZER - SETUP WIZARD")
        print("="*60)
        
        # Check Python version
        if sys.version_info < (3, 9):
            print("❌ Python 3.9+ is required")
            return False
        
        # Create config files if they don't exist
        self._create_default_configs()
        
        # Test system components
        self._test_components()
        
        print("\n✅ Setup completed successfully!")
        print("🚀 Run 'python main.py' to start the system")
        return True
    
    def _create_default_configs(self):
        """Create default configuration files"""
        # Settings config
        settings_path = "config/settings.yaml"
        if not os.path.exists(settings_path):
            default_settings = {
                'company': {
                    'name': 'Your Transportation Company',
                    'contact_name': 'Your Name',
                    'phone': '(555) 123-4567',
                    'email': 'your.email@company.com',
                    'address': 'Your Company Address'
                },
                'system': {
                    'auto_refresh_interval': 30,
                    'max_loads_to_display': 50,
                    'default_radius_miles': 150,
                    'browser_headless': False
                },
                'alerts': {
                    'high_profit_threshold': 2000,
                    'excellent_deal_threshold': 3000,
                    'enable_sound_alerts': True
                }
            }
            
            with open(settings_path, 'w') as f:
                yaml.dump(default_settings, f, default_flow_style=False)
            
            logger.info(f"✅ Created default settings: {settings_path}")
        
        # Email templates
        templates_path = "config/email_templates.yaml"
        if not os.path.exists(templates_path):
            default_templates = {
                'initial_inquiry': {
                    'subject': 'Load Inquiry: {load_id} - {origin} to {destination}',
                    'body': '''Hello,

I hope this message finds you well. I am writing to inquire about the load opportunity posted on DAT:

📋 LOAD DETAILS:
• Load ID: {load_id}
• Route: {origin} → {destination}
• Distance: {miles} miles
• Equipment: {equipment_type}

💰 RATE DISCUSSION:
Based on current market conditions, we would be interested in discussing a rate of ${proposed_rate} for this shipment.

Please let me know if this load is still available and if you would like to discuss the details further.

Best regards,
{contact_name}
{company_name}
📞 {phone}'''
                },
                'follow_up': {
                    'subject': 'Following Up: {load_id} - {origin} to {destination}',
                    'body': '''Hello,

I wanted to follow up on my previous inquiry regarding load {load_id} from {origin} to {destination}.

We have a professional driver ready and available in the area. Please let me know if this load is still available for booking.

Thank you for your time.

Best regards,
{contact_name}
{company_name}
📞 {phone}'''
                }
            }
            
            with open(templates_path, 'w') as f:
                yaml.dump(default_templates, f, default_flow_style=False)
            
            logger.info(f"✅ Created default email templates: {templates_path}")
    
    def _test_components(self):
        """Test system components"""
        logger.info("🧪 Testing system components...")
        
        try:
            # Test imports
            import streamlit
            import selenium
            import pandas
            import plotly
            logger.info("✅ All Python packages available")
            
            # Test browser
            try:
                import undetected_chromedriver as uc
                logger.info("✅ Chrome driver available")
            except Exception as e:
                logger.warning(f"⚠️ Chrome driver issue: {str(e)}")
            
            # Test database
            location_mgr = EnterpriseLocationManager()
            test_driver = location_mgr.add_driver("Test Driver", "555-1234", "Dry Van")
            location_mgr.remove_driver(test_driver)
            logger.info("✅ Database operations working")
            
        except Exception as e:
            logger.error(f"❌ Component test failed: {str(e)}")
    
    def launch_dashboard_only(self):
        """Launch only the dashboard component"""
        logger.info("🚀 Launching dashboard-only mode...")
        
        try:
            # Initialize minimal components
            self.initialize_components()
            
            # Launch Streamlit dashboard
            dashboard_path = os.path.join("src", "dashboard", "real_time_dashboard.py")
            
            cmd = [
                "streamlit", "run", dashboard_path,
                "--server.port", "8501",
                "--server.address", "localhost",
                "--browser.gatherUsageStats", "false",
                "--theme.primaryColor", "#007BFF",
                "--theme.backgroundColor", "#FFFFFF"
            ]
            
            logger.info("🌐 Starting Streamlit dashboard...")
            subprocess.run(cmd)
            
        except KeyboardInterrupt:
            logger.info("🛑 Dashboard stopped by user")
        except Exception as e:
            logger.error(f"❌ Dashboard launch failed: {str(e)}")
    
    def launch_full_system(self):
        """Launch the complete real-time system"""
        logger.info("🚀 Launching full system...")
        
        if not self.initialize_components():
            logger.error("❌ System initialization failed")
            return False
        
        try:
            self.running = True
            
            # Start background services
            logger.info("🔄 Starting background services...")
            
            # Start location tracking
            location_thread = threading.Thread(
                target=self._run_location_tracking,
                daemon=True
            )
            location_thread.start()
            self.threads.append(location_thread)
            
            # Launch dashboard in main thread
            self.launch_dashboard_only()
            
        except KeyboardInterrupt:
            logger.info("🛑 System stopped by user")
            self.shutdown()
        except Exception as e:
            logger.error(f"❌ System error: {str(e)}")
            self.shutdown()
    
    def _run_location_tracking(self):
        """Background location tracking service"""
        logger.info("📍 Location tracking service started")
        
        while self.running:
            try:
                # Perform location tracking tasks
                # This could include checking for location updates,
                # validating driver positions, etc.
                time.sleep(30)  # Check every 30 seconds
                
            except Exception as e:
                logger.error(f"❌ Location tracking error: {str(e)}")
                time.sleep(10)  # Wait before retrying
    
    def shutdown(self):
        """Graceful system shutdown"""
        logger.info("🛑 Shutting down system...")
        
        self.running = False
        
        # Close DAT scraper if active
        if self.dat_scraper:
            try:
                self.dat_scraper.close()
                logger.info("✅ DAT scraper closed")
            except Exception as e:
                logger.error(f"❌ Error closing DAT scraper: {str(e)}")
        
        # Wait for threads to finish
        for thread in self.threads:
            thread.join(timeout=5)
        
        logger.success("✅ System shutdown complete")

def signal_handler(sig, frame):
    """Handle system signals for graceful shutdown"""
    logger.info("🛑 Received shutdown signal")
    sys.exit(0)

def main():
    """Main application entry point"""
    # Set up signal handlers
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # Parse command line arguments
    parser = argparse.ArgumentParser(
        description="🚛 DAT Real-Time Load Analyzer",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    python main.py                    # Launch full system
    python main.py --dashboard-only   # Launch dashboard only
    python main.py --setup           # Run setup wizard
        """
    )
    
    parser.add_argument(
        '--dashboard-only',
        action='store_true',
        help='Launch only the dashboard component'
    )
    
    parser.add_argument(
        '--setup',
        action='store_true',
        help='Run the initial setup wizard'
    )
    
    parser.add_argument(
        '--debug',
        action='store_true',
        help='Enable debug logging'
    )
    
    args = parser.parse_args()
    
    # Initialize application
    app = DATLoadAnalyzer()
    
    try:
        if args.setup:
            success = app.run_setup_wizard()
            sys.exit(0 if success else 1)
        elif args.dashboard_only:
            app.launch_dashboard_only()
        else:
            app.launch_full_system()
            
    except KeyboardInterrupt:
        logger.info("🛑 Application interrupted by user")
        app.shutdown()
    except Exception as e:
        logger.error(f"❌ Application error: {str(e)}")
        app.shutdown()
        sys.exit(1)

if __name__ == "__main__":
    main()
