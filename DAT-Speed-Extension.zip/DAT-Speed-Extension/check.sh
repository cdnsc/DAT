#!/bin/bash
# 🧪 System Check - Verify Installation
# Run this to check what's installed and working

echo "🧪 SYSTEM VERIFICATION CHECK"
echo "=========================="
echo ""

# Check Fedora version
echo "🐧 System Information:"
if [ -f /etc/fedora-release ]; then
    echo "✅ Fedora: $(cat /etc/fedora-release)"
else
    echo "⚠️ Not running on Fedora"
fi
echo ""

# Check Python
echo "🐍 Python Information:"
python3 --version || echo "❌ Python3 not found"
python3 -m pip --version || echo "❌ pip not found"
echo ""

# Check system packages
echo "📦 System Packages:"
rpm -q libxml2-devel &>/dev/null && echo "✅ libxml2-devel installed" || echo "❌ libxml2-devel missing"
rpm -q libxslt-devel &>/dev/null && echo "✅ libxslt-devel installed" || echo "❌ libxslt-devel missing"
rpm -q python3-devel &>/dev/null && echo "✅ python3-devel installed" || echo "❌ python3-devel missing"
rpm -q gcc &>/dev/null && echo "✅ gcc installed" || echo "❌ gcc missing"
echo ""

# Check Python packages
echo "🐍 Python Packages:"
python3 -c "import lxml; print('✅ lxml:', lxml.__version__)" 2>/dev/null || echo "❌ lxml not working"
python3 -c "import selenium; print('✅ selenium:', selenium.__version__)" 2>/dev/null || echo "❌ selenium not working"
python3 -c "import streamlit; print('✅ streamlit:', streamlit.__version__)" 2>/dev/null || echo "❌ streamlit not working"
echo ""

# Check Chrome
echo "🌐 Browser:"
google-chrome --version 2>/dev/null && echo "✅ Google Chrome found" || echo "❌ Google Chrome missing"
echo ""

echo "🔍 DIAGNOSIS:"
if python3 -c "import lxml" 2>/dev/null; then
    echo "✅ System is ready! Run: ./start.sh"
else
    echo "❌ lxml issues detected. Try:"
    echo "   1. ./emergency-fix.sh"
    echo "   2. ./ultimate-fix.sh"
    echo "   3. ./simple-install.sh"
fi
