#!/bin/bash
# 🔧 Quick lxml Fix for Fedora
# Run this if you get lxml compilation errors

echo "🔧 Installing XML development libraries..."
sudo dnf install -y libxml2-devel libxslt-devel python3-devel gcc

echo "📦 Installing lxml directly..."
python3 -m pip install --upgrade pip
python3 -m pip install --no-cache-dir lxml==5.1.0

echo "✅ lxml fix complete!"
echo "💡 Now run: python3 -m pip install -r requirements.txt"
