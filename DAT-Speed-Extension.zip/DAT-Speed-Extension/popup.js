// popup.js - Enterprise DAT Speed Extension Popup Controller
// Handles popup UI logic and quick actions

// Firefox compatibility
const browser_api = chrome || browser;
const isFirefox = typeof browser !== 'undefined';

class DATSpeedPopup {
  constructor() {
    this.initializeEventListeners();
    this.loadStats();
    this.updateUI();
  }

  async initializeEventListeners() {
    // Open sidebar button
    document.getElementById('open-sidebar').onclick = () => this.openSidebar();
    
    // Quick action buttons - check if elements exist first
    const autoMonitorBtn = document.getElementById('auto-monitor');
    const quickFilterBtn = document.getElementById('quick-filter');
    const aiScorerBtn = document.getElementById('ai-scorer');
    const profitAnalyzerBtn = document.getElementById('profit-analyzer');
    const openOptionsBtn = document.getElementById('open-options');
    
    if (autoMonitorBtn) autoMonitorBtn.onclick = () => this.toggleAutoMonitor();
    if (quickFilterBtn) quickFilterBtn.onclick = () => this.applyQuickFilter();
    if (aiScorerBtn) aiScorerBtn.onclick = () => this.toggleAIScorer();
    if (profitAnalyzerBtn) profitAnalyzerBtn.onclick = () => this.openProfitAnalyzer();
    if (openOptionsBtn) openOptionsBtn.onclick = () => this.openOptions();
    
    // Real-time updates
    this.setupRealtimeUpdates();
  }

  async openSidebar() {
    try {
      const tabs = await browser_api.tabs.query({active: true, currentWindow: true});
      if (tabs[0]) {
        // Send message to content script to show sidebar
        try {
          await browser_api.tabs.sendMessage(tabs[0].id, {
            action: 'showSidebar'
          });
        } catch (e) {
          console.log('Content script not ready, will inject');
        }
        
        // Inject content script - Firefox uses different API
        if (isFirefox) {
          try {
            await browser_api.tabs.executeScript(tabs[0].id, {
              file: 'content.js'
            });
          } catch (e) {
            console.log('Could not inject script:', e);
          }
        } else {
          try {
            await browser_api.scripting.executeScript({
              target: {tabId: tabs[0].id},
              files: ['content.js']
            });
          } catch (e) {
            console.log('Could not inject script:', e);
          }
        }
      }
    } catch (error) {
      console.log('Extension working in background mode:', error);
    }
  }

  async toggleAutoMonitor() {
    try {
      const tabs = await browser_api.tabs.query({active: true, currentWindow: true});
      if (tabs[0]) {
        const isEnabled = await this.getStorageValue('autoMonitorEnabled', false);
        await browser_api.storage.sync.set({autoMonitorEnabled: !isEnabled});
        // Send message to service worker
        browser_api.runtime.sendMessage({
          action: 'toggleAutoMonitor',
          enabled: !isEnabled
        });
        
        this.updateUI();
      }
    } catch (error) {
      console.error('Error toggling auto monitor:', error);
    }
  }

  async applyQuickFilter() {
    try {
      const tabs = await browser_api.tabs.query({active: true, currentWindow: true});
      if (tabs[0]) {
        await browser_api.tabs.sendMessage(tabs[0].id, {
          action: 'applyQuickFilter',
          filters: {
            minRate: 2.5,
            maxMiles: 500,
            preferredStates: ['TX', 'CA', 'FL']
          }
        });
      }
    } catch (error) {
      console.error('Error applying quick filter:', error);
    }
  }

  async toggleAIScorer() {
    try {
      const isEnabled = await this.getStorageValue('aiScoringEnabled', true);
      await browser_api.storage.sync.set({aiScoringEnabled: !isEnabled});
      
      const tabs = await browser_api.tabs.query({active: true, currentWindow: true});
      if (tabs[0]) {
        await browser_api.tabs.sendMessage(tabs[0].id, {
          action: 'toggleAIScoring',
          enabled: !isEnabled
        });
      }
      
      this.updateUI();
    } catch (error) {
      console.error('Error toggling AI scorer:', error);
    }
  }

  async openProfitAnalyzer() {
    try {
      const tabs = await browser_api.tabs.query({active: true, currentWindow: true});
      if (tabs[0]) {
        await browser_api.tabs.sendMessage(tabs[0].id, {
          action: 'openProfitAnalyzer'
        });
      }
    } catch (error) {
      console.error('Error opening profit analyzer:', error);
    }
  }

  openOptions() {
    if (browser_api.runtime.openOptionsPage) {
      browser_api.runtime.openOptionsPage();
    } else {
      // Firefox fallback
      browser_api.tabs.create({ url: browser_api.runtime.getURL('options.html') });
    }
  }

  async loadStats() {
    try {
      const stats = await this.getStorageValue('extensionStats', {
        loadsAnalyzed: 0,
        profitableLoads: 0,
        totalProfit: 0,
        autoBookings: 0
      });
      
      document.getElementById('loads-analyzed').textContent = stats.loadsAnalyzed;
      document.getElementById('profitable-loads').textContent = stats.profitableLoads;
      document.getElementById('total-profit').textContent = `$${stats.totalProfit.toLocaleString()}`;
      document.getElementById('auto-bookings').textContent = stats.autoBookings;
    } catch (error) {
      console.error('Error loading stats:', error);
    }
  }

  async updateUI() {
    const autoMonitorEnabled = await this.getStorageValue('autoMonitorEnabled', false);
    const aiScoringEnabled = await this.getStorageValue('aiScoringEnabled', true);
    
    const autoMonitorBtn = document.getElementById('auto-monitor');
    const aiScorerBtn = document.getElementById('ai-scorer');
    
    if (autoMonitorBtn) {
      autoMonitorBtn.textContent = autoMonitorEnabled ? '🔴 Stop Monitor' : '🟢 Start Monitor';
      autoMonitorBtn.className = autoMonitorEnabled ? 'dat-btn dat-btn-active' : 'dat-btn';
    }
    
    if (aiScorerBtn) {
      aiScorerBtn.textContent = aiScoringEnabled ? '🧠 AI: ON' : '🧠 AI: OFF';
      aiScorerBtn.className = aiScoringEnabled ? 'dat-btn dat-btn-active' : 'dat-btn';
    }
  }

  setupRealtimeUpdates() {
    // Listen for updates from service worker
    browser_api.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.action === 'updateStats') {
        this.loadStats();
      } else if (message.action === 'updateUI') {
        this.updateUI();
      }
    });
    
    // Refresh stats every 5 seconds
    setInterval(() => this.loadStats(), 5000);
  }

  async getStorageValue(key, defaultValue) {
    try {
      const result = await browser_api.storage.sync.get(key);
      return result[key] !== undefined ? result[key] : defaultValue;
    } catch (error) {
      return defaultValue;
    }
  }
}

// Initialize popup when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  new DATSpeedPopup();
});
