# DAT Speed Pro - Enterprise Chrome Extension

A comprehensive Chrome extension for DAT One load board optimization with AI-powered features, real-time monitoring, and enterprise-grade functionality.

## Features

### 🚀 Core Features
- **Smart Load Filtering**: Filter by rate, DHO, miles, weight, and location
- **AI Load Scoring**: Advanced AI algorithm scores loads based on profitability
- **Real-time Monitoring**: Continuously monitors for new loads
- **Auto-booking**: Automatically book high-scoring loads (with confirmation)
- **Profit Calculator**: Real-time profit analysis with fuel, driver pay, and cost calculations

### 🧠 AI & Automation
- **Machine Learning**: Learns from your booking patterns
- **Predictive Analytics**: Predicts load profitability and market trends
- **Smart Recommendations**: Suggests optimal loads based on your criteria
- **Auto-negotiation**: Sends rate inquiry templates automatically

### 📊 Analytics & Reporting
- **Performance Dashboard**: Track loads analyzed, profit margins, and success rates
- **Market Intelligence**: Lane analysis and rate trends
- **Broker Ratings**: Historical performance tracking of brokers
- **ROI Tracking**: Calculate return on investment per load

### 🏢 Enterprise Features
- **Multi-user Support**: Team collaboration and shared settings
- **CRM Integration**: Connect with Salesforce, HubSpot, Pipedrive
- **Custom Templates**: Personalized communication templates
- **Advanced Filtering**: Complex filter combinations and saved searches
- **Audit Trail**: Complete activity logging for compliance

## Installation

1. **Download the Extension**
   - Clone or download this repository
   - Ensure all files are in the same directory

2. **Load in Chrome**
   - Open Chrome and go to `chrome://extensions/`
   - Enable "Developer mode" (top right toggle)
   - Click "Load unpacked" and select the extension folder
   - The DAT Speed Pro icon should appear in your toolbar

3. **Configure Settings**
   - Click the extension icon and select "Settings & Config"
   - Set up your filters, profit parameters, and AI preferences
   - Configure templates and enterprise features

## Usage

### Quick Start
1. Navigate to DAT One load board
2. Click the DAT Speed Pro extension icon
3. Click "🚀 Open Control Center" to launch the sidebar
4. The extension will automatically enhance the load table with:
   - AI scores for each load
   - Profit calculations
   - Smart highlighting
   - Quick action buttons

### Setting Up Filters
1. Go to Settings → Load Filters
2. Configure your preferred:
   - Minimum rate per mile
   - Maximum DHO (deadhead out)
   - Equipment types
   - Origin/destination states
   - Weight requirements

### AI Configuration
1. Navigate to Settings → AI & Automation
2. Enable AI Load Scoring
3. Set confidence threshold (recommended: 80%)
4. Configure profit analysis parameters:
   - Fuel cost per gallon
   - Truck MPG
   - Driver pay per mile
   - Other operational costs

### Auto-monitoring
1. Click "🟢 Start Monitor" in the popup
2. Extension will check for new loads every 30 seconds
3. High-scoring loads will trigger notifications
4. Optional auto-booking with user confirmation

## Configuration Options

### Load Filters
- **Minimum Rate**: Filter loads below specified rate per mile
- **Maximum DHO**: Exclude loads with high deadhead miles
- **Equipment Types**: Van, Reefer, Flatbed, Step Deck, Double Drop
- **Geographic Preferences**: Origin and destination states
- **Weight Requirements**: Minimum and maximum weight limits

### AI Settings
- **Scoring Algorithm**: Enable/disable AI-powered load scoring
- **Confidence Threshold**: Minimum confidence level for recommendations
- **Learning Mode**: Allow AI to learn from your booking patterns
- **Auto-actions**: Configure automated booking and negotiation

### Enterprise Options
- **CRM Integration**: Connect with your customer relationship management system
- **Team Collaboration**: Share settings and performance data
- **Compliance Logging**: Maintain audit trails for regulatory compliance
- **API Access**: Custom integrations and data export

## Support & Documentation

### Troubleshooting
- Ensure you're on a DAT One load board page
- Check that the extension is enabled and permissions are granted
- Verify filter settings aren't too restrictive
- Clear browser cache if experiencing issues

### Performance Tips
- Use reasonable filter ranges to avoid overloading
- Set AI confidence threshold between 70-90%
- Monitor system resources during auto-monitoring
- Regularly update profit calculation parameters

### Enterprise Support
- Multi-tenant architecture for fleet management
- Custom onboarding and training available
- Dedicated support channel for enterprise customers
- API documentation for custom integrations

## Technical Specifications

- **Manifest Version**: 3.0
- **Minimum Chrome Version**: 88+
- **Permissions**: Active tab, storage, notifications, scripting
- **Architecture**: Service worker with content script injection
- **Storage**: Chrome Sync API for cross-device settings
- **AI Engine**: Custom scoring algorithm with machine learning

## Security & Privacy

- All data processing happens locally in your browser
- No load data is transmitted to external servers
- Settings sync securely through Chrome's built-in sync
- Enterprise deployments can disable external connectivity

## Changelog

### Version 2.0 (Enterprise Edition)
- Complete rewrite with Manifest V3
- Added AI-powered load scoring
- Implemented real-time monitoring
- Enhanced profit calculator
- Added enterprise features (CRM integration, multi-user)
- Improved UI with modern design
- Advanced analytics and reporting
- Auto-booking with safety controls

### Version 1.0 (Legacy)
- Basic load highlighting
- Simple filtering
- Email templates
- Manual profit calculation

## License

© 2025 DAT Speed Pro. Enterprise License. All rights reserved.

## Support

For technical support, feature requests, or enterprise licensing:
- Email: support@datspeed.com
- Documentation: https://docs.datspeed.com
- Enterprise Sales: enterprise@datspeed.com
