"""
🚀 Real-Time Multi-User Dashboard
Main dashboard integrating all components for live load monitoring
"""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
import time
import json
import threading
import sys
import os

# Add src directory to Python path
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from location.location_manager import RealTimeLocationManager
from communication.gmail_mailto import GmailMailtoSystem
from dashboard.deal_highlighter import RealTimeDealHighlighter

class RealTimeDashboard:
    def __init__(self):
        self.location_manager = RealTimeLocationManager()
        self.gmail_system = GmailMailtoSystem()
        self.deal_highlighter = RealTimeDealHighlighter()
        
        # Initialize session state
        if 'loads_data' not in st.session_state:
            st.session_state.loads_data = []
        if 'driver_location' not in st.session_state:
            st.session_state.driver_location = None
        if 'auto_refresh' not in st.session_state:
            st.session_state.auto_refresh = True
        if 'refresh_interval' not in st.session_state:
            st.session_state.refresh_interval = 30
        if 'alert_count' not in st.session_state:
            st.session_state.alert_count = 0
    
    def run_dispatcher_dashboard(self):
        """🎛️ Main dispatcher dashboard with real-time monitoring"""
        
        st.set_page_config(
            page_title="🚛 DAT Real-Time Load Monitor",
            page_icon="🚛",
            layout="wide",
            initial_sidebar_state="expanded"
        )
        
        # Custom CSS for real-time styling
        st.markdown("""
        <style>
        .excellent-deal {
            background-color: #FFE5E5;
            border: 2px solid #FF0000;
            border-radius: 8px;
            padding: 10px;
            margin: 5px 0;
            animation: flash 2s infinite;
        }
        
        .high-profit {
            background-color: #E5FFE5;
            border: 2px solid #00AA00;
            border-radius: 8px;
            padding: 10px;
            margin: 5px 0;
        }
        
        .good-opportunity {
            background-color: #FFF5E5;
            border: 2px solid #FFB000;
            border-radius: 8px;
            padding: 10px;
            margin: 5px 0;
        }
        
        @keyframes flash {
            0% { background-color: #FFE5E5; }
            50% { background-color: #FF9999; }
            100% { background-color: #FFE5E5; }
        }
        
        .metric-card {
            background-color: #F8F9FA;
            padding: 20px;
            border-radius: 10px;
            border-left: 5px solid #007BFF;
            margin: 10px 0;
        }
        
        .email-button {
            background-color: #007BFF;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
            text-decoration: none;
            margin: 2px;
            display: inline-block;
        }
        </style>
        """, unsafe_allow_html=True)
        
        # Header with real-time status
        col1, col2, col3 = st.columns([2, 1, 1])
        
        with col1:
            st.title("🚛 DAT Real-Time Load Monitor")
            
        with col2:
            if st.session_state.auto_refresh:
                st.success("🔄 Live Updates ON")
            else:
                st.warning("⏸️ Live Updates OFF")
                
        with col3:
            current_time = datetime.now().strftime("%H:%M:%S")
            st.info(f"🕐 {current_time}")
        
        # Sidebar controls
        self._render_sidebar()
        
        # Main content tabs
        tab1, tab2, tab3, tab4 = st.tabs([
            "🚀 Live Loads", 
            "📍 Driver Location", 
            "📊 Analytics", 
            "📧 Email Center"
        ])
        
        with tab1:
            self._render_live_loads_tab()
            
        with tab2:
            self._render_driver_location_tab()
            
        with tab3:
            self._render_analytics_tab()
            
        with tab4:
            self._render_email_center_tab()
        
        # Auto-refresh mechanism
        if st.session_state.auto_refresh:
            time.sleep(st.session_state.refresh_interval)
            st.experimental_rerun()
    
    def _render_sidebar(self):
        """Render sidebar controls"""
        with st.sidebar:
            st.header("⚙️ Controls")
            
            # Auto-refresh controls
            st.session_state.auto_refresh = st.toggle(
                "🔄 Auto Refresh", 
                value=st.session_state.auto_refresh
            )
            
            if st.session_state.auto_refresh:
                st.session_state.refresh_interval = st.slider(
                    "Refresh Interval (seconds)", 
                    10, 120, st.session_state.refresh_interval
                )
            
            # Manual refresh button
            if st.button("🔄 Refresh Now", type="primary"):
                self._fetch_new_loads()
                st.experimental_rerun()
            
            # Filter controls
            st.subheader("🔍 Filters")
            
            min_rate = st.number_input("Min Rate/Mile ($)", 0.0, 10.0, 2.0, 0.25)
            max_deadhead = st.number_input("Max Deadhead (miles)", 0, 500, 100, 25)
            equipment_type = st.selectbox(
                "Equipment Type", 
                ["All", "Dry Van", "Flatbed", "Reefer", "Step Deck"]
            )
            
            # Alert settings
            st.subheader("🔔 Alerts")
            
            alert_excellent = st.checkbox("🔥 Excellent Deals", True)
            alert_high_profit = st.checkbox("💰 High Profit", True)
            sound_alerts = st.checkbox("🔊 Sound Alerts", False)
            
            # Statistics
            st.subheader("📊 Session Stats")
            stats = self.deal_highlighter.get_real_time_stats()
            st.metric("Total Loads", stats['total_processed'])
            st.metric("🔥 Excellent", stats['alert_counts']['excellent'])
            st.metric("💰 High Profit", stats['alert_counts']['high_profit'])
    
    def _render_live_loads_tab(self):
        """Render live loads monitoring tab"""
        st.header("🚀 Live Load Feed")
        
        # Real-time metrics
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("🔥 Excellent Deals", st.session_state.alert_count, "🔥")
        with col2:
            st.metric("💰 High Profit", 0, "💰")
        with col3:
            st.metric("⭐ Good Opportunities", 0, "⭐")
        with col4:
            st.metric("📊 Total Loads", len(st.session_state.loads_data), "📊")
        
        # Load feed
        if st.session_state.loads_data:
            for load in st.session_state.loads_data:
                self._render_load_card(load)
        else:
            st.info("🔍 No loads found. Adjust your filters or check your connection.")
            
            # Sample data button for demo
            if st.button("📋 Load Sample Data"):
                self._load_sample_data()
                st.experimental_rerun()
    
    def _render_load_card(self, load_data):
        """Render individual load card with highlighting"""
        
        # Generate visual highlighting
        visual = self.deal_highlighter.generate_visual_indicators(
            load_data, st.session_state.driver_location
        )
        
        # Determine CSS class based on score
        if visual['score'] >= 90:
            css_class = "excellent-deal"
        elif visual['score'] >= 75:
            css_class = "high-profit"
        elif visual['score'] >= 60:
            css_class = "good-opportunity"
        else:
            css_class = ""
        
        # Create load card
        with st.container():
            if css_class:
                st.markdown(f'<div class="{css_class}">', unsafe_allow_html=True)
            
            col1, col2, col3, col4 = st.columns([3, 2, 2, 3])
            
            with col1:
                st.markdown(f"""
                **{visual['highlight']['icon']} {load_data.get('load_id', 'N/A')}**
                
                📍 **{load_data.get('origin', 'Unknown')}** → **{load_data.get('destination', 'Unknown')}**
                
                🚛 {load_data.get('miles', 0)} miles | {load_data.get('equipment_type', 'Dry Van')}
                """)
            
            with col2:
                st.markdown(f"""
                **💰 ${load_data.get('rate_per_mile', 0.00)}/mile**
                
                **📦 {load_data.get('weight', 'N/A')}**
                
                **⏰ {load_data.get('pickup_date', 'ASAP')}**
                """)
            
            with col3:
                st.markdown(f"""
                **📊 Score: {visual['score']}/100**
                
                **🎯 {visual['highlight']['label']}**
                
                **📏 Deadhead: {load_data.get('deadhead_miles', 0)} mi**
                """)
            
            with col4:
                # Email buttons
                broker_email = load_data.get('broker_email', 'broker@example.com')
                
                email_buttons = self.gmail_system.create_quick_email_buttons(
                    load_data, broker_email, 
                    st.session_state.driver_location.get('city', '') if st.session_state.driver_location else ''
                )
                
                for button_label, mailto_url in email_buttons.items():
                    if st.button(button_label, key=f"{load_data.get('load_id')}_{button_label}"):
                        # Open mailto link
                        st.markdown(f'<a href="{mailto_url}" target="_blank">Open Gmail</a>', 
                                  unsafe_allow_html=True)
            
            if css_class:
                st.markdown('</div>', unsafe_allow_html=True)
            
            st.divider()
    
    def _render_driver_location_tab(self):
        """Render driver location management tab"""
        st.header("📍 Driver Location Management")
        
        col1, col2 = st.columns([1, 1])
        
        with col1:
            st.subheader("🚛 Update Driver Location")
            
            city = st.text_input("City", value="Chicago")
            state = st.selectbox("State", [
                "AL", "AK", "AZ", "AR", "CA", "CO", "CT", "DE", "FL", "GA",
                "HI", "ID", "IL", "IN", "IA", "KS", "KY", "LA", "ME", "MD",
                "MA", "MI", "MN", "MS", "MO", "MT", "NE", "NV", "NH", "NJ",
                "NM", "NY", "NC", "ND", "OH", "OK", "OR", "PA", "RI", "SC",
                "SD", "TN", "TX", "UT", "VT", "VA", "WA", "WV", "WI", "WY"
            ], index=12)  # Default to IL
            
            if st.button("📍 Update Location", type="primary"):
                result = self.location_manager.update_driver_location(city, state)
                st.session_state.driver_location = result
                st.success(f"✅ Driver location updated to {city}, {state}")
                st.experimental_rerun()
        
        with col2:
            st.subheader("📍 Current Location")
            
            if st.session_state.driver_location:
                location = st.session_state.driver_location
                st.info(f"""
                **🏙️ City:** {location.get('city', 'Unknown')}
                
                **🏛️ State:** {location.get('state', 'Unknown')}
                
                **🕐 Last Update:** {location.get('timestamp', 'Unknown')}
                
                **📊 Status:** {location.get('status', 'Unknown')}
                """)
                
                # Nearby cities
                if location.get('latitude') and location.get('longitude'):
                    nearby_cities = self.location_manager.find_nearby_cities(150)
                    
                    if nearby_cities:
                        st.subheader("🌍 Nearby Cities (150 miles)")
                        for city in nearby_cities[:5]:
                            st.write(f"📍 {city['city']}, {city['state']} - {city['distance_miles']} miles")
            else:
                st.warning("⚠️ No driver location set. Please update location above.")
    
    def _render_analytics_tab(self):
        """Render analytics and charts tab"""
        st.header("📊 Real-Time Analytics")
        
        if not st.session_state.loads_data:
            st.info("📊 No data available for analytics. Load some sample data first.")
            return
        
        # Create DataFrame for analysis
        df = pd.DataFrame(st.session_state.loads_data)
        
        col1, col2 = st.columns(2)
        
        with col1:
            # Rate distribution chart
            if 'rate_per_mile' in df.columns:
                fig_rate = px.histogram(
                    df, x='rate_per_mile', 
                    title="📊 Rate Distribution ($/mile)",
                    labels={'rate_per_mile': 'Rate per Mile ($)', 'count': 'Number of Loads'}
                )
                st.plotly_chart(fig_rate, use_container_width=True)
        
        with col2:
            # Distance vs Rate scatter plot
            if 'miles' in df.columns and 'rate_per_mile' in df.columns:
                fig_scatter = px.scatter(
                    df, x='miles', y='rate_per_mile',
                    title="📏 Distance vs Rate Analysis",
                    labels={'miles': 'Miles', 'rate_per_mile': 'Rate per Mile ($)'}
                )
                st.plotly_chart(fig_scatter, use_container_width=True)
        
        # Summary statistics
        st.subheader("📈 Summary Statistics")
        
        if 'rate_per_mile' in df.columns:
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                avg_rate = df['rate_per_mile'].mean()
                st.metric("💰 Average Rate", f"${avg_rate:.2f}/mile")
            
            with col2:
                max_rate = df['rate_per_mile'].max()
                st.metric("🔥 Highest Rate", f"${max_rate:.2f}/mile")
            
            with col3:
                if 'miles' in df.columns:
                    avg_miles = df['miles'].mean()
                    st.metric("📏 Average Distance", f"{avg_miles:.0f} miles")
            
            with col4:
                load_count = len(df)
                st.metric("📊 Total Loads", load_count)
    
    def _render_email_center_tab(self):
        """Render email management center"""
        st.header("📧 Email Communication Center")
        
        st.subheader("📋 Email Templates")
        
        # Template selection
        template_type = st.selectbox("Select Template", [
            "initial_inquiry",
            "rate_negotiation", 
            "follow_up",
            "booking_confirmation"
        ])
        
        # Sample load for template preview
        sample_load = {
            'load_id': 'DAT123456',
            'origin': 'Chicago, IL',
            'destination': 'Atlanta, GA',
            'miles': 465,
            'rate_per_mile': 2.25,
            'equipment_type': 'Dry Van',
            'weight': '34,000 lbs',
            'commodity': 'Electronics',
            'pickup_date': 'Today 2:00 PM',
            'delivery_date': 'Tomorrow 8:00 AM',
            'broker_email': 'broker@example.com'
        }
        
        # Generate email data
        email_data = self.gmail_system.generate_load_email_data(
            sample_load, 
            st.session_state.driver_location.get('city', '') if st.session_state.driver_location else ''
        )
        company_data = self.gmail_system.get_company_data()
        
        # Preview email
        st.subheader("👁️ Email Preview")
        
        template = self.gmail_system.templates[template_type]
        subject = template['subject'].format(**email_data, **company_data)
        body = template['body'].format(**email_data, **company_data)
        
        st.write("**Subject:**", subject)
        st.text_area("**Email Body:**", body, height=300)
        
        # Create mailto link
        broker_email = st.text_input("Broker Email", "broker@example.com")
        
        if st.button("📧 Open Gmail Compose", type="primary"):
            mailto_url = self.gmail_system.create_mailto_link(
                broker_email, template_type, email_data, company_data
            )
            st.markdown(f'<a href="{mailto_url}" target="_blank" class="email-button">🚀 Open Gmail</a>', 
                      unsafe_allow_html=True)
            st.success("✅ Gmail compose window should open in your default browser!")
    
    def _fetch_new_loads(self):
        """Fetch new loads (placeholder for real DAT integration)"""
        # This would integrate with the actual DAT scraper
        # For now, we'll use sample data
        pass
    
    def _load_sample_data(self):
        """Load sample data for demonstration"""
        sample_loads = [
            {
                'load_id': 'DAT001',
                'origin': 'Chicago, IL',
                'destination': 'Atlanta, GA',
                'rate_per_mile': 3.25,
                'miles': 465,
                'deadhead_miles': 20,
                'equipment_type': 'Dry Van',
                'weight': '45,000 lbs',
                'commodity': 'Electronics',
                'pickup_date': 'Today 2:00 PM',
                'delivery_date': 'Tomorrow 10:00 AM',
                'broker_email': 'broker1@example.com',
                'pickup_urgency': 'asap',
                'equipment_match': True,
                'lane_popularity': 'high'
            },
            {
                'load_id': 'DAT002',
                'origin': 'Dallas, TX',
                'destination': 'Phoenix, AZ',
                'rate_per_mile': 2.10,
                'miles': 887,
                'deadhead_miles': 85,
                'equipment_type': 'Flatbed',
                'weight': '38,000 lbs',
                'commodity': 'Steel',
                'pickup_date': 'Tomorrow 8:00 AM',
                'delivery_date': 'Day after 6:00 PM',
                'broker_email': 'broker2@example.com',
                'pickup_urgency': 'tomorrow',
                'equipment_match': False,
                'lane_popularity': 'medium'
            },
            {
                'load_id': 'DAT003',
                'origin': 'Los Angeles, CA',
                'destination': 'Seattle, WA',
                'rate_per_mile': 2.85,
                'miles': 1135,
                'deadhead_miles': 45,
                'equipment_type': 'Reefer',
                'weight': '42,000 lbs',
                'commodity': 'Produce',
                'pickup_date': 'ASAP',
                'delivery_date': 'Day after tomorrow',
                'broker_email': 'broker3@example.com',
                'pickup_urgency': 'asap',
                'equipment_match': True,
                'lane_popularity': 'high'
            }
        ]
        
        st.session_state.loads_data = sample_loads
        st.session_state.alert_count = len([l for l in sample_loads if l['rate_per_mile'] >= 3.0])

# 🚀 MAIN APPLICATION ENTRY POINT
if __name__ == "__main__":
    dashboard = RealTimeDashboard()
    dashboard.run_dispatcher_dashboard()
