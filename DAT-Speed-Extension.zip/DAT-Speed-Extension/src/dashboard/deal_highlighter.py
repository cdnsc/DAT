"""
🎨 Real-Time Deal Highlighter System
Visual highlighting and icons for profitable load opportunities
"""

import json
import time
from datetime import datetime
from typing import Dict, List, Tuple, Optional
import logging

class RealTimeDealHighlighter:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
        # Visual highlighting rules
        self.highlight_rules = {
            'excellent': {
                'score_min': 90,
                'color': '#FF0000',  # Red
                'background': '#FFE5E5',
                'icon': '🔥',
                'label': 'EXCELLENT DEAL',
                'animation': 'flash',
                'priority': 1,
                'sound_alert': True
            },
            'high_profit': {
                'score_min': 75,
                'color': '#00AA00',  # Green
                'background': '#E5FFE5',
                'icon': '💰',
                'label': 'HIGH PROFIT',
                'animation': 'glow',
                'priority': 2,
                'sound_alert': True
            },
            'good_opportunity': {
                'score_min': 60,
                'color': '#FFB000',  # Orange/Yellow
                'background': '#FFF5E5',
                'icon': '⭐',
                'label': 'GOOD DEAL',
                'animation': 'highlight',
                'priority': 3,
                'sound_alert': False
            },
            'standard': {
                'score_min': 40,
                'color': '#0066CC',  # Blue
                'background': '#E5F2FF',
                'icon': '📋',
                'label': 'STANDARD',
                'animation': 'none',
                'priority': 4,
                'sound_alert': False
            },
            'low_value': {
                'score_min': 0,
                'color': '#666666',  # Gray
                'background': '#F5F5F5',
                'icon': '➖',
                'label': 'LOW VALUE',
                'animation': 'none',
                'priority': 5,
                'sound_alert': False
            }
        }
        
        # Distance-based highlighting
        self.distance_rules = {
            'local': {'max_miles': 50, 'icon': '🏠', 'bonus': 10},
            'regional': {'max_miles': 250, 'icon': '🌍', 'bonus': 5},
            'long_haul': {'max_miles': 1000, 'icon': '🛣️', 'bonus': 0},
            'cross_country': {'max_miles': 3000, 'icon': '🌎', 'bonus': -5}
        }
        
        # Real-time alert counters
        self.alert_counts = {
            'excellent': 0,
            'high_profit': 0,
            'good_opportunity': 0,
            'total_alerts': 0
        }
    
    def calculate_deal_score(self, load_data: Dict, driver_location: Dict = None) -> float:
        """
        🚀 INSTANT: Calculate comprehensive deal score (0-100)
        
        Factors:
        - Rate per mile
        - Total profit potential
        - Distance from driver
        - Pickup/delivery timing
        - Equipment match
        - Market conditions
        """
        try:
            score = 0.0
            
            # Base rate scoring (40% of total score)
            rate_per_mile = float(load_data.get('rate_per_mile', 0))
            if rate_per_mile >= 3.00:
                score += 40
            elif rate_per_mile >= 2.50:
                score += 30
            elif rate_per_mile >= 2.00:
                score += 20
            elif rate_per_mile >= 1.50:
                score += 10
            else:
                score += 0
            
            # Distance scoring (20% of total score)
            miles = int(load_data.get('miles', 0))
            deadhead = int(load_data.get('deadhead_miles', 0))
            
            # Prefer moderate distances with low deadhead
            if miles > 0:
                deadhead_ratio = deadhead / miles
                if deadhead_ratio <= 0.1:  # 10% or less deadhead
                    score += 20
                elif deadhead_ratio <= 0.2:  # 20% or less deadhead
                    score += 15
                elif deadhead_ratio <= 0.3:  # 30% or less deadhead
                    score += 10
                else:
                    score += 5
            
            # Proximity to driver (15% of total score)
            if driver_location:
                proximity_score = self._calculate_proximity_score(load_data, driver_location)
                score += proximity_score * 0.15
            
            # Timing scoring (10% of total score)
            pickup_urgency = load_data.get('pickup_urgency', 'standard')
            if pickup_urgency == 'asap':
                score += 10  # ASAP loads often pay more
            elif pickup_urgency == 'today':
                score += 8
            elif pickup_urgency == 'tomorrow':
                score += 5
            
            # Equipment match (10% of total score)
            if load_data.get('equipment_match', False):
                score += 10
            
            # Market conditions (5% of total score)
            # This could be enhanced with real market data
            lane_popularity = load_data.get('lane_popularity', 'medium')
            if lane_popularity == 'high':
                score += 5
            elif lane_popularity == 'medium':
                score += 3
            
            # Ensure score is between 0-100
            score = max(0, min(100, score))
            
            return round(score, 1)
            
        except Exception as e:
            self.logger.error(f"❌ Score calculation failed: {str(e)}")
            return 0.0
    
    def _calculate_proximity_score(self, load_data: Dict, driver_location: Dict) -> float:
        """Calculate score based on proximity to driver (0-100)"""
        try:
            # This is a simplified version - you'd use actual geolocation
            load_origin = load_data.get('origin', '').lower()
            driver_city = driver_location.get('city', '').lower()
            driver_state = driver_location.get('state', '').lower()
            
            # Simple string matching for demo
            if driver_city in load_origin:
                return 100  # Same city
            elif driver_state in load_origin.lower():
                return 75   # Same state
            else:
                return 25   # Different region
                
        except Exception:
            return 50  # Default moderate score
    
    def get_deal_highlight(self, deal_score: float, load_data: Dict = None) -> Dict:
        """
        🚀 INSTANT: Get highlighting information for a deal
        
        Returns:
            Dictionary with colors, icons, animations, and labels
        """
        try:
            # Find appropriate highlight rule
            highlight_rule = None
            for rule_name, rule in self.highlight_rules.items():
                if deal_score >= rule['score_min']:
                    highlight_rule = rule.copy()
                    highlight_rule['rule_name'] = rule_name
                    break
            
            if not highlight_rule:
                highlight_rule = self.highlight_rules['low_value'].copy()
                highlight_rule['rule_name'] = 'low_value'
            
            # Add distance-based enhancements
            if load_data:
                miles = int(load_data.get('miles', 0))
                for distance_type, distance_rule in self.distance_rules.items():
                    if miles <= distance_rule['max_miles']:
                        highlight_rule['distance_icon'] = distance_rule['icon']
                        highlight_rule['distance_type'] = distance_type
                        break
            
            # Add timestamp for real-time tracking
            highlight_rule['timestamp'] = datetime.now().isoformat()
            highlight_rule['score'] = deal_score
            
            # Increment alert counters
            rule_name = highlight_rule['rule_name']
            if rule_name in self.alert_counts:
                self.alert_counts[rule_name] += 1
                self.alert_counts['total_alerts'] += 1
            
            return highlight_rule
            
        except Exception as e:
            self.logger.error(f"❌ Highlight generation failed: {str(e)}")
            return self.highlight_rules['standard'].copy()
    
    def generate_visual_indicators(self, load_data: Dict, driver_location: Dict = None) -> Dict:
        """
        🚀 INSTANT: Generate complete visual package for a load
        
        Returns:
            Complete styling and interaction data for UI display
        """
        try:
            # Calculate deal score
            deal_score = self.calculate_deal_score(load_data, driver_location)
            
            # Get highlight rules
            highlight = self.get_deal_highlight(deal_score, load_data)
            
            # Create complete visual package
            visual_package = {
                'score': deal_score,
                'highlight': highlight,
                'css_styles': self._generate_css_styles(highlight),
                'html_elements': self._generate_html_elements(highlight, load_data),
                'javascript_actions': self._generate_js_actions(highlight),
                'email_buttons': self._generate_email_buttons(load_data),
                'quick_actions': self._generate_quick_actions(load_data)
            }
            
            return visual_package
            
        except Exception as e:
            self.logger.error(f"❌ Visual indicator generation failed: {str(e)}")
            return {}
    
    def _generate_css_styles(self, highlight: Dict) -> Dict:
        """Generate CSS styling for the load row"""
        return {
            'background_color': highlight['background'],
            'border_color': highlight['color'],
            'border_width': '2px',
            'border_style': 'solid',
            'color': highlight['color'],
            'font_weight': 'bold' if highlight['score'] >= 75 else 'normal',
            'animation': highlight.get('animation', 'none'),
            'box_shadow': f"0 0 10px {highlight['color']}" if highlight['score'] >= 90 else 'none'
        }
    
    def _generate_html_elements(self, highlight: Dict, load_data: Dict) -> Dict:
        """Generate HTML elements for the load display"""
        score_badge = f"""
        <span class="score-badge" style="
            background-color: {highlight['color']};
            color: white;
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: bold;
        ">
            {highlight['icon']} {highlight['score']}/100
        </span>
        """
        
        priority_label = f"""
        <div class="priority-label" style="
            background-color: {highlight['background']};
            color: {highlight['color']};
            padding: 2px 6px;
            border-radius: 4px;
            font-size: 10px;
            font-weight: bold;
            margin-left: 5px;
        ">
            {highlight['label']}
        </div>
        """
        
        return {
            'score_badge': score_badge,
            'priority_label': priority_label,
            'main_icon': highlight['icon'],
            'distance_icon': highlight.get('distance_icon', '📍')
        }
    
    def _generate_js_actions(self, highlight: Dict) -> Dict:
        """Generate JavaScript actions for interactivity"""
        actions = {
            'on_click': f"highlightLoad('{highlight['rule_name']}')",
            'on_hover': f"showLoadDetails('{highlight['score']}')",
            'auto_alert': highlight.get('sound_alert', False)
        }
        
        if highlight['score'] >= 90:
            actions['flash_animation'] = True
            actions['urgent_notification'] = True
        
        return actions
    
    def _generate_email_buttons(self, load_data: Dict) -> List[Dict]:
        """Generate email action buttons"""
        buttons = [
            {
                'label': '📧 Quick Inquiry',
                'type': 'initial_inquiry',
                'style': 'primary',
                'icon': '📧'
            },
            {
                'label': '💰 Negotiate',
                'type': 'rate_negotiation',
                'style': 'success',
                'icon': '💰'
            },
            {
                'label': '⏰ Follow Up',
                'type': 'follow_up',
                'style': 'warning',
                'icon': '⏰'
            }
        ]
        
        return buttons
    
    def _generate_quick_actions(self, load_data: Dict) -> List[Dict]:
        """Generate quick action buttons"""
        actions = [
            {
                'label': '👁️ View Details',
                'action': 'view_details',
                'icon': '👁️'
            },
            {
                'label': '📍 Show Route',
                'action': 'show_route',
                'icon': '📍'
            },
            {
                'label': '💾 Save Load',
                'action': 'save_load',
                'icon': '💾'
            },
            {
                'label': '📱 Share',
                'action': 'share_load',
                'icon': '📱'
            }
        ]
        
        return actions
    
    def get_real_time_stats(self) -> Dict:
        """🚀 INSTANT: Get real-time highlighting statistics"""
        return {
            'alert_counts': self.alert_counts.copy(),
            'total_processed': sum(self.alert_counts.values()),
            'excellent_percentage': round(
                (self.alert_counts['excellent'] / max(1, self.alert_counts['total_alerts'])) * 100, 1
            ),
            'last_update': datetime.now().isoformat()
        }

# 🚀 QUICK USAGE EXAMPLE
if __name__ == "__main__":
    # Initialize highlighter
    highlighter = RealTimeDealHighlighter()
    
    # Sample load data
    sample_loads = [
        {
            'load_id': 'DAT001',
            'origin': 'Chicago, IL',
            'destination': 'Atlanta, GA',
            'rate_per_mile': 3.25,
            'miles': 465,
            'deadhead_miles': 20,
            'pickup_urgency': 'asap',
            'equipment_match': True,
            'lane_popularity': 'high'
        },
        {
            'load_id': 'DAT002',
            'origin': 'Los Angeles, CA',
            'destination': 'Phoenix, AZ',
            'rate_per_mile': 2.10,
            'miles': 370,
            'deadhead_miles': 85,
            'pickup_urgency': 'tomorrow',
            'equipment_match': False,
            'lane_popularity': 'medium'
        }
    ]
    
    driver_location = {'city': 'Chicago', 'state': 'IL'}
    
    print("🎨 Real-Time Deal Highlighter Demo")
    print("=" * 50)
    
    for load in sample_loads:
        print(f"\n📋 Processing Load: {load['load_id']}")
        
        # Generate visual package
        visual = highlighter.generate_visual_indicators(load, driver_location)
        
        print(f"💯 Score: {visual['score']}/100")
        print(f"🎨 Highlight: {visual['highlight']['label']}")
        print(f"🔥 Icon: {visual['highlight']['icon']}")
        print(f"🎯 Priority: {visual['highlight']['priority']}")
        print(f"📧 Email Buttons: {len(visual['email_buttons'])}")
        
        if visual['score'] >= 90:
            print("🚨 URGENT: Excellent deal detected!")
    
    # Show real-time stats
    stats = highlighter.get_real_time_stats()
    print(f"\n📊 Real-Time Stats:")
    print(f"🔥 Excellent deals: {stats['alert_counts']['excellent']}")
    print(f"💰 High profit deals: {stats['alert_counts']['high_profit']}")
    print(f"⭐ Good opportunities: {stats['alert_counts']['good_opportunity']}")
    print(f"📈 Total processed: {stats['total_processed']}")
