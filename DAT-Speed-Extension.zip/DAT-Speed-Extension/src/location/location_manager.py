"""
🚛 Enterprise Multi-Driver Location Manager
Real-time tracking for 4-5 drivers with bulletproof error handling
"""

import json
import sqlite3
import threading
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, asdict
from loguru import logger
import uuid
from geopy.geocoders import Nominatim
from geopy.distance import geodesic
from haversine import haversine, Unit
import os

@dataclass
class Driver:
    """Enterprise Driver Data Model"""
    driver_id: str
    name: str
    phone: str
    email: str
    equipment_type: str
    truck_number: str
    trailer_number: str
    is_active: bool = True
    created_at: str = None
    last_updated: str = None
    
    def __post_init__(self):
        if not self.created_at:
            self.created_at = datetime.now().isoformat()
        self.last_updated = datetime.now().isoformat()

@dataclass
class DriverLocation:
    """Enterprise Location Data Model"""
    location_id: str
    driver_id: str
    city: str
    state: str
    latitude: float = None
    longitude: float = None
    address: str = None
    timestamp: str = None
    accuracy_meters: float = None
    is_current: bool = True
    notes: str = None
    
    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = datetime.now().isoformat()

class EnterpriseLocationManager:
    """
    🚛 Enterprise-Grade Multi-Driver Location Management System
    
    Features:
    - Support for 4-5 drivers simultaneously
    - Real-time location tracking with error recovery
    - Geographic intelligence and route optimization
    - Enterprise security and data integrity
    - Bulletproof error handling and logging
    """
    
    def __init__(self, db_path: str = "data/enterprise_locations.db"):
        self.db_path = db_path
        self.drivers: Dict[str, Driver] = {}
        self.current_locations: Dict[str, DriverLocation] = {}
        self.location_callbacks = []
        self.is_tracking = False
        self.tracking_thread = None
        
        # Initialize geocoder with enterprise settings
        self.geolocator = Nominatim(
            user_agent="enterprise-dat-analyzer",
            timeout=10,
            scheme='https'
        )
        
        # Ensure data directory exists
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        
        # Initialize enterprise database
        self._init_enterprise_database()
        
        # Load existing drivers and locations
        self._load_existing_data()
        
        # Configure enterprise logging
        logger.add(
            "data/logs/location_manager.log",
            rotation="1 day",
            retention="30 days",
            level="INFO",
            format="{time:YYYY-MM-DD HH:mm:ss} | {level} | {module}:{function}:{line} | {message}"
        )
        
        logger.info("🚛 Enterprise Location Manager initialized")
    
    def _init_enterprise_database(self):
        """Initialize enterprise-grade database with full schema"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Drivers table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS drivers (
                    driver_id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    phone TEXT NOT NULL,
                    email TEXT,
                    equipment_type TEXT NOT NULL,
                    truck_number TEXT,
                    trailer_number TEXT,
                    is_active BOOLEAN DEFAULT 1,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    last_updated DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Driver locations table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS driver_locations (
                    location_id TEXT PRIMARY KEY,
                    driver_id TEXT NOT NULL,
                    city TEXT NOT NULL,
                    state TEXT NOT NULL,
                    latitude REAL,
                    longitude REAL,
                    address TEXT,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                    accuracy_meters REAL,
                    is_current BOOLEAN DEFAULT 0,
                    notes TEXT,
                    FOREIGN KEY (driver_id) REFERENCES drivers (driver_id)
                )
            ''')
            
            # Location history table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS location_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    driver_id TEXT NOT NULL,
                    from_city TEXT,
                    from_state TEXT,
                    to_city TEXT NOT NULL,
                    to_state TEXT NOT NULL,
                    distance_miles REAL,
                    travel_time_hours REAL,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (driver_id) REFERENCES drivers (driver_id)
                )
            ''')
            
            # Performance tracking table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS location_updates (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    driver_id TEXT,
                    update_type TEXT NOT NULL,
                    processing_time_ms REAL,
                    success BOOLEAN DEFAULT 1,
                    error_message TEXT,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Create indexes for performance
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_driver_locations_current ON driver_locations(driver_id, is_current)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_location_history_driver ON location_history(driver_id, timestamp)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_location_updates_timestamp ON location_updates(timestamp)')
            
            conn.commit()
            conn.close()
            
            logger.info("✅ Enterprise database initialized successfully")
            
        except Exception as e:
            logger.error(f"❌ Database initialization failed: {str(e)}")
            raise
    
    def add_driver(self, name: str, phone: str, equipment_type: str, 
                   email: str = "", truck_number: str = "", trailer_number: str = "") -> str:
        """
        🚛 Add a new driver to the fleet
        
        Returns:
            driver_id: Unique identifier for the driver
        """
        try:
            driver_id = str(uuid.uuid4())[:8]  # Short unique ID
            
            driver = Driver(
                driver_id=driver_id,
                name=name,
                phone=phone,
                email=email,
                equipment_type=equipment_type,
                truck_number=truck_number,
                trailer_number=trailer_number
            )
            
            # Save to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO drivers (driver_id, name, phone, email, equipment_type, 
                                   truck_number, trailer_number, is_active, created_at, last_updated)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                driver.driver_id, driver.name, driver.phone, driver.email,
                driver.equipment_type, driver.truck_number, driver.trailer_number,
                driver.is_active, driver.created_at, driver.last_updated
            ))
            
            conn.commit()
            conn.close()
            
            # Add to memory
            self.drivers[driver_id] = driver
            
            logger.info(f"✅ Driver added: {name} ({driver_id})")
            
            return driver_id
            
        except Exception as e:
            logger.error(f"❌ Failed to add driver {name}: {str(e)}")
            raise
    
    def update_driver_location(self, driver_id: str, city: str, state: str, 
                              notes: str = "") -> Dict:
        """
        🚀 ENTERPRISE: Update driver location with full error handling
        
        Args:
            driver_id: Unique driver identifier
            city: Current city
            state: Current state (2-letter code)
            notes: Optional notes about the location
            
        Returns:
            Location data with processing status
        """
        start_time = time.time()
        
        try:
            # Validate driver exists
            if driver_id not in self.drivers:
                raise ValueError(f"Driver {driver_id} not found")
            
            # Validate and clean input
            city = city.strip().title()
            state = state.strip().upper()
            
            if len(state) != 2:
                raise ValueError("State must be 2-letter code (e.g., 'IL', 'TX')")
            
            # Create location object
            location_id = str(uuid.uuid4())[:8]
            location = DriverLocation(
                location_id=location_id,
                driver_id=driver_id,
                city=city,
                state=state,
                notes=notes
            )
            
            # Immediate response for real-time UI
            response_data = {
                'driver_id': driver_id,
                'driver_name': self.drivers[driver_id].name,
                'city': city,
                'state': state,
                'timestamp': location.timestamp,
                'status': 'updating',
                'location_id': location_id
            }
            
            # Start background geocoding
            threading.Thread(
                target=self._geocode_and_save_location,
                args=(location, response_data),
                daemon=True
            ).start()
            
            # Update current location immediately
            self.current_locations[driver_id] = location
            
            # Notify callbacks
            self._notify_location_callbacks(driver_id, response_data)
            
            # Log performance
            processing_time = (time.time() - start_time) * 1000
            self._log_performance('location_update', driver_id, processing_time, True)
            
            logger.info(f"🚀 Location updated for {self.drivers[driver_id].name}: {city}, {state}")
            
            return response_data
            
        except Exception as e:
            processing_time = (time.time() - start_time) * 1000
            self._log_performance('location_update', driver_id, processing_time, False, str(e))
            
            logger.error(f"❌ Location update failed for {driver_id}: {str(e)}")
            
            return {
                'driver_id': driver_id,
                'error': str(e),
                'status': 'failed',
                'timestamp': datetime.now().isoformat()
            }
    
    def _geocode_and_save_location(self, location: DriverLocation, response_data: Dict):
        """Background geocoding with enterprise error handling"""
        try:
            # Geocode the location
            full_address = f"{location.city}, {location.state}"
            geo_result = self.geolocator.geocode(full_address)
            
            if geo_result:
                location.latitude = geo_result.latitude
                location.longitude = geo_result.longitude
                location.address = geo_result.address
                response_data.update({
                    'latitude': location.latitude,
                    'longitude': location.longitude,
                    'address': location.address,
                    'status': 'active'
                })
            else:
                response_data['status'] = 'geocoding_failed'
                logger.warning(f"⚠️ Geocoding failed for: {full_address}")
            
            # Save to database
            self._save_location_to_database(location)
            
            # Update memory
            self.current_locations[location.driver_id] = location
            
            # Notify callbacks with complete data
            self._notify_location_callbacks(location.driver_id, response_data)
            
        except Exception as e:
            response_data['status'] = 'geocoding_error'
            response_data['error'] = str(e)
            logger.error(f"❌ Geocoding error: {str(e)}")
    
    def _save_location_to_database(self, location: DriverLocation):
        """Save location to database with transaction safety"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Begin transaction
            cursor.execute('BEGIN TRANSACTION')
            
            # Mark all previous locations as not current
            cursor.execute(
                'UPDATE driver_locations SET is_current = 0 WHERE driver_id = ?',
                (location.driver_id,)
            )
            
            # Insert new current location
            cursor.execute('''
                INSERT INTO driver_locations 
                (location_id, driver_id, city, state, latitude, longitude, 
                 address, timestamp, is_current, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?)
            ''', (
                location.location_id, location.driver_id, location.city, location.state,
                location.latitude, location.longitude, location.address, 
                location.timestamp, location.notes
            ))
            
            # Commit transaction
            cursor.execute('COMMIT')
            conn.close()
            
        except Exception as e:
            logger.error(f"❌ Database save failed: {str(e)}")
            try:
                cursor.execute('ROLLBACK')
                conn.close()
            except:
                pass
            raise
    
    def get_all_drivers(self) -> List[Dict]:
        """🚛 Get all drivers with their current locations"""
        try:
            drivers_data = []
            
            for driver_id, driver in self.drivers.items():
                driver_data = asdict(driver)
                
                # Add current location if available
                if driver_id in self.current_locations:
                    location = self.current_locations[driver_id]
                    driver_data['current_location'] = asdict(location)
                else:
                    driver_data['current_location'] = None
                
                drivers_data.append(driver_data)
            
            return drivers_data
            
        except Exception as e:
            logger.error(f"❌ Failed to get drivers: {str(e)}")
            return []
    
    def get_driver_location(self, driver_id: str) -> Optional[Dict]:
        """🚀 Get current location for specific driver"""
        try:
            if driver_id in self.current_locations:
                location = self.current_locations[driver_id]
                return asdict(location)
            return None
            
        except Exception as e:
            logger.error(f"❌ Failed to get location for {driver_id}: {str(e)}")
            return None
    
    def find_nearby_loads_for_driver(self, driver_id: str, radius_miles: int = 150) -> List[Dict]:
        """🎯 Find potential load pickup locations near driver"""
        try:
            location = self.current_locations.get(driver_id)
            if not location or not location.latitude:
                return []
            
            # Major freight hubs and cities
            freight_hubs = [
                {'city': 'Chicago', 'state': 'IL', 'lat': 41.8781, 'lon': -87.6298, 'type': 'major_hub'},
                {'city': 'Atlanta', 'state': 'GA', 'lat': 33.7490, 'lon': -84.3880, 'type': 'major_hub'},
                {'city': 'Dallas', 'state': 'TX', 'lat': 32.7767, 'lon': -96.7970, 'type': 'major_hub'},
                {'city': 'Los Angeles', 'state': 'CA', 'lat': 34.0522, 'lon': -118.2437, 'type': 'major_hub'},
                {'city': 'Memphis', 'state': 'TN', 'lat': 35.1495, 'lon': -90.0490, 'type': 'freight_hub'},
                {'city': 'Louisville', 'state': 'KY', 'lat': 38.2527, 'lon': -85.7585, 'type': 'freight_hub'},
                {'city': 'Phoenix', 'state': 'AZ', 'lat': 33.4484, 'lon': -112.0740, 'type': 'regional_hub'},
                {'city': 'Denver', 'state': 'CO', 'lat': 39.7392, 'lon': -104.9903, 'type': 'regional_hub'},
            ]
            
            driver_pos = (location.latitude, location.longitude)
            nearby_areas = []
            
            for hub in freight_hubs:
                hub_pos = (hub['lat'], hub['lon'])
                distance = haversine(driver_pos, hub_pos, unit=Unit.MILES)
                
                if distance <= radius_miles:
                    nearby_areas.append({
                        'city': hub['city'],
                        'state': hub['state'],
                        'distance_miles': round(distance, 1),
                        'hub_type': hub['type'],
                        'coordinates': hub_pos,
                        'driver_id': driver_id,
                        'driver_name': self.drivers[driver_id].name
                    })
            
            # Sort by distance
            nearby_areas.sort(key=lambda x: x['distance_miles'])
            
            return nearby_areas
            
        except Exception as e:
            logger.error(f"❌ Failed to find nearby loads for {driver_id}: {str(e)}")
            return []
    
    def get_fleet_overview(self) -> Dict:
        """📊 Get complete fleet overview with statistics"""
        try:
            overview = {
                'total_drivers': len(self.drivers),
                'active_drivers': len([d for d in self.drivers.values() if d.is_active]),
                'drivers_with_locations': len(self.current_locations),
                'drivers': [],
                'fleet_center': None,
                'last_updated': datetime.now().isoformat()
            }
            
            # Add driver details
            for driver_id, driver in self.drivers.items():
                driver_info = {
                    'driver_id': driver_id,
                    'name': driver.name,
                    'equipment_type': driver.equipment_type,
                    'is_active': driver.is_active,
                    'current_location': None
                }
                
                if driver_id in self.current_locations:
                    location = self.current_locations[driver_id]
                    driver_info['current_location'] = {
                        'city': location.city,
                        'state': location.state,
                        'timestamp': location.timestamp,
                        'latitude': location.latitude,
                        'longitude': location.longitude
                    }
                
                overview['drivers'].append(driver_info)
            
            # Calculate fleet center (average position)
            valid_locations = [
                loc for loc in self.current_locations.values() 
                if loc.latitude and loc.longitude
            ]
            
            if valid_locations:
                avg_lat = sum(loc.latitude for loc in valid_locations) / len(valid_locations)
                avg_lon = sum(loc.longitude for loc in valid_locations) / len(valid_locations)
                overview['fleet_center'] = {'latitude': avg_lat, 'longitude': avg_lon}
            
            return overview
            
        except Exception as e:
            logger.error(f"❌ Failed to get fleet overview: {str(e)}")
            return {'error': str(e)}
    
    def register_location_callback(self, callback_func):
        """Register callback for location updates"""
        self.location_callbacks.append(callback_func)
    
    def _notify_location_callbacks(self, driver_id: str, location_data: Dict):
        """Notify all registered callbacks"""
        for callback in self.location_callbacks:
            try:
                callback(driver_id, location_data)
            except Exception as e:
                logger.error(f"❌ Callback error: {str(e)}")
    
    def _log_performance(self, operation: str, driver_id: str, processing_time_ms: float, 
                        success: bool, error_message: str = None):
        """Log performance metrics"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO location_updates 
                (driver_id, update_type, processing_time_ms, success, error_message, timestamp)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (
                driver_id, operation, processing_time_ms, success, 
                error_message, datetime.now().isoformat()
            ))
            
            conn.commit()
            conn.close()
            
        except Exception as e:
            logger.error(f"❌ Performance logging failed: {str(e)}")
    
    def _load_existing_data(self):
        """Load existing drivers and locations from database"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Load drivers
            cursor.execute('SELECT * FROM drivers WHERE is_active = 1')
            for row in cursor.fetchall():
                driver = Driver(
                    driver_id=row[0], name=row[1], phone=row[2], email=row[3],
                    equipment_type=row[4], truck_number=row[5], trailer_number=row[6],
                    is_active=bool(row[7]), created_at=row[8], last_updated=row[9]
                )
                self.drivers[driver.driver_id] = driver
            
            # Load current locations
            cursor.execute('''
                SELECT * FROM driver_locations 
                WHERE is_current = 1
            ''')
            for row in cursor.fetchall():
                location = DriverLocation(
                    location_id=row[0], driver_id=row[1], city=row[2], state=row[3],
                    latitude=row[4], longitude=row[5], address=row[6], timestamp=row[7],
                    accuracy_meters=row[8], is_current=bool(row[9]), notes=row[10]
                )
                self.current_locations[location.driver_id] = location
            
            conn.close()
            
            logger.info(f"✅ Loaded {len(self.drivers)} drivers and {len(self.current_locations)} locations")
            
        except Exception as e:
            logger.error(f"❌ Failed to load existing data: {str(e)}")

# 🚀 ENTERPRISE USAGE EXAMPLE
if __name__ == "__main__":
    # Initialize enterprise location manager
    location_mgr = EnterpriseLocationManager()
    
    # Add sample drivers
    if not location_mgr.drivers:
        print("🚛 Adding sample drivers...")
        
        driver1_id = location_mgr.add_driver(
            name="John Smith", 
            phone="(555) 123-4567", 
            equipment_type="Dry Van",
            email="john@company.com",
            truck_number="T001",
            trailer_number="TR001"
        )
        
        driver2_id = location_mgr.add_driver(
            name="Maria Rodriguez", 
            phone="(555) 987-6543", 
            equipment_type="Reefer",
            email="maria@company.com",
            truck_number="T002",
            trailer_number="TR002"
        )
        
        # Update locations
        location_mgr.update_driver_location(driver1_id, "Chicago", "IL")
        location_mgr.update_driver_location(driver2_id, "Atlanta", "GA")
        
        time.sleep(2)  # Allow geocoding to complete
    
    # Show fleet overview
    overview = location_mgr.get_fleet_overview()
    print(f"\n📊 Fleet Overview:")
    print(f"   Total Drivers: {overview['total_drivers']}")
    print(f"   Active Drivers: {overview['active_drivers']}")
    print(f"   With Locations: {overview['drivers_with_locations']}")
    
    for driver in overview['drivers']:
        print(f"\n🚛 {driver['name']} ({driver['driver_id']})")
        if driver['current_location']:
            loc = driver['current_location']
            print(f"   📍 {loc['city']}, {loc['state']}")
            print(f"   🕐 {loc['timestamp']}")
        else:
            print("   📍 No location set")
    
    def _init_database(self):
        """Initialize SQLite database for location tracking"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS driver_locations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                city TEXT NOT NULL,
                state TEXT NOT NULL,
                latitude REAL,
                longitude REAL,
                address TEXT,
                is_current BOOLEAN DEFAULT 0
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS location_updates (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                update_type TEXT,
                details TEXT
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def update_driver_location(self, city: str, state: str) -> Dict:
        """
        🚀 REAL-TIME: Update driver's current location
        Returns immediately with location data and starts background geocoding
        """
        try:
            # Immediate response for real-time UI
            location_data = {
                'city': city.title(),
                'state': state.upper(),
                'timestamp': datetime.now().isoformat(),
                'status': 'updating'
            }
            
            # Start background geocoding thread
            threading.Thread(
                target=self._geocode_and_save,
                args=(city, state, location_data),
                daemon=True
            ).start()
            
            # Update current location immediately
            self.current_location = location_data
            
            # Notify all registered callbacks INSTANTLY
            self._notify_location_update(location_data)
            
            self.logger.info(f"🚀 REAL-TIME: Driver location updated to {city}, {state}")
            
            return location_data
            
        except Exception as e:
            self.logger.error(f"❌ Location update failed: {str(e)}")
            return {'error': str(e), 'status': 'failed'}
    
    def _geocode_and_save(self, city: str, state: str, location_data: Dict):
        """Background geocoding and database save"""
        try:
            # Geocode the location
            location = self.geolocator.geocode(f"{city}, {state}")
            
            if location:
                location_data.update({
                    'latitude': location.latitude,
                    'longitude': location.longitude,
                    'address': location.address,
                    'status': 'active'
                })
            else:
                location_data['status'] = 'geocoding_failed'
            
            # Save to database
            self._save_location_to_db(location_data)
            
            # Update current location with full data
            self.current_location = location_data
            
            # Notify callbacks with complete data
            self._notify_location_update(location_data)
            
        except Exception as e:
            self.logger.error(f"Geocoding failed: {str(e)}")
            location_data['status'] = 'geocoding_error'
    
    def _save_location_to_db(self, location_data: Dict):
        """Save location to database and mark as current"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Mark all previous locations as not current
        cursor.execute("UPDATE driver_locations SET is_current = 0")
        
        # Insert new current location
        cursor.execute('''
            INSERT INTO driver_locations 
            (city, state, latitude, longitude, address, is_current)
            VALUES (?, ?, ?, ?, ?, 1)
        ''', (
            location_data['city'],
            location_data['state'],
            location_data.get('latitude'),
            location_data.get('longitude'),
            location_data.get('address')
        ))
        
        conn.commit()
        conn.close()
    
    def get_current_location(self) -> Optional[Dict]:
        """🚀 INSTANT: Get driver's current location"""
        return self.current_location
    
    def find_nearby_cities(self, radius_miles: int = 100) -> List[Dict]:
        """
        🚀 REAL-TIME: Find cities within radius of driver's location
        """
        if not self.current_location or not self.current_location.get('latitude'):
            return []
        
        # Major cities database (simplified for demo)
        major_cities = [
            {'city': 'Chicago', 'state': 'IL', 'lat': 41.8781, 'lon': -87.6298},
            {'city': 'Atlanta', 'state': 'GA', 'lat': 33.7490, 'lon': -84.3880},
            {'city': 'Dallas', 'state': 'TX', 'lat': 32.7767, 'lon': -96.7970},
            {'city': 'Los Angeles', 'state': 'CA', 'lat': 34.0522, 'lon': -118.2437},
            {'city': 'New York', 'state': 'NY', 'lat': 40.7128, 'lon': -74.0060},
            {'city': 'Phoenix', 'state': 'AZ', 'lat': 33.4484, 'lon': -112.0740},
            {'city': 'Philadelphia', 'state': 'PA', 'lat': 39.9526, 'lon': -75.1652},
            {'city': 'Houston', 'state': 'TX', 'lat': 29.7604, 'lon': -95.3698},
            {'city': 'Detroit', 'state': 'MI', 'lat': 42.3314, 'lon': -83.0458},
            {'city': 'Denver', 'state': 'CO', 'lat': 39.7392, 'lon': -104.9903}
        ]
        
        driver_pos = (
            self.current_location['latitude'], 
            self.current_location['longitude']
        )
        
        nearby_cities = []
        for city in major_cities:
            city_pos = (city['lat'], city['lon'])
            distance = geodesic(driver_pos, city_pos).miles
            
            if distance <= radius_miles:
                nearby_cities.append({
                    'city': city['city'],
                    'state': city['state'],
                    'distance_miles': round(distance, 1),
                    'coordinates': city_pos
                })
        
        # Sort by distance
        nearby_cities.sort(key=lambda x: x['distance_miles'])
        
        return nearby_cities
    
    def register_update_callback(self, callback_func):
        """Register function to be called on location updates"""
        self.update_callbacks.append(callback_func)
    
    def _notify_location_update(self, location_data: Dict):
        """Notify all registered callbacks of location update"""
        for callback in self.update_callbacks:
            try:
                callback(location_data)
            except Exception as e:
                self.logger.error(f"Callback error: {str(e)}")
    
    def start_real_time_tracking(self):
        """🚀 Start real-time location monitoring"""
        if self.is_tracking:
            return
        
        self.is_tracking = True
        self.tracking_thread = threading.Thread(
            target=self._tracking_loop, 
            daemon=True
        )
        self.tracking_thread.start()
        
        self.logger.info("🚀 Real-time location tracking started")
    
    def stop_real_time_tracking(self):
        """Stop real-time location monitoring"""
        self.is_tracking = False
        if self.tracking_thread:
            self.tracking_thread.join(timeout=5)
        
        self.logger.info("⏹️ Real-time location tracking stopped")
    
    def _tracking_loop(self):
        """Background tracking loop"""
        while self.is_tracking:
            try:
                # Check for location updates every 10 seconds
                time.sleep(10)
                
                # Here you could add automatic GPS updates if needed
                # For now, we rely on manual updates
                
            except Exception as e:
                self.logger.error(f"Tracking loop error: {str(e)}")
                time.sleep(30)  # Wait before retrying

# 🚀 QUICK USAGE EXAMPLE
if __name__ == "__main__":
    # Initialize location manager
    location_mgr = RealTimeLocationManager()
    
    # Register callback for real-time updates
    def on_location_update(location_data):
        print(f"🚀 REAL-TIME UPDATE: Driver now in {location_data['city']}, {location_data['state']}")
        
        # Find nearby cities instantly
        nearby = location_mgr.find_nearby_cities(150)
        print(f"📍 Found {len(nearby)} cities within 150 miles")
        
        for city in nearby[:5]:  # Show top 5
            print(f"   • {city['city']}, {city['state']} ({city['distance_miles']} mi)")
    
    location_mgr.register_update_callback(on_location_update)
    
    # Start real-time tracking
    location_mgr.start_real_time_tracking()
    
    # Update location (simulates driver input)
    print("🚛 Updating driver location...")
    result = location_mgr.update_driver_location("Atlanta", "GA")
    
    # Keep running for demo
    time.sleep(5)
    
    print("\n📊 Current location:", location_mgr.get_current_location())
