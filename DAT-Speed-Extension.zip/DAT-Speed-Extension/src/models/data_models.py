"""
📊 Enterprise Data Models and Types
Core data structures for the DAT Load Analyzer system
Optimized for Fedora Linux enterprise deployment
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, List, Optional, Any, Union
from enum import Enum
import json
import uuid

class LoadStatus(Enum):
    """Load status enumeration"""
    AVAILABLE = "available"
    CONTACTED = "contacted"
    BOOKED = "booked"
    IN_TRANSIT = "in_transit"
    DELIVERED = "delivered"
    CANCELLED = "cancelled"

class DriverStatus(Enum):
    """Driver status enumeration"""
    AVAILABLE = "available"
    ASSIGNED = "assigned"
    IN_TRANSIT = "in_transit"
    LOADING = "loading"
    UNLOADING = "unloading"
    OFFLINE = "offline"

class DealQuality(Enum):
    """Deal quality classification"""
    EXCELLENT = "excellent"  # $3000+ profit
    HIGH_PROFIT = "high_profit"  # $2000-3000 profit
    GOOD_OPPORTUNITY = "good_opportunity"  # $1000-2000 profit
    STANDARD = "standard"  # $500-1000 profit
    LOW_MARGIN = "low_margin"  # <$500 profit

@dataclass
class Location:
    """Geographic location data"""
    city: str
    state: str
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    address: Optional[str] = None
    zip_code: Optional[str] = None
    
    def __str__(self) -> str:
        return f"{self.city}, {self.state}"
    
    def to_dict(self) -> Dict:
        return {
            'city': self.city,
            'state': self.state,
            'latitude': self.latitude,
            'longitude': self.longitude,
            'address': self.address,
            'zip_code': self.zip_code
        }

@dataclass
class Driver:
    """Driver information model"""
    driver_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    phone: str = ""
    email: str = ""
    equipment_type: str = "Dry Van"
    truck_number: str = ""
    trailer_number: str = ""
    current_location: Optional[Location] = None
    status: DriverStatus = DriverStatus.AVAILABLE
    years_experience: int = 5
    is_active: bool = True
    created_at: datetime = field(default_factory=datetime.now)
    last_updated: datetime = field(default_factory=datetime.now)
    
    def to_dict(self) -> Dict:
        return {
            'driver_id': self.driver_id,
            'name': self.name,
            'phone': self.phone,
            'email': self.email,
            'equipment_type': self.equipment_type,
            'truck_number': self.truck_number,
            'trailer_number': self.trailer_number,
            'current_location': self.current_location.to_dict() if self.current_location else None,
            'status': self.status.value,
            'years_experience': self.years_experience,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat(),
            'last_updated': self.last_updated.isoformat()
        }

@dataclass
class LoadData:
    """DAT load information model"""
    load_id: str = ""
    origin: Location = field(default_factory=lambda: Location("", ""))
    destination: Location = field(default_factory=lambda: Location("", ""))
    miles: int = 0
    rate_per_mile: float = 0.0
    total_rate: float = 0.0
    equipment_type: str = "Dry Van"
    weight: str = ""
    commodity: str = ""
    pickup_date: str = ""
    delivery_date: str = ""
    broker_name: str = ""
    broker_email: str = ""
    broker_phone: str = ""
    posted_time: datetime = field(default_factory=datetime.now)
    status: LoadStatus = LoadStatus.AVAILABLE
    deal_quality: DealQuality = DealQuality.STANDARD
    profit_estimate: float = 0.0
    fuel_cost_estimate: float = 0.0
    notes: str = ""
    scraped_at: datetime = field(default_factory=datetime.now)
    
    def calculate_profit(self, driver: Driver) -> float:
        """Calculate estimated profit for this load"""
        # Base costs
        fuel_cost = self.miles * 0.60  # $0.60 per mile (current average)
        driver_pay = self.total_rate * 0.60  # 60% to driver
        insurance = self.total_rate * 0.05  # 5% insurance
        maintenance = self.miles * 0.15  # $0.15 per mile maintenance
        
        total_costs = fuel_cost + driver_pay + insurance + maintenance
        profit = self.total_rate - total_costs
        
        self.profit_estimate = profit
        self.fuel_cost_estimate = fuel_cost
        
        # Update deal quality
        if profit >= 3000:
            self.deal_quality = DealQuality.EXCELLENT
        elif profit >= 2000:
            self.deal_quality = DealQuality.HIGH_PROFIT
        elif profit >= 1000:
            self.deal_quality = DealQuality.GOOD_OPPORTUNITY
        elif profit >= 500:
            self.deal_quality = DealQuality.STANDARD
        else:
            self.deal_quality = DealQuality.LOW_MARGIN
        
        return profit
    
    def to_dict(self) -> Dict:
        return {
            'load_id': self.load_id,
            'origin': self.origin.to_dict(),
            'destination': self.destination.to_dict(),
            'miles': self.miles,
            'rate_per_mile': self.rate_per_mile,
            'total_rate': self.total_rate,
            'equipment_type': self.equipment_type,
            'weight': self.weight,
            'commodity': self.commodity,
            'pickup_date': self.pickup_date,
            'delivery_date': self.delivery_date,
            'broker_name': self.broker_name,
            'broker_email': self.broker_email,
            'broker_phone': self.broker_phone,
            'posted_time': self.posted_time.isoformat(),
            'status': self.status.value,
            'deal_quality': self.deal_quality.value,
            'profit_estimate': self.profit_estimate,
            'fuel_cost_estimate': self.fuel_cost_estimate,
            'notes': self.notes,
            'scraped_at': self.scraped_at.isoformat()
        }

@dataclass
class EmailTemplate:
    """Email template model"""
    template_id: str
    name: str
    subject: str
    body: str
    category: str = "standard"
    priority: int = 1
    tags: List[str] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.now)
    
    def format_template(self, **kwargs) -> Dict[str, str]:
        """Format template with provided variables"""
        try:
            formatted_subject = self.subject.format(**kwargs)
            formatted_body = self.body.format(**kwargs)
            
            return {
                'subject': formatted_subject,
                'body': formatted_body,
                'template_id': self.template_id
            }
        except KeyError as e:
            raise ValueError(f"Missing template variable: {e}")

@dataclass
class SystemConfig:
    """System configuration model"""
    company_name: str = "Your Transportation Company"
    contact_name: str = "Your Name"
    phone: str = "(555) 123-4567"
    email: str = "your.email@company.com"
    address: str = "Your Company Address"
    
    # System settings
    auto_refresh_interval: int = 30
    max_loads_to_display: int = 50
    default_radius_miles: int = 150
    browser_headless: bool = False
    
    # Alert settings
    high_profit_threshold: float = 2000.0
    excellent_deal_threshold: float = 3000.0
    enable_sound_alerts: bool = True
    
    # DAT settings
    dat_username: str = ""
    dat_password: str = ""
    
    def to_dict(self) -> Dict:
        return {
            'company': {
                'name': self.company_name,
                'contact_name': self.contact_name,
                'phone': self.phone,
                'email': self.email,
                'address': self.address
            },
            'system': {
                'auto_refresh_interval': self.auto_refresh_interval,
                'max_loads_to_display': self.max_loads_to_display,
                'default_radius_miles': self.default_radius_miles,
                'browser_headless': self.browser_headless
            },
            'alerts': {
                'high_profit_threshold': self.high_profit_threshold,
                'excellent_deal_threshold': self.excellent_deal_threshold,
                'enable_sound_alerts': self.enable_sound_alerts
            },
            'dat': {
                'username': self.dat_username,
                'password': self.dat_password
            }
        }

@dataclass
class MarketData:
    """Market rate and trend data"""
    lane: str  # "Chicago, IL -> Atlanta, GA"
    base_rate_per_mile: float
    current_rate_per_mile: float
    trend: str  # "up", "down", "stable"
    confidence: float  # 0.0 to 1.0
    sample_size: int
    last_updated: datetime = field(default_factory=datetime.now)
    
    def get_rate_recommendation(self, miles: int) -> Dict[str, float]:
        """Get rate recommendations for this lane"""
        base_total = self.base_rate_per_mile * miles
        current_total = self.current_rate_per_mile * miles
        
        # Calculate different rate strategies
        aggressive = current_total * 1.05  # 5% above market
        competitive = current_total
        conservative = current_total * 0.95  # 5% below market
        
        return {
            'aggressive': round(aggressive, 2),
            'competitive': round(competitive, 2),
            'conservative': round(conservative, 2),
            'base_market': round(base_total, 2),
            'current_market': round(current_total, 2)
        }

@dataclass
class SystemMetrics:
    """System performance and usage metrics"""
    loads_scraped_today: int = 0
    emails_sent_today: int = 0
    deals_booked_today: int = 0
    total_profit_today: float = 0.0
    active_drivers: int = 0
    system_uptime: float = 0.0  # hours
    last_dat_scrape: Optional[datetime] = None
    scraping_errors_today: int = 0
    
    def to_dict(self) -> Dict:
        return {
            'loads_scraped_today': self.loads_scraped_today,
            'emails_sent_today': self.emails_sent_today,
            'deals_booked_today': self.deals_booked_today,
            'total_profit_today': self.total_profit_today,
            'active_drivers': self.active_drivers,
            'system_uptime': self.system_uptime,
            'last_dat_scrape': self.last_dat_scrape.isoformat() if self.last_dat_scrape else None,
            'scraping_errors_today': self.scraping_errors_today
        }

# Utility functions for data handling
def load_from_dict(data_dict: Dict, model_class) -> Any:
    """Load data model from dictionary"""
    if model_class == Location:
        return Location(**{k: v for k, v in data_dict.items() if k in Location.__annotations__})
    elif model_class == Driver:
        driver_data = data_dict.copy()
        if 'current_location' in driver_data and driver_data['current_location']:
            driver_data['current_location'] = load_from_dict(driver_data['current_location'], Location)
        if 'status' in driver_data:
            driver_data['status'] = DriverStatus(driver_data['status'])
        if 'created_at' in driver_data:
            driver_data['created_at'] = datetime.fromisoformat(driver_data['created_at'])
        if 'last_updated' in driver_data:
            driver_data['last_updated'] = datetime.fromisoformat(driver_data['last_updated'])
        return Driver(**{k: v for k, v in driver_data.items() if k in Driver.__annotations__})
    elif model_class == LoadData:
        load_data = data_dict.copy()
        if 'origin' in load_data:
            load_data['origin'] = load_from_dict(load_data['origin'], Location)
        if 'destination' in load_data:
            load_data['destination'] = load_from_dict(load_data['destination'], Location)
        if 'status' in load_data:
            load_data['status'] = LoadStatus(load_data['status'])
        if 'deal_quality' in load_data:
            load_data['deal_quality'] = DealQuality(load_data['deal_quality'])
        if 'posted_time' in load_data:
            load_data['posted_time'] = datetime.fromisoformat(load_data['posted_time'])
        if 'scraped_at' in load_data:
            load_data['scraped_at'] = datetime.fromisoformat(load_data['scraped_at'])
        return LoadData(**{k: v for k, v in load_data.items() if k in LoadData.__annotations__})
    
    return model_class(**data_dict)

def export_to_json(data: Any, filepath: str) -> bool:
    """Export data model to JSON file"""
    try:
        if hasattr(data, 'to_dict'):
            json_data = data.to_dict()
        elif isinstance(data, dict):
            json_data = data
        else:
            json_data = data.__dict__
        
        with open(filepath, 'w') as f:
            json.dump(json_data, f, indent=2, default=str)
        
        return True
    except Exception:
        return False

def import_from_json(filepath: str, model_class) -> Optional[Any]:
    """Import data model from JSON file"""
    try:
        with open(filepath, 'r') as f:
            data_dict = json.load(f)
        
        return load_from_dict(data_dict, model_class)
    except Exception:
        return None
