"""
📧 Enterprise Gmail Mailto Integration System
Professional browser-based email composition with zero APIs
Multi-driver support with dynamic templates and intelligent rate suggestions
"""

import urllib.parse
import webbrowser
import json
import os
import re
from datetime import datetime
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict
import logging
import yaml

@dataclass
class EmailTemplate:
    """Enterprise Email Template Model"""
    template_id: str
    name: str
    subject: str
    body: str
    category: str
    priority: int = 1
    tags: List[str] = None
    
    def __post_init__(self):
        if not self.tags:
            self.tags = []

class EnterpriseGmailSystem:
    """
    📧 Enterprise-Grade Gmail Mailto Integration
    
    Features:
    - Professional email templates with smart variable substitution
    - Multi-driver context awareness
    - Intelligent rate suggestions based on market data
    - Browser-based Gmail integration (no APIs)
    - Template customization and management
    - Audit logging for compliance
    - Rate negotiation intelligence
    """
    
    def __init__(self, config_path: str = "config"):
        self.config_path = config_path
        self.templates = {}
        self.company_config = {}
        self.market_rates = {}
        
        # Configure enterprise logging
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s | %(levelname)s | %(module)s:%(funcName)s:%(lineno)d | %(message)s',
            handlers=[
                logging.FileHandler('data/logs/gmail_system.log'),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(__name__)
        
        # Load configuration and templates
        self._load_company_config()
        self._load_email_templates()
        self._initialize_market_rates()
        
        self.logger.info("📧 Enterprise Gmail System initialized")
    
    def _load_company_config(self):
        """Load company configuration from YAML"""
        try:
            config_file = os.path.join(self.config_path, "settings.yaml")
            if os.path.exists(config_file):
                with open(config_file, 'r') as f:
                    config = yaml.safe_load(f)
                    self.company_config = config.get('company', {})
                    
                self.logger.info("✅ Company configuration loaded")
            else:
                # Default company configuration
                self.company_config = {
                    'name': 'Your Transportation Company',
                    'contact_name': 'Your Name',
                    'phone': '(555) 123-4567',
                    'email': 'your.email@gmail.com',
                    'mc_number': 'MC-123456',
                    'dot_number': 'DOT-123456'
                }
                self.logger.warning("⚠️ Using default company configuration")
                
        except Exception as e:
            self.logger.error(f"❌ Failed to load company config: {str(e)}")
            self.company_config = {}
    
    def _load_email_templates(self):
        """Load email templates from YAML configuration"""
        try:
            templates_file = os.path.join(self.config_path, "email_templates.yaml")
            if os.path.exists(templates_file):
                with open(templates_file, 'r') as f:
                    templates_data = yaml.safe_load(f)
                    
                for template_id, template_config in templates_data.items():
                    self.templates[template_id] = EmailTemplate(
                        template_id=template_id,
                        name=template_id.replace('_', ' ').title(),
                        subject=template_config['subject'],
                        body=template_config['body'],
                        category='standard'
                    )
                
                self.logger.info(f"✅ Loaded {len(self.templates)} email templates")
            else:
                self._create_default_templates()
                
        except Exception as e:
            self.logger.error(f"❌ Failed to load email templates: {str(e)}")
            self._create_default_templates()
    
    def _create_default_templates(self):
        """Create default professional email templates"""
        self.templates = {
            'initial_inquiry': EmailTemplate(
                template_id='initial_inquiry',
                name='Initial Inquiry',
                subject='Load Inquiry: {load_id} - {origin} to {destination}',
                body='''Hello,

I hope this message finds you well. I am writing to inquire about the load opportunity posted on DAT:

📋 LOAD DETAILS:
• Load ID: {load_id}
• Route: {origin} → {destination}
• Distance: {miles} miles
• Equipment: {equipment_type}
• Weight: {weight}
• Commodity: {commodity}

🚛 OUR CAPABILITIES:
• Professional driver currently in {driver_location}
• {years_experience}+ years of experience
• Clean driving record and excellent safety rating
• Real-time GPS tracking and communication
• Fully insured and compliant

💰 RATE DISCUSSION:
Based on current market conditions and our operational costs, we would be interested in discussing a rate of ${proposed_rate} for this shipment.

We are available for immediate pickup and committed to on-time delivery. Please let me know if you would like to discuss this opportunity further.

Thank you for your time and consideration.

Best regards,
{contact_name}
{company_name}
📞 {phone}
📧 {email}

🚛 MC: {mc_number} | DOT: {dot_number}''',
                category='inquiry'
            ),
            
            'rate_negotiation': EmailTemplate(
                template_id='rate_negotiation',
                name='Rate Negotiation',
                subject='Rate Discussion: {load_id} - Competitive Market Offer',
                body='''Hello,

Thank you for your quick response regarding load {load_id}.

After reviewing the route details and current market conditions, I would like to propose a competitive rate that works for both parties:

📊 MARKET ANALYSIS:
• Current market rate for this lane: ${market_rate}/mile
• Fuel costs (current): ${fuel_cost}
• Distance efficiency: {miles} miles from {driver_location}
• Our competitive rate: ${proposed_rate} all-in

🎯 VALUE PROPOSITION:
• Guaranteed pickup within {pickup_hours} hours
• Driver already positioned in {driver_location}
• Real-time tracking and proactive communication
• Excellent service record and customer references
• Flexible scheduling to meet your exact needs

This rate reflects current market conditions while ensuring reliable, professional service for your customer.

Would you be open to discussing this rate? I'm available for a quick call at your convenience.

Best regards,
{contact_name}
📞 {phone}''',
                category='negotiation'
            ),
            
            'urgent_response': EmailTemplate(
                template_id='urgent_response',
                name='Urgent Response',
                subject='🔥 URGENT: Available for {load_id} - Immediate Pickup Possible',
                body='''Hello,

I see you have an urgent load {load_id} ({origin} to {destination}) that needs immediate attention.

🚨 IMMEDIATE AVAILABILITY:
• Driver currently in {driver_location} - only {deadhead_miles} miles away
• Can pickup within {pickup_hours} hours
• Clean, compliant equipment ready for dispatch
• Direct communication throughout transit

💰 URGENT RATE:
Given the time-sensitive nature, we can commit at ${proposed_rate} for immediate pickup and guaranteed delivery.

📞 DIRECT CONTACT:
Please call me directly at {phone} for immediate booking confirmation.

Time is critical - I'm standing by for your response.

Regards,
{contact_name}
{phone}''',
                category='urgent'
            ),
            
            'follow_up': EmailTemplate(
                template_id='follow_up',
                name='Professional Follow-up',
                subject='Follow-up: {load_id} - Still Available?',
                body='''Hello,

I wanted to follow up on the load opportunity {load_id} ({origin} to {destination}) that I inquired about earlier.

Is this load still available? We remain very interested and can commit immediately if the terms work for both parties.

🚛 CURRENT STATUS:
• Driver positioned in {driver_location}
• Ready for immediate dispatch
• All paperwork and insurance current
• Committed to your delivery schedule

Please let me know at your earliest convenience if this opportunity is still open.

Thank you for your time.

Best regards,
{contact_name}
{company_name}
📞 {phone}''',
                category='follow_up'
            ),
            
            'booking_confirmation': EmailTemplate(
                template_id='booking_confirmation',
                name='Booking Confirmation',
                subject='✅ BOOKING CONFIRMED: {load_id} - Ready for Pickup',
                body='''Hello,

Thank you for booking load {load_id} with us. Here are the confirmed details:

✅ CONFIRMED LOAD DETAILS:
• Load ID: {load_id}
• Route: {origin} → {destination}
• Pickup Date/Time: {pickup_datetime}
• Delivery Date/Time: {delivery_datetime}
• Confirmed Rate: ${confirmed_rate}
• Equipment: {equipment_type}

🚛 DRIVER INFORMATION:
• Driver Name: {driver_name}
• Direct Phone: {driver_phone}
• Truck/Trailer: {truck_info}
• Current Location: {driver_location}

📋 NEXT STEPS:
1. Driver will call 1 hour before pickup
2. Rate confirmation and paperwork at pickup
3. Real-time tracking updates provided
4. Delivery confirmation upon completion

📧 Please confirm receipt of this email and let me know if you need any additional information.

Thank you for choosing us for your transportation needs.

Best regards,
{contact_name}
{company_name}
📞 {phone}
📧 {email}''',
                category='confirmation'
            )
        }
        
        self.logger.info("✅ Created default email templates")
    
    def _initialize_market_rates(self):
        """Initialize market rate intelligence"""
        # This would typically connect to market data services
        # For now, we'll use intelligent estimates based on common lanes
        self.market_rates = {
            'national_average': 2.45,
            'lanes': {
                'IL_TX': 2.35,
                'TX_CA': 2.55,
                'CA_IL': 2.65,
                'FL_NY': 2.40,
                'GA_IL': 2.30
            },
            'equipment_multipliers': {
                'Dry Van': 1.0,
                'Reefer': 1.15,
                'Flatbed': 1.10,
                'Step Deck': 1.20,
                'Lowboy': 1.35
            },
            'urgency_multipliers': {
                'asap': 1.10,
                'today': 1.05,
                'tomorrow': 1.02,
                'standard': 1.0
            }
        }
    
    def calculate_intelligent_rate(self, load_data: Dict, driver_location: Dict) -> Dict:
        """
        🧠 Calculate intelligent rate suggestions based on market data
        
        Args:
            load_data: Load information
            driver_location: Driver's current location
            
        Returns:
            Dict with rate recommendations and reasoning
        """
        try:
            miles = int(load_data.get('miles', 100))
            equipment_type = load_data.get('equipment_type', 'Dry Van')
            pickup_urgency = load_data.get('pickup_urgency', 'standard').lower()
            deadhead_miles = int(load_data.get('deadhead_miles', 0))
            
            # Base market rate
            base_rate = self.market_rates['national_average']
            
            # Lane-specific adjustment
            origin_state = load_data.get('origin', '').split(',')[-1].strip()
            dest_state = load_data.get('destination', '').split(',')[-1].strip()
            lane_key = f"{origin_state}_{dest_state}"
            
            if lane_key in self.market_rates['lanes']:
                base_rate = self.market_rates['lanes'][lane_key]
            
            # Equipment type multiplier
            equipment_multiplier = self.market_rates['equipment_multipliers'].get(equipment_type, 1.0)
            base_rate *= equipment_multiplier
            
            # Urgency multiplier
            urgency_multiplier = self.market_rates['urgency_multipliers'].get(pickup_urgency, 1.0)
            base_rate *= urgency_multiplier
            
            # Deadhead adjustment
            if deadhead_miles > 50:
                deadhead_adjustment = min(0.15, deadhead_miles / 1000)  # Max 15% increase
                base_rate *= (1 + deadhead_adjustment)
            
            # Calculate different rate scenarios
            conservative_rate = round(base_rate * 0.95, 2)  # 5% below market
            market_rate = round(base_rate, 2)
            competitive_rate = round(base_rate * 1.05, 2)  # 5% above market
            premium_rate = round(base_rate * 1.15, 2)  # 15% above market
            
            # Calculate total amounts
            total_conservative = round(conservative_rate * miles, 2)
            total_market = round(market_rate * miles, 2)
            total_competitive = round(competitive_rate * miles, 2)
            total_premium = round(premium_rate * miles, 2)
            
            # Fuel cost estimation
            fuel_cost = round(miles * 0.65, 2)  # Rough estimate at current rates
            
            rate_analysis = {
                'conservative': {
                    'rate_per_mile': conservative_rate,
                    'total': total_conservative,
                    'description': 'Below market - for quick acceptance'
                },
                'market': {
                    'rate_per_mile': market_rate,
                    'total': total_market,
                    'description': 'Fair market rate'
                },
                'competitive': {
                    'rate_per_mile': competitive_rate,
                    'total': total_competitive,
                    'description': 'Above market - good profit margin'
                },
                'premium': {
                    'rate_per_mile': premium_rate,
                    'total': total_premium,
                    'description': 'Premium rate - high profit'
                },
                'recommended': 'competitive',  # Default recommendation
                'fuel_cost_estimate': fuel_cost,
                'base_market_rate': base_rate,
                'adjustments': {
                    'equipment': f"{equipment_multiplier:.2f}x for {equipment_type}",
                    'urgency': f"{urgency_multiplier:.2f}x for {pickup_urgency}",
                    'deadhead': f"{deadhead_miles} miles deadhead"
                }
            }
            
            # Adjust recommendation based on urgency and deadhead
            if pickup_urgency in ['asap', 'today']:
                rate_analysis['recommended'] = 'premium'
            elif deadhead_miles > 100:
                rate_analysis['recommended'] = 'competitive'
            
            return rate_analysis
            
        except Exception as e:
            self.logger.error(f"❌ Rate calculation failed: {str(e)}")
            return {
                'market': {'rate_per_mile': 2.45, 'total': 245.0, 'description': 'Default market rate'},
                'recommended': 'market',
                'fuel_cost_estimate': 65.0
            }
    
    def create_mailto_link(self, broker_email: str, template_id: str, 
                          load_data: Dict, driver_info: Dict) -> str:
        """
        📧 Create professional Gmail mailto link with intelligent content
        
        Args:
            broker_email: Broker's email address
            template_id: Email template to use
            load_data: Load information
            driver_info: Driver information including location
            
        Returns:
            Complete mailto: URL for Gmail
        """
        try:
            if template_id not in self.templates:
                self.logger.error(f"❌ Template {template_id} not found")
                return ""
            
            template = self.templates[template_id]
            
            # Get intelligent rate suggestions
            rate_analysis = self.calculate_intelligent_rate(load_data, driver_info)
            recommended_rate_data = rate_analysis[rate_analysis['recommended']]
            
            # Prepare template variables
            template_vars = {
                # Load information
                'load_id': load_data.get('load_id', 'Unknown'),
                'origin': load_data.get('origin', 'Unknown Origin'),
                'destination': load_data.get('destination', 'Unknown Destination'),
                'miles': load_data.get('miles', 0),
                'equipment_type': load_data.get('equipment_type', 'Dry Van'),
                'weight': load_data.get('weight', 'Standard'),
                'commodity': load_data.get('commodity', 'General Freight'),
                'pickup_date': load_data.get('pickup_date', 'ASAP'),
                'delivery_date': load_data.get('delivery_date', 'Standard'),
                'pickup_datetime': load_data.get('pickup_date', 'ASAP'),
                'delivery_datetime': load_data.get('delivery_date', 'Standard'),
                'deadhead_miles': load_data.get('deadhead_miles', 0),
                
                # Rate information
                'proposed_rate': recommended_rate_data['total'],
                'market_rate': rate_analysis['market']['rate_per_mile'],
                'confirmed_rate': recommended_rate_data['total'],
                'fuel_cost': rate_analysis['fuel_cost_estimate'],
                
                # Driver information
                'driver_location': f"{driver_info.get('city', 'Unknown')}, {driver_info.get('state', 'Unknown')}",
                'driver_name': driver_info.get('name', 'Professional Driver'),
                'driver_phone': driver_info.get('phone', self.company_config.get('phone', '(555) 123-4567')),
                'truck_info': f"{driver_info.get('truck_number', 'Professional')} / {driver_info.get('equipment_type', 'Late Model')}",
                
                # Company information
                'company_name': self.company_config.get('name', 'Your Transportation Company'),
                'contact_name': self.company_config.get('contact_name', 'Your Name'),
                'phone': self.company_config.get('phone', '(555) 123-4567'),
                'email': self.company_config.get('email', 'your.email@gmail.com'),
                'mc_number': self.company_config.get('mc_number', 'MC-123456'),
                'dot_number': self.company_config.get('dot_number', 'DOT-123456'),
                
                # Operational details
                'years_experience': '10',
                'pickup_hours': '2-4',
            }
            
            # Format subject and body
            try:
                subject = template.subject.format(**template_vars)
                body = template.body.format(**template_vars)
            except KeyError as e:
                self.logger.warning(f"⚠️ Missing template variable: {e}")
                # Replace missing variables with placeholder
                for key, value in template_vars.items():
                    template.subject = template.subject.replace(f"{{{key}}}", str(value))
                    template.body = template.body.replace(f"{{{key}}}", str(value))
                
                subject = template.subject
                body = template.body
            
            # Create mailto URL
            mailto_params = {
                'to': broker_email,
                'subject': subject,
                'body': body
            }
            
            # URL encode parameters
            encoded_params = urllib.parse.urlencode(mailto_params, quote_via=urllib.parse.quote)
            mailto_url = f"mailto:?{encoded_params}"
            
            # Log the email creation
            self.logger.info(f"📧 Created {template_id} email for {broker_email}")
            
            return mailto_url
            
        except Exception as e:
            self.logger.error(f"❌ Failed to create mailto link: {str(e)}")
            return ""
    
    def open_gmail_compose(self, broker_email: str, template_id: str, 
                          load_data: Dict, driver_info: Dict) -> bool:
        """
        🚀 Open Gmail compose window with professional email
        
        Args:
            broker_email: Broker's email address
            template_id: Email template to use
            load_data: Load information
            driver_info: Driver information
            
        Returns:
            bool: Success status
        """
        try:
            mailto_url = self.create_mailto_link(broker_email, template_id, load_data, driver_info)
            
            if mailto_url:
                webbrowser.open(mailto_url)
                self.logger.info(f"🚀 Opened Gmail compose: {template_id} for {broker_email}")
                return True
            
            return False
            
        except Exception as e:
            self.logger.error(f"❌ Failed to open Gmail: {str(e)}")
            return False
    
    def create_email_buttons_for_load(self, load_data: Dict, driver_info: Dict, 
                                     broker_email: str) -> List[Dict]:
        """
        📧 Create multiple email button options for a specific load
        
        Args:
            load_data: Load information
            driver_info: Driver information
            broker_email: Broker's email address
            
        Returns:
            List of email button configurations
        """
        try:
            pickup_urgency = load_data.get('pickup_urgency', 'standard').lower()
            
            # Base email options
            email_buttons = [
                {
                    'label': '📧 Initial Inquiry',
                    'template_id': 'initial_inquiry',
                    'style': 'primary',
                    'description': 'Professional first contact'
                },
                {
                    'label': '💰 Negotiate Rate',
                    'template_id': 'rate_negotiation',
                    'style': 'success',
                    'description': 'Market-based rate discussion'
                },
                {
                    'label': '⏰ Follow Up',
                    'template_id': 'follow_up',
                    'style': 'warning',
                    'description': 'Polite follow-up inquiry'
                }
            ]
            
            # Add urgent response for time-sensitive loads
            if pickup_urgency in ['asap', 'today']:
                email_buttons.insert(1, {
                    'label': '🔥 Urgent Response',
                    'template_id': 'urgent_response',
                    'style': 'danger',
                    'description': 'Immediate availability response'
                })
            
            # Generate mailto URLs for each button
            for button in email_buttons:
                button['mailto_url'] = self.create_mailto_link(
                    broker_email, button['template_id'], load_data, driver_info
                )
                button['broker_email'] = broker_email
            
            return email_buttons
            
        except Exception as e:
            self.logger.error(f"❌ Failed to create email buttons: {str(e)}")
            return []
    
    def get_rate_suggestions(self, load_data: Dict, driver_info: Dict) -> Dict:
        """
        💰 Get intelligent rate suggestions for a load
        
        Args:
            load_data: Load information
            driver_info: Driver information
            
        Returns:
            Rate analysis with recommendations
        """
        return self.calculate_intelligent_rate(load_data, driver_info)
    
    def preview_email(self, template_id: str, load_data: Dict, driver_info: Dict) -> Dict:
        """
        👁️ Preview email content before sending
        
        Args:
            template_id: Email template to preview
            load_data: Load information
            driver_info: Driver information
            
        Returns:
            Dict with subject and body preview
        """
        try:
            # Create a dummy mailto link to get the formatted content
            dummy_email = "preview@example.com"
            mailto_url = self.create_mailto_link(dummy_email, template_id, load_data, driver_info)
            
            # Parse the mailto URL to extract subject and body
            parsed = urllib.parse.urlparse(mailto_url)
            params = urllib.parse.parse_qs(parsed.query)
            
            preview = {
                'template_name': self.templates[template_id].name,
                'subject': urllib.parse.unquote_plus(params.get('subject', [''])[0]),
                'body': urllib.parse.unquote_plus(params.get('body', [''])[0]),
                'template_id': template_id,
                'rate_analysis': self.get_rate_suggestions(load_data, driver_info)
            }
            
            return preview
            
        except Exception as e:
            self.logger.error(f"❌ Email preview failed: {str(e)}")
            return {'error': str(e)}

# 🚀 ENTERPRISE USAGE EXAMPLE
if __name__ == "__main__":
    # Initialize enterprise Gmail system
    gmail_system = EnterpriseGmailSystem()
    
    # Sample load data
    sample_load = {
        'load_id': 'DAT123456',
        'origin': 'Chicago, IL',
        'destination': 'Atlanta, GA',
        'miles': 465,
        'rate_per_mile': 2.25,
        'equipment_type': 'Dry Van',
        'weight': '34,000 lbs',
        'commodity': 'Electronics',
        'pickup_date': 'Today 2:00 PM',
        'delivery_date': 'Tomorrow 8:00 AM',
        'pickup_urgency': 'asap',
        'deadhead_miles': 25
    }
    
    # Sample driver info
    sample_driver = {
        'driver_id': 'D001',
        'name': 'John Smith',
        'city': 'Chicago',
        'state': 'IL',
        'phone': '(555) 987-6543',
        'equipment_type': 'Dry Van',
        'truck_number': 'T001'
    }
    
    broker_email = "broker@example.com"
    
    print("📧 Enterprise Gmail System Demo")
    print("=" * 50)
    
    # Show rate analysis
    rate_analysis = gmail_system.get_rate_suggestions(sample_load, sample_driver)
    print(f"\n💰 Rate Analysis:")
    print(f"   Market Rate: ${rate_analysis['market']['rate_per_mile']}/mile")
    print(f"   Recommended: ${rate_analysis[rate_analysis['recommended']]['rate_per_mile']}/mile")
    print(f"   Total Recommended: ${rate_analysis[rate_analysis['recommended']]['total']}")
    
    # Create email buttons
    email_buttons = gmail_system.create_email_buttons_for_load(
        sample_load, sample_driver, broker_email
    )
    
    print(f"\n📧 Available Email Templates:")
    for i, button in enumerate(email_buttons, 1):
        print(f"   {i}. {button['label']} - {button['description']}")
    
    # Preview an email
    preview = gmail_system.preview_email('initial_inquiry', sample_load, sample_driver)
    print(f"\n👁️ Email Preview - {preview['template_name']}:")
    print(f"   Subject: {preview['subject']}")
    print(f"   Body: {preview['body'][:200]}...")
    
    print(f"\n✅ Ready for enterprise deployment!")
    
    def create_mailto_link(self, broker_email: str, template_type: str, 
                          load_data: Dict, company_data: Dict) -> str:
        """
        🚀 INSTANT: Create Gmail mailto link with pre-filled template
        
        Args:
            broker_email: Broker's email address
            template_type: Type of email template to use
            load_data: Load information from DAT
            company_data: Your company information
            
        Returns:
            Complete mailto: link that opens Gmail with pre-filled email
        """
        try:
            if template_type not in self.templates:
                raise ValueError(f"Unknown template type: {template_type}")
            
            template = self.templates[template_type]
            
            # Format subject line
            subject = template['subject'].format(**load_data, **company_data)
            
            # Format email body
            body = template['body'].format(**load_data, **company_data)
            
            # Create mailto URL
            mailto_params = {
                'to': broker_email,
                'subject': subject,
                'body': body
            }
            
            # URL encode the parameters
            encoded_params = urllib.parse.urlencode(mailto_params, quote_via=urllib.parse.quote)
            mailto_url = f"mailto:?{encoded_params}"
            
            self.logger.info(f"📧 Created mailto link for {broker_email} - {template_type}")
            
            return mailto_url
            
        except Exception as e:
            self.logger.error(f"❌ Failed to create mailto link: {str(e)}")
            return ""
    
    def open_gmail_compose(self, broker_email: str, template_type: str, 
                          load_data: Dict, company_data: Dict) -> bool:
        """
        🚀 INSTANT: Open Gmail compose window with pre-filled email
        """
        try:
            mailto_url = self.create_mailto_link(broker_email, template_type, load_data, company_data)
            
            if mailto_url:
                # Open Gmail in default browser
                webbrowser.open(mailto_url)
                self.logger.info(f"🚀 Opened Gmail compose for {broker_email}")
                return True
            
            return False
            
        except Exception as e:
            self.logger.error(f"❌ Failed to open Gmail: {str(e)}")
            return False
    
    def generate_load_email_data(self, load_info: Dict, 
                                driver_location: str = "") -> Dict:
        """
        🚀 INSTANT: Generate formatted data for email templates
        
        Args:
            load_info: Raw load data from DAT scraper
            driver_location: Current driver location
            
        Returns:
            Formatted data ready for email templates
        """
        try:
            # Calculate proposed rate (you can adjust this logic)
            base_rate = float(load_info.get('rate_per_mile', 2.00))
            miles = int(load_info.get('miles', 100))
            proposed_rate = round(base_rate * miles * 1.1, 2)  # 10% markup
            
            # Market rate estimation
            market_rate = round(base_rate * 1.05, 2)
            
            # Fuel cost estimation
            fuel_cost = round(miles * 0.60, 2)  # Rough estimate
            
            email_data = {
                # Load information
                'load_id': load_info.get('load_id', 'N/A'),
                'origin': load_info.get('origin', 'Unknown'),
                'destination': load_info.get('destination', 'Unknown'),
                'miles': miles,
                'equipment_type': load_info.get('equipment_type', 'Dry Van'),
                'weight': load_info.get('weight', 'N/A'),
                'commodity': load_info.get('commodity', 'General Freight'),
                'pickup_datetime': load_info.get('pickup_date', 'ASAP'),
                'delivery_datetime': load_info.get('delivery_date', 'Standard'),
                
                # Financial information
                'proposed_rate': proposed_rate,
                'market_rate': market_rate,
                'confirmed_rate': proposed_rate,
                'fuel_cost': fuel_cost,
                
                # Driver information
                'driver_location': driver_location,
                'driver_name': 'Professional Driver',
                'driver_phone': '(555) 123-4567',  # You'll set this in config
                'truck_info': 'Late Model Equipment',
                
                # Timing
                'pickup_hours': '2-4',
                'years_experience': '10'
            }
            
            return email_data
            
        except Exception as e:
            self.logger.error(f"❌ Failed to generate email data: {str(e)}")
            return {}
    
    def get_company_data(self) -> Dict:
        """
        📋 Get your company information for emails
        You should customize this with your actual company details
        """
        return {
            'company_name': 'Your Transportation Company',
            'contact_name': 'Your Name',
            'phone_number': '(555) 123-4567',
            'email_address': 'your.email@gmail.com',
            'mc_number': 'MC-123456',
            'dot_number': 'DOT-123456'
        }
    
    def create_quick_email_buttons(self, load_info: Dict, broker_email: str, 
                                  driver_location: str = "") -> Dict[str, str]:
        """
        🚀 INSTANT: Create multiple pre-filled email options for a load
        
        Returns:
            Dictionary of button labels and their mailto URLs
        """
        try:
            email_data = self.generate_load_email_data(load_info, driver_location)
            company_data = self.get_company_data()
            
            # Combine data
            full_data = {**email_data, **company_data}
            
            email_buttons = {}
            
            # Create different email options
            email_options = [
                ('📧 Initial Inquiry', 'initial_inquiry'),
                ('💰 Negotiate Rate', 'rate_negotiation'),
                ('⏰ Follow Up', 'follow_up'),
                ('✅ Confirm Booking', 'booking_confirmation')
            ]
            
            for button_label, template_type in email_options:
                mailto_url = self.create_mailto_link(
                    broker_email, template_type, full_data, {}
                )
                email_buttons[button_label] = mailto_url
            
            return email_buttons
            
        except Exception as e:
            self.logger.error(f"❌ Failed to create email buttons: {str(e)}")
            return {}

# 🚀 QUICK USAGE EXAMPLE
if __name__ == "__main__":
    # Initialize Gmail system
    gmail = GmailMailtoSystem()
    
    # Sample load data (from DAT scraper)
    sample_load = {
        'load_id': 'DAT123456',
        'origin': 'Chicago, IL',
        'destination': 'Atlanta, GA',
        'miles': 465,
        'rate_per_mile': 2.25,
        'equipment_type': 'Dry Van',
        'weight': '34,000 lbs',
        'commodity': 'Electronics',
        'pickup_date': 'Today 2:00 PM',
        'delivery_date': 'Tomorrow 8:00 AM'
    }
    
    broker_email = "broker@example.com"
    driver_location = "Chicago, IL"
    
    # Create email buttons for dashboard
    email_buttons = gmail.create_quick_email_buttons(
        sample_load, broker_email, driver_location
    )
    
    print("📧 Gmail Integration Ready!")
    print(f"✅ Created {len(email_buttons)} email templates")
    
    for button_label, mailto_url in email_buttons.items():
        print(f"\n{button_label}:")
        print(f"📎 {mailto_url[:100]}...")
    
    # Example: Open initial inquiry email
    print("\n🚀 Opening Gmail compose window...")
    success = gmail.open_gmail_compose(
        broker_email, 'initial_inquiry', 
        gmail.generate_load_email_data(sample_load, driver_location),
        gmail.get_company_data()
    )
