"""
🌐 Enterprise DAT.com Browser Scraper
Professional-grade browser automation for real load data extraction
Zero APIs - Pure browser automation with bulletproof error handling
"""

import time
import json
import os
import re
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.common.exceptions import (
    TimeoutException, NoSuchElementException, ElementClickInterceptedException,
    WebDriverException, StaleElementReferenceException
)
from webdriver_manager.chrome import ChromeDriverManager
import undetected_chromedriver as uc
from bs4 import BeautifulSoup
import logging
from urllib.parse import urljoin, urlparse
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed

@dataclass
class LoadData:
    """Enterprise Load Data Model"""
    load_id: str
    origin: str
    destination: str
    pickup_date: str
    delivery_date: str
    miles: int
    rate_per_mile: float
    total_rate: float
    equipment_type: str
    weight: str
    commodity: str
    broker_name: str
    broker_phone: str
    broker_email: str
    deadhead_miles: int = 0
    pickup_urgency: str = "standard"
    equipment_match: bool = False
    lane_popularity: str = "medium"
    posting_timestamp: str = None
    last_updated: str = None
    
    def __post_init__(self):
        if not self.posting_timestamp:
            self.posting_timestamp = datetime.now().isoformat()
        self.last_updated = datetime.now().isoformat()

class EnterpriseDATScraper:
    """
    🌐 Enterprise-Grade DAT.com Browser Scraper
    
    Features:
    - Undetected Chrome browser with stealth mode
    - Professional session management
    - Real-time load extraction
    - Multi-driver location filtering
    - Enterprise error handling and recovery
    - Rate limiting and respectful scraping
    - Full audit logging
    """
    
    def __init__(self, headless: bool = False, debug: bool = False):
        self.driver = None
        self.is_logged_in = False
        self.session_active = False
        self.last_activity = None
        self.load_cache = {}
        self.headless = headless
        self.debug = debug
        
        # Configure enterprise logging
        logging.basicConfig(
            level=logging.INFO if not debug else logging.DEBUG,
            format='%(asctime)s | %(levelname)s | %(module)s:%(funcName)s:%(lineno)d | %(message)s',
            handlers=[
                logging.FileHandler('data/logs/dat_scraper.log'),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(__name__)
        
        # Rate limiting settings
        self.min_request_interval = 2.0  # Minimum seconds between requests
        self.last_request_time = 0
        
        # Session timeout settings
        self.session_timeout = 3600  # 1 hour
        self.max_retries = 3
        
        self.logger.info("🌐 Enterprise DAT Scraper initialized")
    
    def _init_browser(self) -> bool:
        """Initialize undetected Chrome browser with enterprise settings"""
        try:
            # Configure Chrome options for enterprise use
            chrome_options = uc.ChromeOptions()
            
            if self.headless:
                chrome_options.add_argument("--headless=new")
            
            # Enterprise security and performance settings
            chrome_options.add_argument("--no-sandbox")
            chrome_options.add_argument("--disable-dev-shm-usage")
            chrome_options.add_argument("--disable-gpu")
            chrome_options.add_argument("--disable-web-security")
            chrome_options.add_argument("--disable-features=VizDisplayCompositor")
            chrome_options.add_argument("--disable-blink-features=AutomationControlled")
            chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
            chrome_options.add_experimental_option('useAutomationExtension', False)
            
            # Professional user agent
            chrome_options.add_argument(
                "--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
            )
            
            # Performance optimizations
            chrome_options.add_argument("--memory-pressure-off")
            chrome_options.add_argument("--max_old_space_size=4096")
            
            # Initialize undetected Chrome
            self.driver = uc.Chrome(
                options=chrome_options,
                version_main=None,
                driver_executable_path=None
            )
            
            # Configure timeouts
            self.driver.implicitly_wait(10)
            self.driver.set_page_load_timeout(30)
            
            # Execute stealth script
            self.driver.execute_script(
                "Object.defineProperty(navigator, 'webdriver', {get: () => undefined})"
            )
            
            self.logger.info("✅ Browser initialized successfully")
            return True
            
        except Exception as e:
            self.logger.error(f"❌ Browser initialization failed: {str(e)}")
            return False
    
    def login_to_dat(self, username: str, password: str) -> bool:
        """
        🔐 Professional DAT.com login with enterprise security
        
        Args:
            username: DAT.com username
            password: DAT.com password
            
        Returns:
            bool: Success status
        """
        try:
            if not self.driver:
                if not self._init_browser():
                    return False
            
            self.logger.info("🔐 Initiating DAT.com login...")
            
            # Navigate to DAT.com
            self.driver.get("https://www.dat.com/")
            
            # Wait for page load
            WebDriverWait(self.driver, 15).until(
                EC.presence_of_element_located((By.TAG_NAME, "body"))
            )
            
            # Look for login button/link
            login_selectors = [
                "a[href*='login']",
                "button[data-testid*='login']",
                ".login-button",
                "#login-btn",
                "a[text()='Log In']"
            ]
            
            login_element = None
            for selector in login_selectors:
                try:
                    login_element = WebDriverWait(self.driver, 5).until(
                        EC.element_to_be_clickable((By.CSS_SELECTOR, selector))
                    )
                    break
                except TimeoutException:
                    continue
            
            if not login_element:
                # Try to find login by text
                try:
                    login_element = WebDriverWait(self.driver, 5).until(
                        EC.element_to_be_clickable((By.XPATH, "//a[contains(text(), 'Log In')] | //button[contains(text(), 'Log In')]"))
                    )
                except TimeoutException:
                    self.logger.error("❌ Login button not found")
                    return False
            
            # Click login
            login_element.click()
            self.logger.info("🔐 Clicked login button")
            
            # Wait for login form
            try:
                username_field = WebDriverWait(self.driver, 15).until(
                    EC.presence_of_element_located((
                        By.CSS_SELECTOR, 
                        "input[type='email'], input[name*='username'], input[name*='email'], input[id*='username'], input[id*='email']"
                    ))
                )
            except TimeoutException:
                self.logger.error("❌ Username field not found")
                return False
            
            # Enter credentials
            username_field.clear()
            username_field.send_keys(username)
            self.logger.info("✅ Username entered")
            
            # Find password field
            try:
                password_field = self.driver.find_element(
                    By.CSS_SELECTOR,
                    "input[type='password'], input[name*='password'], input[id*='password']"
                )
            except NoSuchElementException:
                self.logger.error("❌ Password field not found")
                return False
            
            password_field.clear()
            password_field.send_keys(password)
            self.logger.info("✅ Password entered")
            
            # Find and click submit button
            submit_selectors = [
                "button[type='submit']",
                "input[type='submit']",
                "button[data-testid*='submit']",
                ".submit-button",
                "#submit-btn"
            ]
            
            submit_element = None
            for selector in submit_selectors:
                try:
                    submit_element = self.driver.find_element(By.CSS_SELECTOR, selector)
                    break
                except NoSuchElementException:
                    continue
            
            if not submit_element:
                # Try to find by text
                try:
                    submit_element = self.driver.find_element(
                        By.XPATH, 
                        "//button[contains(text(), 'Log In')] | //button[contains(text(), 'Sign In')] | //input[@value='Log In']"
                    )
                except NoSuchElementException:
                    self.logger.error("❌ Submit button not found")
                    return False
            
            # Submit login
            submit_element.click()
            self.logger.info("🔐 Login submitted")
            
            # Wait for successful login (check for dashboard/load board)
            try:
                WebDriverWait(self.driver, 20).until(
                    lambda driver: any([
                        "dashboard" in driver.current_url.lower(),
                        "loadboard" in driver.current_url.lower(),
                        "loads" in driver.current_url.lower(),
                        len(driver.find_elements(By.CSS_SELECTOR, ".load-item, .load-row, [data-testid*='load']")) > 0
                    ])
                )
                
                self.is_logged_in = True
                self.session_active = True
                self.last_activity = datetime.now()
                
                self.logger.info("✅ Successfully logged into DAT.com")
                return True
                
            except TimeoutException:
                # Check if there's an error message
                error_elements = self.driver.find_elements(
                    By.CSS_SELECTOR, 
                    ".error, .alert-error, .error-message, [data-testid*='error']"
                )
                
                if error_elements:
                    error_text = error_elements[0].text
                    self.logger.error(f"❌ Login failed: {error_text}")
                else:
                    self.logger.error("❌ Login failed: Unknown error")
                
                return False
                
        except Exception as e:
            self.logger.error(f"❌ Login error: {str(e)}")
            return False
    
    def navigate_to_load_board(self) -> bool:
        """Navigate to the main load board"""
        try:
            if not self.session_active:
                self.logger.error("❌ No active session")
                return False
            
            # Common load board URLs and selectors
            load_board_paths = [
                "/loadboard",
                "/loads",
                "/search",
                "/freight"
            ]
            
            current_url = self.driver.current_url
            
            # Check if already on load board
            if any(path in current_url.lower() for path in load_board_paths):
                self.logger.info("✅ Already on load board")
                return True
            
            # Try to find load board navigation
            nav_selectors = [
                "a[href*='loadboard']",
                "a[href*='loads']",
                "nav a[text()*='Load']",
                ".nav-loads",
                "#loadboard-link"
            ]
            
            for selector in nav_selectors:
                try:
                    nav_element = WebDriverWait(self.driver, 5).until(
                        EC.element_to_be_clickable((By.CSS_SELECTOR, selector))
                    )
                    nav_element.click()
                    self.logger.info("🔗 Navigated to load board")
                    
                    # Wait for load board to load
                    WebDriverWait(self.driver, 15).until(
                        EC.presence_of_element_located((
                            By.CSS_SELECTOR, 
                            ".load-item, .load-row, [data-testid*='load'], .freight-item"
                        ))
                    )
                    
                    return True
                    
                except (TimeoutException, NoSuchElementException):
                    continue
            
            # Try direct URL navigation
            base_url = urlparse(current_url).scheme + "://" + urlparse(current_url).netloc
            for path in load_board_paths:
                try:
                    self.driver.get(base_url + path)
                    
                    # Check if loads are present
                    WebDriverWait(self.driver, 10).until(
                        EC.presence_of_element_located((
                            By.CSS_SELECTOR, 
                            ".load-item, .load-row, [data-testid*='load'], .freight-item"
                        ))
                    )
                    
                    self.logger.info(f"✅ Navigated to load board via: {path}")
                    return True
                    
                except TimeoutException:
                    continue
            
            self.logger.error("❌ Could not navigate to load board")
            return False
            
        except Exception as e:
            self.logger.error(f"❌ Navigation error: {str(e)}")
            return False
    
    def set_location_filter(self, city: str, state: str, radius_miles: int = 150) -> bool:
        """
        🎯 Set location filter for specific driver location
        
        Args:
            city: Driver's current city
            state: Driver's current state
            radius_miles: Search radius in miles
            
        Returns:
            bool: Success status
        """
        try:
            if not self.session_active:
                return False
            
            self.logger.info(f"🎯 Setting location filter: {city}, {state} ({radius_miles} miles)")
            
            # Look for location/origin filter inputs
            location_selectors = [
                "input[placeholder*='Origin']",
                "input[placeholder*='Pickup']", 
                "input[placeholder*='Location']",
                "input[name*='origin']",
                "input[id*='origin']",
                ".origin-input input",
                ".pickup-location input"
            ]
            
            location_input = None
            for selector in location_selectors:
                try:
                    location_input = WebDriverWait(self.driver, 5).until(
                        EC.element_to_be_clickable((By.CSS_SELECTOR, selector))
                    )
                    break
                except TimeoutException:
                    continue
            
            if not location_input:
                self.logger.warning("⚠️ Location filter input not found")
                return False
            
            # Clear and enter location
            location_input.clear()
            location_input.send_keys(f"{city}, {state}")
            
            # Wait for autocomplete/suggestions
            time.sleep(2)
            
            # Try to select from dropdown if available
            try:
                suggestion = WebDriverWait(self.driver, 3).until(
                    EC.element_to_be_clickable((
                        By.CSS_SELECTOR, 
                        ".suggestion, .dropdown-item, .autocomplete-item, li[data-value*='{}']".format(state)
                    ))
                )
                suggestion.click()
                self.logger.info("✅ Selected location from suggestions")
            except TimeoutException:
                # Press Enter if no dropdown
                from selenium.webdriver.common.keys import Keys
                location_input.send_keys(Keys.ENTER)
            
            # Set radius if radius input exists
            radius_selectors = [
                "input[placeholder*='Radius']",
                "input[placeholder*='Miles']",
                "select[name*='radius']",
                ".radius-select",
                "#radius-input"
            ]
            
            for selector in radius_selectors:
                try:
                    radius_input = self.driver.find_element(By.CSS_SELECTOR, selector)
                    
                    if radius_input.tag_name == "select":
                        from selenium.webdriver.support.ui import Select
                        select = Select(radius_input)
                        # Try to find closest radius option
                        for option in select.options:
                            if str(radius_miles) in option.text:
                                select.select_by_visible_text(option.text)
                                break
                    else:
                        radius_input.clear()
                        radius_input.send_keys(str(radius_miles))
                    
                    self.logger.info(f"✅ Set radius to {radius_miles} miles")
                    break
                    
                except NoSuchElementException:
                    continue
            
            # Apply filter (look for search/apply button)
            apply_selectors = [
                "button[type='submit']",
                "button[data-testid*='search']",
                ".search-button",
                ".apply-filters",
                "#search-btn"
            ]
            
            for selector in apply_selectors:
                try:
                    apply_button = self.driver.find_element(By.CSS_SELECTOR, selector)
                    apply_button.click()
                    self.logger.info("✅ Applied location filter")
                    break
                except NoSuchElementException:
                    continue
            
            # Wait for results to update
            time.sleep(3)
            
            self.last_activity = datetime.now()
            return True
            
        except Exception as e:
            self.logger.error(f"❌ Location filter error: {str(e)}")
            return False
    
    def scrape_loads(self, max_loads: int = 50) -> List[LoadData]:
        """
        🕷️ Scrape loads from current page with enterprise data extraction
        
        Args:
            max_loads: Maximum number of loads to extract
            
        Returns:
            List of LoadData objects
        """
        try:
            if not self.session_active:
                return []
            
            # Respect rate limiting
            self._enforce_rate_limit()
            
            self.logger.info(f"🕷️ Scraping loads (max: {max_loads})")
            
            loads = []
            
            # Wait for loads to be present
            try:
                WebDriverWait(self.driver, 10).until(
                    EC.presence_of_element_located((
                        By.CSS_SELECTOR, 
                        ".load-item, .load-row, [data-testid*='load'], .freight-item, tr[data-load], .load-listing"
                    ))
                )
            except TimeoutException:
                self.logger.warning("⚠️ No loads found on page")
                return []
            
            # Get page source for BeautifulSoup parsing
            soup = BeautifulSoup(self.driver.page_source, 'html.parser')
            
            # Find load containers with multiple selector strategies
            load_selectors = [
                '.load-item',
                '.load-row', 
                '[data-testid*="load"]',
                '.freight-item',
                'tr[data-load]',
                '.load-listing',
                '.search-result-item'
            ]
            
            load_elements = []
            for selector in load_selectors:
                elements = soup.select(selector)
                if elements:
                    load_elements = elements
                    self.logger.info(f"✅ Found {len(elements)} loads using selector: {selector}")
                    break
            
            if not load_elements:
                self.logger.warning("⚠️ No load elements found")
                return []
            
            # Extract data from each load
            for i, element in enumerate(load_elements[:max_loads]):
                try:
                    load_data = self._extract_load_data(element, i)
                    if load_data:
                        loads.append(load_data)
                        
                except Exception as e:
                    self.logger.warning(f"⚠️ Failed to extract load {i}: {str(e)}")
                    continue
            
            self.logger.info(f"✅ Successfully scraped {len(loads)} loads")
            self.last_activity = datetime.now()
            
            return loads
            
        except Exception as e:
            self.logger.error(f"❌ Scraping error: {str(e)}")
            return []
    
    def _extract_load_data(self, element, index: int) -> Optional[LoadData]:
        """Extract load data from HTML element"""
        try:
            # Initialize with defaults
            load_data = {
                'load_id': f"DAT_{index}_{int(time.time())}",
                'origin': "Unknown",
                'destination': "Unknown", 
                'pickup_date': "ASAP",
                'delivery_date': "Standard",
                'miles': 0,
                'rate_per_mile': 0.0,
                'total_rate': 0.0,
                'equipment_type': "Dry Van",
                'weight': "N/A",
                'commodity': "General Freight",
                'broker_name': "Unknown Broker",
                'broker_phone': "",
                'broker_email': "",
                'deadhead_miles': 0
            }
            
            # Extract origin/destination using multiple patterns
            location_patterns = [
                r'([A-Z]{2,}(?:\s+[A-Z]{2,})*),\s*([A-Z]{2})\s*→\s*([A-Z]{2,}(?:\s+[A-Z]{2,})*),\s*([A-Z]{2})',
                r'([A-Za-z\s]+),\s*([A-Z]{2})\s*to\s*([A-Za-z\s]+),\s*([A-Z]{2})',
                r'([A-Za-z\s]+)\s+([A-Z]{2})\s*-\s*([A-Za-z\s]+)\s+([A-Z]{2})'
            ]
            
            text_content = element.get_text() if hasattr(element, 'get_text') else str(element)
            
            for pattern in location_patterns:
                match = re.search(pattern, text_content)
                if match:
                    load_data['origin'] = f"{match.group(1).strip()}, {match.group(2)}"
                    load_data['destination'] = f"{match.group(3).strip()}, {match.group(4)}"
                    break
            
            # Extract miles
            miles_pattern = r'(\d{1,4})\s*(?:mi|miles|MI|MILES)'
            miles_match = re.search(miles_pattern, text_content)
            if miles_match:
                load_data['miles'] = int(miles_match.group(1))
            
            # Extract rate information
            rate_patterns = [
                r'\$(\d+(?:\.\d{2})?)\s*/\s*mi',
                r'(\d+(?:\.\d{2})?)\s*per\s*mile',
                r'\$(\d+(?:,\d{3})*(?:\.\d{2})?)\s*total'
            ]
            
            for pattern in rate_patterns:
                rate_match = re.search(pattern, text_content)
                if rate_match:
                    rate_value = float(rate_match.group(1).replace(',', ''))
                    if 'total' in pattern:
                        load_data['total_rate'] = rate_value
                        if load_data['miles'] > 0:
                            load_data['rate_per_mile'] = rate_value / load_data['miles']
                    else:
                        load_data['rate_per_mile'] = rate_value
                        load_data['total_rate'] = rate_value * load_data['miles']
                    break
            
            # Extract equipment type
            equipment_patterns = [
                r'(Dry\s*Van|DRY\s*VAN|Van)',
                r'(Reefer|REEFER|Refrigerated)',
                r'(Flatbed|FLATBED|Flat)',
                r'(Step\s*Deck|STEP\s*DECK)',
                r'(Lowboy|LOWBOY)',
                r'(Container|CONTAINER)'
            ]
            
            for pattern in equipment_patterns:
                equip_match = re.search(pattern, text_content, re.IGNORECASE)
                if equip_match:
                    load_data['equipment_type'] = equip_match.group(1).title()
                    break
            
            # Extract weight
            weight_pattern = r'(\d{1,3}(?:,\d{3})*)\s*(?:lbs|LBS|pounds|#)'
            weight_match = re.search(weight_pattern, text_content)
            if weight_match:
                load_data['weight'] = weight_match.group(1) + " lbs"
            
            # Extract pickup date
            date_patterns = [
                r'(Today|TODAY)',
                r'(Tomorrow|TOMORROW)',
                r'(ASAP|asap)',
                r'(\d{1,2}/\d{1,2}(?:/\d{2,4})?)'
            ]
            
            for pattern in date_patterns:
                date_match = re.search(pattern, text_content)
                if date_match:
                    load_data['pickup_date'] = date_match.group(1)
                    break
            
            # Try to find broker information in links or contact sections
            links = element.find_all('a') if hasattr(element, 'find_all') else []
            for link in links:
                href = link.get('href', '')
                if 'mailto:' in href:
                    load_data['broker_email'] = href.replace('mailto:', '')
                elif 'tel:' in href:
                    load_data['broker_phone'] = href.replace('tel:', '')
            
            # Create LoadData object
            return LoadData(**load_data)
            
        except Exception as e:
            self.logger.warning(f"⚠️ Load data extraction failed: {str(e)}")
            return None
    
    def _enforce_rate_limit(self):
        """Enforce rate limiting to be respectful to DAT.com"""
        current_time = time.time()
        time_since_last = current_time - self.last_request_time
        
        if time_since_last < self.min_request_interval:
            sleep_time = self.min_request_interval - time_since_last
            time.sleep(sleep_time)
        
        self.last_request_time = time.time()
    
    def get_loads_for_driver(self, driver_location: Dict, max_loads: int = 50) -> List[LoadData]:
        """
        🎯 Get loads specifically filtered for a driver's location
        
        Args:
            driver_location: Dict with 'city' and 'state' keys
            max_loads: Maximum loads to return
            
        Returns:
            List of LoadData objects filtered for the driver
        """
        try:
            if not driver_location or not driver_location.get('city'):
                self.logger.warning("⚠️ Invalid driver location provided")
                return []
            
            city = driver_location['city']
            state = driver_location['state']
            
            # Set location filter
            if not self.set_location_filter(city, state):
                self.logger.error(f"❌ Failed to set location filter for {city}, {state}")
                return []
            
            # Scrape loads
            loads = self.scrape_loads(max_loads)
            
            # Add driver context to loads
            for load in loads:
                load.driver_city = city
                load.driver_state = state
            
            self.logger.info(f"✅ Retrieved {len(loads)} loads for driver in {city}, {state}")
            
            return loads
            
        except Exception as e:
            self.logger.error(f"❌ Failed to get loads for driver: {str(e)}")
            return []
    
    def close_session(self):
        """🔒 Properly close browser session"""
        try:
            if self.driver:
                self.driver.quit()
                self.logger.info("✅ Browser session closed")
            
            self.session_active = False
            self.is_logged_in = False
            
        except Exception as e:
            self.logger.error(f"❌ Error closing session: {str(e)}")

# 🚀 ENTERPRISE USAGE EXAMPLE
if __name__ == "__main__":
    # Initialize enterprise scraper
    scraper = EnterpriseDATScraper(headless=False, debug=True)
    
    try:
        # Login (you'll need to provide actual credentials)
        username = input("DAT.com Username: ")
        password = input("DAT.com Password: ")
        
        if scraper.login_to_dat(username, password):
            print("✅ Successfully logged into DAT.com")
            
            # Navigate to load board
            if scraper.navigate_to_load_board():
                print("✅ Navigated to load board")
                
                # Example driver location
                driver_location = {'city': 'Chicago', 'state': 'IL'}
                
                # Get loads for driver
                loads = scraper.get_loads_for_driver(driver_location, max_loads=10)
                
                print(f"\n📊 Found {len(loads)} loads for driver in Chicago, IL:")
                for i, load in enumerate(loads[:5], 1):
                    print(f"\n{i}. Load {load.load_id}")
                    print(f"   Route: {load.origin} → {load.destination}")
                    print(f"   Rate: ${load.rate_per_mile}/mile ({load.miles} miles)")
                    print(f"   Equipment: {load.equipment_type}")
                    print(f"   Pickup: {load.pickup_date}")
            
        else:
            print("❌ Failed to login to DAT.com")
    
    finally:
        # Always close the session
        scraper.close_session()
