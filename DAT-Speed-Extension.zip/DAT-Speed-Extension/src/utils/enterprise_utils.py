"""
🛠️ Enterprise Utilities and Helper Functions
Fedora Linux optimized utilities for the DAT Load Analyzer
"""

import os
import sys
import json
import yaml
import sqlite3
import hashlib
import subprocess
import threading
import time
import logging
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
import base64

# Fedora-specific imports
try:
    import psutil  # For system monitoring
    import distro  # For Linux distribution detection
except ImportError:
    psutil = None
    distro = None

from loguru import logger

class FedoraSystemUtils:
    """Fedora Linux specific system utilities"""
    
    @staticmethod
    def get_system_info() -> Dict[str, Any]:
        """Get Fedora system information"""
        info = {
            'os': 'Unknown',
            'version': 'Unknown',
            'kernel': 'Unknown',
            'cpu_count': 1,
            'memory_gb': 0,
            'disk_free_gb': 0
        }
        
        try:
            # OS information
            if distro:
                info['os'] = distro.name()
                info['version'] = distro.version()
            else:
                # Fallback method
                with open('/etc/fedora-release', 'r') as f:
                    info['os'] = f.read().strip()
            
            # Kernel version
            info['kernel'] = os.uname().release
            
            # System resources
            if psutil:
                info['cpu_count'] = psutil.cpu_count()
                info['memory_gb'] = round(psutil.virtual_memory().total / (1024**3), 2)
                info['disk_free_gb'] = round(psutil.disk_usage('/').free / (1024**3), 2)
            
        except Exception as e:
            logger.warning(f"Could not get system info: {e}")
        
        return info
    
    @staticmethod
    def check_chrome_installation() -> Dict[str, Any]:
        """Check Chrome/Chromium installation on Fedora"""
        chrome_info = {
            'installed': False,
            'version': None,
            'path': None,
            'type': None
        }
        
        # Check for different Chrome installations
        chrome_paths = [
            ('/usr/bin/google-chrome', 'Google Chrome'),
            ('/usr/bin/chromium-browser', 'Chromium'),
            ('/usr/bin/chromium', 'Chromium'),
            ('/opt/google/chrome/chrome', 'Google Chrome'),
            ('/snap/bin/chromium', 'Chromium Snap')
        ]
        
        for path, chrome_type in chrome_paths:
            if os.path.exists(path):
                chrome_info['installed'] = True
                chrome_info['path'] = path
                chrome_info['type'] = chrome_type
                
                # Get version
                try:
                    result = subprocess.run([path, '--version'], 
                                          capture_output=True, text=True)
                    chrome_info['version'] = result.stdout.strip()
                except Exception:
                    pass
                
                break
        
        return chrome_info
    
    @staticmethod
    def install_chrome_fedora() -> bool:
        """Install Chrome on Fedora using dnf"""
        try:
            logger.info("🔧 Installing Google Chrome on Fedora...")
            
            # Add Google Chrome repository
            repo_content = """[google-chrome]
name=google-chrome
baseurl=http://dl.google.com/linux/chrome/rpm/stable/x86_64
enabled=1
gpgcheck=1
gpgkey=https://dl.google.com/linux/linux_signing_key.pub"""
            
            repo_file = "/etc/yum.repos.d/google-chrome.repo"
            
            # Write repo file (requires sudo)
            subprocess.run(['sudo', 'tee', repo_file], 
                          input=repo_content, text=True, check=True)
            
            # Install Chrome
            subprocess.run(['sudo', 'dnf', 'install', '-y', 'google-chrome-stable'], 
                          check=True)
            
            logger.success("✅ Google Chrome installed successfully")
            return True
            
        except subprocess.CalledProcessError as e:
            logger.error(f"❌ Failed to install Chrome: {e}")
            return False
    
    @staticmethod
    def check_python_packages() -> Dict[str, bool]:
        """Check if required Python packages are installed"""
        required_packages = [
            'streamlit', 'pandas', 'plotly', 'selenium', 
            'undetected_chromedriver', 'beautifulsoup4', 
            'requests', 'geopy', 'pyyaml', 'loguru', 
            'sqlalchemy', 'cryptography'
        ]
        
        package_status = {}
        
        for package in required_packages:
            try:
                __import__(package.replace('-', '_'))
                package_status[package] = True
            except ImportError:
                package_status[package] = False
        
        return package_status
    
    @staticmethod
    def optimize_for_fedora():
        """Apply Fedora-specific optimizations"""
        try:
            # Set environment variables for better performance
            os.environ['STREAMLIT_BROWSER_GATHER_USAGE_STATS'] = 'false'
            os.environ['PYTHONUNBUFFERED'] = '1'
            
            # Optimize Chrome for Fedora
            os.environ['CHROME_NO_SANDBOX'] = '1'
            
            logger.info("✅ Fedora optimizations applied")
        except Exception as e:
            logger.warning(f"⚠️ Could not apply all optimizations: {e}")

class SecureCredentialManager:
    """Enterprise-grade credential management"""
    
    def __init__(self, config_dir: str = "config"):
        self.config_dir = Path(config_dir)
        self.config_dir.mkdir(exist_ok=True)
        self.key_file = self.config_dir / ".key"
        self.creds_file = self.config_dir / ".credentials.enc"
        
        # Generate or load encryption key
        self.key = self._get_or_create_key()
        self.cipher = Fernet(self.key)
    
    def _get_or_create_key(self) -> bytes:
        """Get existing key or create new one"""
        if self.key_file.exists():
            with open(self.key_file, 'rb') as f:
                return f.read()
        else:
            # Create new key
            key = Fernet.generate_key()
            with open(self.key_file, 'wb') as f:
                f.write(key)
            
            # Set restrictive permissions (Linux only)
            if os.name == 'posix':
                os.chmod(self.key_file, 0o600)
            
            return key
    
    def store_credentials(self, username: str, password: str, service: str = "dat"):
        """Store encrypted credentials"""
        try:
            credentials = {
                'username': username,
                'password': password,
                'service': service,
                'stored_at': datetime.now().isoformat()
            }
            
            # Encrypt and store
            encrypted_data = self.cipher.encrypt(json.dumps(credentials).encode())
            
            with open(self.creds_file, 'wb') as f:
                f.write(encrypted_data)
            
            # Set restrictive permissions
            if os.name == 'posix':
                os.chmod(self.creds_file, 0o600)
            
            logger.success("✅ Credentials stored securely")
            return True
            
        except Exception as e:
            logger.error(f"❌ Failed to store credentials: {e}")
            return False
    
    def retrieve_credentials(self, service: str = "dat") -> Optional[Dict[str, str]]:
        """Retrieve decrypted credentials"""
        try:
            if not self.creds_file.exists():
                return None
            
            with open(self.creds_file, 'rb') as f:
                encrypted_data = f.read()
            
            # Decrypt
            decrypted_data = self.cipher.decrypt(encrypted_data)
            credentials = json.loads(decrypted_data.decode())
            
            if credentials.get('service') == service:
                return {
                    'username': credentials['username'],
                    'password': credentials['password']
                }
            
            return None
            
        except Exception as e:
            logger.error(f"❌ Failed to retrieve credentials: {e}")
            return None
    
    def delete_credentials(self, service: str = "dat") -> bool:
        """Delete stored credentials"""
        try:
            if self.creds_file.exists():
                os.remove(self.creds_file)
                logger.info(f"✅ Credentials for {service} deleted")
                return True
            return False
        except Exception as e:
            logger.error(f"❌ Failed to delete credentials: {e}")
            return False

class ConfigManager:
    """Configuration file management"""
    
    def __init__(self, config_dir: str = "config"):
        self.config_dir = Path(config_dir)
        self.config_dir.mkdir(exist_ok=True)
    
    def load_yaml(self, filename: str) -> Dict[str, Any]:
        """Load YAML configuration file"""
        file_path = self.config_dir / filename
        
        if not file_path.exists():
            return {}
        
        try:
            with open(file_path, 'r') as f:
                return yaml.safe_load(f) or {}
        except Exception as e:
            logger.error(f"❌ Failed to load {filename}: {e}")
            return {}
    
    def save_yaml(self, filename: str, data: Dict[str, Any]) -> bool:
        """Save data to YAML configuration file"""
        file_path = self.config_dir / filename
        
        try:
            with open(file_path, 'w') as f:
                yaml.dump(data, f, default_flow_style=False, indent=2)
            logger.success(f"✅ Saved {filename}")
            return True
        except Exception as e:
            logger.error(f"❌ Failed to save {filename}: {e}")
            return False
    
    def load_json(self, filename: str) -> Dict[str, Any]:
        """Load JSON configuration file"""
        file_path = self.config_dir / filename
        
        if not file_path.exists():
            return {}
        
        try:
            with open(file_path, 'r') as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"❌ Failed to load {filename}: {e}")
            return {}
    
    def save_json(self, filename: str, data: Dict[str, Any]) -> bool:
        """Save data to JSON configuration file"""
        file_path = self.config_dir / filename
        
        try:
            with open(file_path, 'w') as f:
                json.dump(data, f, indent=2, default=str)
            logger.success(f"✅ Saved {filename}")
            return True
        except Exception as e:
            logger.error(f"❌ Failed to save {filename}: {e}")
            return False

class DatabaseManager:
    """SQLite database management utilities"""
    
    def __init__(self, db_path: str = "data/enterprise.db"):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(exist_ok=True)
    
    def execute_query(self, query: str, params: Tuple = ()) -> Optional[List[Tuple]]:
        """Execute SQL query and return results"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute(query, params)
            
            if query.strip().upper().startswith('SELECT'):
                results = cursor.fetchall()
            else:
                conn.commit()
                results = []
            
            conn.close()
            return results
            
        except Exception as e:
            logger.error(f"❌ Database query failed: {e}")
            return None
    
    def backup_database(self, backup_dir: str = "data/backups") -> bool:
        """Create database backup"""
        try:
            backup_path = Path(backup_dir)
            backup_path.mkdir(exist_ok=True)
            
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_file = backup_path / f"enterprise_backup_{timestamp}.db"
            
            # Copy database file
            import shutil
            shutil.copy2(self.db_path, backup_file)
            
            logger.success(f"✅ Database backed up to {backup_file}")
            return True
            
        except Exception as e:
            logger.error(f"❌ Database backup failed: {e}")
            return False
    
    def optimize_database(self) -> bool:
        """Optimize database performance"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Run VACUUM to reclaim space
            cursor.execute("VACUUM")
            
            # Analyze for query optimization
            cursor.execute("ANALYZE")
            
            conn.close()
            logger.success("✅ Database optimized")
            return True
            
        except Exception as e:
            logger.error(f"❌ Database optimization failed: {e}")
            return False

class SystemMonitor:
    """System performance monitoring"""
    
    def __init__(self):
        self.start_time = datetime.now()
        self.metrics = {
            'uptime': 0,
            'memory_usage': 0,
            'cpu_usage': 0,
            'disk_usage': 0
        }
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get current system metrics"""
        try:
            # Calculate uptime
            uptime = (datetime.now() - self.start_time).total_seconds() / 3600
            self.metrics['uptime'] = round(uptime, 2)
            
            if psutil:
                # Memory usage
                memory = psutil.virtual_memory()
                self.metrics['memory_usage'] = memory.percent
                
                # CPU usage
                self.metrics['cpu_usage'] = psutil.cpu_percent(interval=1)
                
                # Disk usage
                disk = psutil.disk_usage('/')
                self.metrics['disk_usage'] = (disk.used / disk.total) * 100
            
        except Exception as e:
            logger.warning(f"⚠️ Could not get system metrics: {e}")
        
        return self.metrics.copy()

class NetworkUtils:
    """Network connectivity utilities"""
    
    @staticmethod
    def check_internet_connectivity() -> bool:
        """Check if internet connection is available"""
        try:
            import socket
            socket.create_connection(("8.8.8.8", 53), timeout=3)
            return True
        except OSError:
            return False
    
    @staticmethod
    def check_dat_accessibility() -> bool:
        """Check if DAT.com is accessible"""
        try:
            import requests
            response = requests.get("https://www.dat.com", timeout=10)
            return response.status_code == 200
        except Exception:
            return False
    
    @staticmethod
    def get_public_ip() -> Optional[str]:
        """Get public IP address"""
        try:
            import requests
            response = requests.get("https://httpbin.org/ip", timeout=5)
            return response.json().get('origin')
        except Exception:
            return None

class ProcessManager:
    """Process and service management"""
    
    def __init__(self):
        self.processes = {}
    
    def start_background_process(self, name: str, target, *args, **kwargs) -> bool:
        """Start a background process"""
        try:
            if name in self.processes and self.processes[name].is_alive():
                logger.warning(f"⚠️ Process {name} already running")
                return False
            
            process = threading.Thread(target=target, args=args, kwargs=kwargs, daemon=True)
            process.start()
            
            self.processes[name] = process
            logger.success(f"✅ Started background process: {name}")
            return True
            
        except Exception as e:
            logger.error(f"❌ Failed to start process {name}: {e}")
            return False
    
    def stop_process(self, name: str) -> bool:
        """Stop a background process"""
        try:
            if name in self.processes:
                process = self.processes[name]
                if process.is_alive():
                    # Note: Can't actually kill thread in Python, just remove reference
                    del self.processes[name]
                    logger.info(f"✅ Stopped process: {name}")
                    return True
            
            return False
            
        except Exception as e:
            logger.error(f"❌ Failed to stop process {name}: {e}")
            return False
    
    def get_process_status(self) -> Dict[str, bool]:
        """Get status of all managed processes"""
        status = {}
        for name, process in self.processes.items():
            status[name] = process.is_alive()
        return status

# Fedora-specific optimization functions
def optimize_for_fedora():
    """Apply Fedora-specific optimizations"""
    FedoraSystemUtils.optimize_for_fedora()

def check_fedora_dependencies():
    """Check Fedora system dependencies"""
    system_info = FedoraSystemUtils.get_system_info()
    chrome_info = FedoraSystemUtils.check_chrome_installation()
    package_status = FedoraSystemUtils.check_python_packages()
    
    logger.info(f"🐧 System: {system_info['os']} {system_info['version']}")
    logger.info(f"🔧 Chrome: {chrome_info['type']} - {chrome_info['version']}" if chrome_info['installed'] else "❌ Chrome not found")
    
    missing_packages = [pkg for pkg, installed in package_status.items() if not installed]
    if missing_packages:
        logger.warning(f"⚠️ Missing packages: {', '.join(missing_packages)}")
    else:
        logger.success("✅ All Python packages available")
    
    return {
        'system_info': system_info,
        'chrome_info': chrome_info,
        'package_status': package_status,
        'ready': chrome_info['installed'] and not missing_packages
    }

# Initialize utilities for the application
credential_manager = SecureCredentialManager()
config_manager = ConfigManager()
system_monitor = SystemMonitor()
process_manager = ProcessManager()
