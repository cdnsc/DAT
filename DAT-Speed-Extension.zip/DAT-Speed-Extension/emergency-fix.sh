#!/bin/bash
# 🚨 Emergency lxml Fix for Fedora
# Run this to resolve lxml compilation issues immediately

set -e

echo "🚨 FIXING LXML COMPILATION ERROR..."
echo ""

# Check if we're on Fedora
if [ ! -f /etc/fedora-release ]; then
    echo "⚠️ This script is optimized for Fedora Linux"
    echo "For other distributions, install: libxml2-dev libxslt1-dev python3-dev build-essential"
fi

# Update system first
echo "🔄 Updating system packages..."
sudo dnf update -y

# Install comprehensive development packages
echo "🔧 Installing ALL required development packages..."
sudo dnf install -y \
    libxml2-devel \
    libxslt-devel \
    python3-devel \
    python3-pip \
    python3-setuptools \
    python3-wheel \
    gcc \
    gcc-c++ \
    make \
    cmake \
    pkgconfig \
    zlib-devel \
    openssl-devel \
    libffi-devel

# Verify packages are installed
echo "🔍 Verifying XML libraries are installed..."
if ! pkg-config --exists libxml-2.0; then
    echo "❌ libxml2 not found, installing additional packages..."
    sudo dnf install -y libxml2 libxml2-static
fi

if ! pkg-config --exists libxslt; then
    echo "❌ libxslt not found, installing additional packages..."
    sudo dnf install -y libxslt libxslt-static
fi

# Clear all caches completely
echo "🧹 Clearing ALL pip caches..."
python3 -m pip cache purge
rm -rf ~/.cache/pip/*
rm -rf /tmp/pip-*

# Upgrade pip and build tools with force
echo "⬆️ Force upgrading pip and build tools..."
python3 -m pip install --upgrade --force-reinstall pip setuptools wheel

# Try to install lxml with verbose output
echo "📦 Installing lxml with verbose output..."
python3 -m pip install --no-cache-dir --verbose --force-reinstall lxml==5.1.0

echo ""
echo "✅ LXML COMPILATION SUCCESSFUL!"
echo "� Now installing remaining requirements..."

# Install other requirements
python3 -m pip install --no-cache-dir -r requirements.txt

echo ""
echo "✅ ALL PACKAGES INSTALLED SUCCESSFULLY!"
echo "🚀 You can now run: ./start.sh"
