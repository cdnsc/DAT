#!/bin/bash
# 🚨 Emergency lxml Fix for Fedora
# Run this to resolve lxml compilation issues immediately

set -e

echo "🚨 FIXING LXML COMPILATION ERROR..."
echo ""

# Install required system packages
echo "🔧 Installing system dependencies..."
sudo dnf install -y libxml2-devel libxslt-devel python3-devel gcc python3-pip

# Clear all caches
echo "🧹 Clearing pip caches..."
python3 -m pip cache purge
rm -rf ~/.cache/pip

# Upgrade pip and build tools
echo "⬆️ Upgrading pip and build tools..."
python3 -m pip install --upgrade pip setuptools wheel

# Install lxml first (most problematic package)
echo "📦 Installing lxml specifically..."
python3 -m pip install --no-cache-dir --force-reinstall lxml==5.1.0

# Install other requirements
echo "📦 Installing remaining requirements..."
python3 -m pip install --no-cache-dir -r requirements.txt

echo ""
echo "✅ LXML FIX COMPLETE!"
echo "🚀 You can now run: ./start.sh"
