#!/bin/bash
# 🚛 DAT Real-Time Load Analyzer - Complete Installation & Setup Script
# Enterprise-grade installation for Linux (Fedora/Ubuntu/CentOS)

set -e  # Exit on any error

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Configuration
PYTHON_MIN_VERSION="3.9"
PROJECT_NAME="DAT Real-Time Load Analyzer"
VENV_NAME="dat-analyzer-env"

# Print banner
print_banner() {
    echo -e "${BLUE}============================================================${NC}"
    echo -e "${GREEN}🚛 $PROJECT_NAME - Installation Script${NC}"
    echo -e "${BLUE}============================================================${NC}"
    echo -e "${CYAN}Enterprise-grade, multi-driver, real-time load monitoring${NC}"
    echo ""
}

# Print step
print_step() {
    echo -e "${YELLOW}📦 $1${NC}"
}

# Print success
print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

# Print error
print_error() {
    echo -e "${RED}❌ $1${NC}"
}

# Print info
print_info() {
    echo -e "${CYAN}ℹ️  $1${NC}"
}

# Check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Compare version numbers
version_ge() {
    printf '%s\n%s\n' "$2" "$1" | sort -V -C
}

# Detect Linux distribution
detect_distro() {
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        echo $ID
    elif [ -f /etc/fedora-release ]; then
        echo "fedora"
    elif [ -f /etc/redhat-release ]; then
        echo "rhel"
    elif [ -f /etc/debian_version ]; then
        echo "debian"
    else
        echo "unknown"
    fi
}

# Install system dependencies based on distribution
install_system_deps() {
    local distro=$(detect_distro)
    
    print_step "Installing system dependencies for $distro..."
    
    case $distro in
        "fedora")
            print_step "Installing dependencies for Fedora Linux..."
            
            # Update system first
            sudo dnf update -y
            
            # Install Python and development tools
            sudo dnf install -y python3 python3-pip python3-devel \
                               python3-virtualenv python3-setuptools \
                               python3-wheel
            
            # Install Chrome/Chromium for browser automation
            print_step "Installing Google Chrome for Fedora..."
            
            # Add Google Chrome repository
            sudo tee /etc/yum.repos.d/google-chrome.repo > /dev/null << 'EOF'
[google-chrome]
name=google-chrome
baseurl=http://dl.google.com/linux/chrome/rpm/stable/x86_64
enabled=1
gpgcheck=1
gpgkey=https://dl.google.com/linux/linux_signing_key.pub
EOF
            
            # Install Chrome
            sudo dnf install -y google-chrome-stable
            
            # Install system dependencies including comprehensive XML/XSLT libraries
            sudo dnf install -y sqlite git curl wget \
                               gcc gcc-c++ make cmake pkgconfig \
                               libffi-devel openssl-devel \
                               zlib-devel bzip2-devel \
                               readline-devel sqlite-devel \
                               xz-devel tk-devel \
                               libxml2-devel libxslt-devel \
                               libxml2 libxslt \
                               libxml2-static libxslt-static
            
            # Install Fedora-specific performance tools
            sudo dnf install -y htop iotop nethogs \
                               python3-psutil python3-distro
            
            print_success "Fedora dependencies installed"
            ;;
        "ubuntu"|"debian")
            sudo apt update
            sudo apt install -y python3 python3-pip python3-venv python3-dev \
                              chromium-browser chromium-chromedriver \
                              sqlite3 git curl wget \
                              build-essential \
                              libffi-dev libssl-dev \
                              libxml2-dev libxslt1-dev
            ;;
        "centos"|"rhel")
            sudo yum update -y
            sudo yum install -y python3 python3-pip python3-venv python3-devel \
                              chromium chromium-chromedriver \
                              sqlite git curl wget \
                              gcc openssl-devel libffi-devel
            ;;
        *)
            print_error "Unsupported Linux distribution: $distro"
            print_info "This script is optimized for Fedora Linux"
            print_info "Please install Python 3.9+, Chrome/Chromium, and development tools manually"
            exit 1
            ;;
    esac
    
    print_success "System dependencies installed"
}

# Check Python version
check_python() {
    print_step "Checking Python installation..."
    
    if command_exists python3; then
        PYTHON_VERSION=$(python3 -c 'import sys; print(".".join(map(str, sys.version_info[:2])))')
        
        if version_ge "$PYTHON_VERSION" "$PYTHON_MIN_VERSION"; then
            print_success "Python $PYTHON_VERSION found (>= $PYTHON_MIN_VERSION required)"
            return 0
        else
            print_error "Python $PYTHON_VERSION found, but $PYTHON_MIN_VERSION+ required"
            return 1
        fi
    else
        print_error "Python 3 not found"
        return 1
    fi
}

# Install Python if needed
install_python() {
    if ! check_python; then
        print_step "Installing Python $PYTHON_MIN_VERSION+..."
        install_system_deps
    fi
}

# Create virtual environment
create_venv() {
    print_step "Creating Python virtual environment..."
    
    if [ -d "$VENV_NAME" ]; then
        print_info "Virtual environment already exists, removing old one..."
        rm -rf "$VENV_NAME"
    fi
    
    python3 -m venv "$VENV_NAME"
    source "$VENV_NAME/bin/activate"
    
    # Upgrade pip
    pip install --upgrade pip setuptools wheel
    
    print_success "Virtual environment created: $VENV_NAME"
}

# Install Python dependencies
install_python_deps() {
    print_step "Installing Python dependencies..."
    
    # Make sure we're in the virtual environment
    if [ -z "$VIRTUAL_ENV" ]; then
        source "$VENV_NAME/bin/activate"
    fi
    
    # Clear pip cache to avoid version conflicts
    print_step "Clearing pip cache..."
    pip cache purge
    
    # Install from requirements.txt if available
    if [ -f "requirements.txt" ]; then
        print_step "Installing dependencies from requirements.txt..."
        pip install --no-cache-dir -r requirements.txt
        print_success "Installed dependencies from requirements.txt"
    else
        # Install core dependencies manually
        print_info "requirements.txt not found, installing core dependencies..."
        pip install \
            streamlit \
            pandas \
            plotly \
            selenium \
            undetected-chromedriver \
            beautifulsoup4 \
            requests \
            geopy \
            pyyaml \
            loguru \
            sqlalchemy \
            cryptography \
            pillow \
            matplotlib \
            seaborn
        
        print_success "Core dependencies installed"
    fi
    
    # Install enterprise dependencies if available
    if [ -f "requirements-full.txt" ]; then
        print_step "Installing enterprise dependencies..."
        pip install --no-cache-dir -r requirements-full.txt
        print_success "Enterprise dependencies installed"
    fi
}

# Setup Chrome/Chromium driver
setup_chrome_driver() {
    print_step "Setting up Chrome driver..."
    
    # Check if chromedriver is available
    if command_exists chromedriver; then
        print_success "Chrome driver found in system PATH"
        return 0
    fi
    
    # Try to install chromedriver via pip (backup method)
    if [ -z "$VIRTUAL_ENV" ]; then
        source "$VENV_NAME/bin/activate"
    fi
    
    pip install chromedriver-binary
    print_success "Chrome driver installed via pip"
}

# Create directory structure
create_directories() {
    print_step "Creating directory structure..."
    
    mkdir -p data/logs
    mkdir -p data/exports
    mkdir -p config
    mkdir -p scripts
    
    print_success "Directory structure created"
}

# Setup configuration files
setup_config() {
    print_step "Setting up configuration files..."
    
    # Run the setup wizard through Python
    if [ -z "$VIRTUAL_ENV" ]; then
        source "$VENV_NAME/bin/activate"
    fi
    
    python main.py --setup
    
    print_success "Configuration files created"
}

# Create run script
create_run_script() {
    print_step "Creating run script..."
    
    cat > "run_system.sh" << 'EOF'
#!/bin/bash
# 🚀 DAT Real-Time Load Analyzer - Quick Start Script

# Activate virtual environment
if [ -d "dat-analyzer-env" ]; then
    source dat-analyzer-env/bin/activate
else
    echo "❌ Virtual environment not found. Please run install.sh first."
    exit 1
fi

# Check if main.py exists
if [ ! -f "main.py" ]; then
    echo "❌ main.py not found. Please ensure you're in the correct directory."
    exit 1
fi

echo "🚛 Starting DAT Real-Time Load Analyzer..."
echo "================================================"
echo "📊 Dashboard will open in your default browser"
echo "📧 Gmail integration ready for broker communication"
echo "📍 Location tracking system active"
echo ""
echo "💡 QUICK TIPS:"
echo "   • Update driver location in the 'Driver Location' tab"
echo "   • Use 'Load Sample Data' button to test the system"
echo "   • Click email buttons to compose messages to brokers"
echo "   • Toggle 'Auto Refresh' for live monitoring"
echo ""
echo "🛑 Press Ctrl+C to stop the system"
echo ""

# Run the application
python main.py
EOF

    chmod +x "run_system.sh"
    print_success "Run script created: run_system.sh"
}

# Create uninstall script
create_uninstall_script() {
    print_step "Creating uninstall script..."
    
    cat > "uninstall.sh" << 'EOF'
#!/bin/bash
# 🗑️ DAT Real-Time Load Analyzer - Uninstall Script

echo "🗑️ Uninstalling DAT Real-Time Load Analyzer..."

# Remove virtual environment
if [ -d "dat-analyzer-env" ]; then
    rm -rf dat-analyzer-env
    echo "✅ Virtual environment removed"
fi

# Remove data directory (ask user)
read -p "❓ Remove data directory (logs, exports)? [y/N]: " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    rm -rf data
    echo "✅ Data directory removed"
fi

# Remove config directory (ask user)
read -p "❓ Remove configuration files? [y/N]: " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    rm -rf config
    echo "✅ Configuration files removed"
fi

# Remove scripts
rm -f run_system.sh
rm -f uninstall.sh

echo "✅ Uninstall complete"
EOF

    chmod +x "uninstall.sh"
    print_success "Uninstall script created: uninstall.sh"
}

# Test installation
test_installation() {
    print_step "Testing installation..."
    
    if [ -z "$VIRTUAL_ENV" ]; then
        source "$VENV_NAME/bin/activate"
    fi
    
    # Test Python imports
    python -c "
import sys
import streamlit
import pandas
import selenium
import undetected_chromedriver
print('✅ All Python packages imported successfully')
print(f'🐍 Python version: {sys.version}')
" || {
        print_error "Python package test failed"
        return 1
    }
    
    # Test Chrome driver
    python -c "
try:
    import undetected_chromedriver as uc
    driver = uc.Chrome(headless=True)
    driver.quit()
    print('✅ Chrome driver test passed')
except Exception as e:
    print(f'❌ Chrome driver test failed: {e}')
    raise
" || {
        print_error "Chrome driver test failed"
        return 1
    }
    
    print_success "Installation test passed"
}

# Main installation function
main() {
    print_banner
    
    # Check if already installed
    if [ -d "$VENV_NAME" ] && [ -f "main.py" ]; then
        print_info "Installation already exists."
        read -p "❓ Reinstall? [y/N]: " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            print_info "Installation cancelled"
            exit 0
        fi
    fi
    
    # Installation steps
    print_step "Starting installation process..."
    
    # Check/install Python
    if ! check_python; then
        install_python
    fi
    
    # Create virtual environment
    create_venv
    
    # Install dependencies
    install_python_deps
    
    # Setup Chrome driver
    setup_chrome_driver
    
    # Create directories
    create_directories
    
    # Setup configuration
    setup_config
    
    # Create run scripts
    create_run_script
    create_uninstall_script
    
    # Test installation
    test_installation
    
    # Installation complete
    echo ""
    print_success "🎉 Installation completed successfully!"
    echo ""
    echo -e "${CYAN}📋 NEXT STEPS:${NC}"
    echo -e "${YELLOW}   1. Configure your company details in config/settings.yaml${NC}"
    echo -e "${YELLOW}   2. Add your DAT.com credentials when prompted${NC}"
    echo -e "${YELLOW}   3. Run: ./run_system.sh${NC}"
    echo ""
    echo -e "${CYAN}📖 DOCUMENTATION:${NC}"
    echo -e "${YELLOW}   • README.md - Complete usage guide${NC}"
    echo -e "${YELLOW}   • PROJECT_PLAN.md - Technical details${NC}"
    echo ""
    echo -e "${CYAN}🚀 QUICK START:${NC}"
    echo -e "${GREEN}   ./run_system.sh${NC}"
    echo ""
}

# Handle errors
trap 'print_error "Installation failed at line $LINENO"' ERR

# Run main installation
main "$@"
