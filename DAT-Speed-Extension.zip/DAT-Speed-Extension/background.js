// background.js - DAT Speed Pro Background Script
// Compatible with both Manifest V2 and V3

// Compatibility layer for different extension environments
const isServiceWorker = typeof importScripts === 'function';
const runtime = chrome.runtime || browser.runtime;
const storage = chrome.storage || browser.storage;
const tabs = chrome.tabs || browser.tabs;
const alarms = chrome.alarms || browser.alarms;
const notifications = chrome.notifications || browser.notifications;

class DATSpeedPro {
  constructor() {
    this.isMonitoring = false;
    this.lastCheckTime = Date.now();
    this.loadCache = new Map();
    this.alertSettings = {};
    this.analytics = {
      loadsProcessed: 0,
      alertsSent: 0,
      autoBookings: 0,
      profitTracked: 0
    };
    
    this.init();
  }

  async init() {
    console.log('🚀 DAT Speed Pro v2.0 - Enterprise Background Service Started');
    
    try {
      // Load settings
      await this.loadSettings();
      
      // Setup monitoring alarm if alarms API is available
      if (alarms && alarms.create) {
        alarms.create('dat-monitor', { delayInMinutes: 1, periodInMinutes: 1 });
        alarms.onAlarm.addListener((alarm) => {
          if (alarm.name === 'dat-monitor') {
            this.performMonitoring();
          }
        });
      } else {
        // Fallback to setInterval for environments without alarms
        setInterval(() => this.performMonitoring(), 60000);
      }
      
      // Listen for tab updates
      if (tabs && tabs.onUpdated) {
        tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
          if (changeInfo.status === 'complete' && tab.url?.includes('dat.com')) {
            this.injectEnhancements(tabId);
          }
        });
      }
      
      // Setup message listener
      runtime.onMessage.addListener((message, sender, sendResponse) => {
        this.handleMessage(message, sender, sendResponse);
        return true; // Keep message channel open for async responses
      });
      
    } catch (error) {
      console.error('Error initializing DAT Speed Pro:', error);
    }
  }

  async loadSettings() {
    try {
      const settings = await storage.sync.get([
        'monitoringEnabled', 'alertSettings', 'aiSettings', 'crmSettings'
      ]);
      
      this.alertSettings = settings.alertSettings || {
        minRate: 1500,
        maxDeadhead: 100,
        preferredLanes: [],
        excludedBrokers: [],
        autoBook: false
      };
      
      this.isMonitoring = settings.monitoringEnabled || false;
    } catch (error) {
      console.error('Error loading settings:', error);
    }
  }

  async handleMessage(message, sender, sendResponse) {
    try {
      switch (message.action) {
        case 'toggleMonitoring':
          this.isMonitoring = message.enabled;
          await storage.sync.set({ monitoringEnabled: this.isMonitoring });
          sendResponse({ success: true, monitoring: this.isMonitoring });
          break;
          
        case 'getAnalytics':
          sendResponse({ success: true, analytics: this.analytics });
          break;
          
        case 'updateSettings':
          await storage.sync.set({ extensionSettings: message.settings });
          await this.loadSettings();
          sendResponse({ success: true });
          break;
          
        case 'getStats':
          sendResponse({ 
            success: true, 
            stats: {
              loadsAnalyzed: this.analytics.loadsProcessed,
              profitableLoads: this.analytics.alertsSent,
              totalProfit: this.analytics.profitTracked,
              autoBookings: this.analytics.autoBookings
            }
          });
          break;
          
        default:
          sendResponse({ success: false, error: 'Unknown action' });
      }
    } catch (error) {
      console.error('Message handling error:', error);
      sendResponse({ success: false, error: error.message });
    }
  }

  async performMonitoring() {
    if (!this.isMonitoring) return;
    
    try {
      // Get active DAT tabs
      const tabsResult = await tabs.query({ url: '*://*.dat.com/*' });
      
      for (const tab of tabsResult) {
        if (tab.url && tab.url.includes('search-loads')) {
          await this.monitorLoadsTab(tab.id);
        }
      }
      
      this.lastCheckTime = Date.now();
    } catch (error) {
      console.error('Monitoring error:', error);
    }
  }

  async monitorLoadsTab(tabId) {
    try {
      // Simple monitoring - just increment counter for now
      this.analytics.loadsProcessed++;
      
      // In a real implementation, you would inject scripts to extract load data
      // For now, we'll just simulate some activity
      if (Math.random() > 0.8) {
        this.analytics.alertsSent++;
        await this.sendTestAlert(tabId);
      }
      
    } catch (error) {
      console.error('Tab monitoring error:', error);
    }
  }

  async sendTestAlert(tabId) {
    try {
      if (notifications && notifications.create) {
        notifications.create({
          type: 'basic',
          iconUrl: 'icons/icon48.png',
          title: 'DAT Speed Pro Alert',
          message: 'High-scoring load detected!'
        });
      }
    } catch (error) {
      console.error('Notification error:', error);
    }
  }

  async injectEnhancements(tabId) {
    try {
      // Only inject if we have scripting permissions
      if (chrome.scripting && chrome.scripting.executeScript) {
        await chrome.scripting.executeScript({
          target: { tabId },
          files: ['content.js']
        });
      }
    } catch (error) {
      // Silently fail if we can't inject (permissions, etc.)
      console.log('Could not inject content script:', error.message);
    }
  }
}

// Installation handler
runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    console.log('🎉 DAT Speed Pro installed successfully!');
    // Open options page on install
    if (tabs && tabs.create) {
      tabs.create({ url: chrome.runtime.getURL('options.html') });
    }
  }
});

// Initialize the service
const datSpeedPro = new DATSpeedPro();
