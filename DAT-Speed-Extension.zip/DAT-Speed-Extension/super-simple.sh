#!/bin/bash
# 🚀 Super Simple DAT Analyzer for QubesOS
# Minimal dependencies, maximum compatibility

echo "🚀 SUPER SIMPLE SETUP FOR QUBESOS"
echo "================================="

# Install only essential packages
sudo dnf install -y python3 python3-pip chromium

# Install streamlit only
python3 -m pip install --user streamlit pandas

# Create minimal working app
cat > minimal_app.py << 'EOF'
import streamlit as st
import pandas as pd
from datetime import datetime

st.title("🚛 DAT Load Board")

# Sample data
loads = [
    {"ID": "DAT001", "Origin": "Chicago", "Dest": "Denver", "Rate": "$2800", "Miles": 920},
    {"ID": "DAT002", "Origin": "Atlanta", "Dest": "Miami", "Rate": "$1950", "Miles": 650},
    {"ID": "DAT003", "Origin": "Dallas", "Dest": "LA", "Rate": "$4320", "Miles": 1440},
]

df = pd.DataFrame(loads)
st.dataframe(df)

if st.button("Refresh"):
    st.success("Refreshed!")

st.write(f"Last updated: {datetime.now()}")
EOF

echo "✅ Setup complete!"
echo "🚀 Starting app..."

python3 -m streamlit run minimal_app.py
