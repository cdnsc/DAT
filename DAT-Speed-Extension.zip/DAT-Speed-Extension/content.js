// content.js - DAT Speed Pro Content Script
// Enterprise-grade UI enhancements and automation for DAT One

class DATSpeedProContent {
  constructor() {
    this.isActive = false;
    this.loads = new Map();
    this.ui = null;
    this.observer = null;
    this.settings = {};
    
    this.init();
  }

  async init() {
    console.log('🚀 DAT Speed Pro Content Script Loading...');
    
    // Wait for page to be ready
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => this.start());
    } else {
      this.start();
    }
  }

  async start() {
    // Load settings
    await this.loadSettings();
    
    // Check if we're on a supported DAT page
    if (!this.isDATPage()) return;
    
    // Initialize based on page type
    if (this.isSearchPage()) {
      this.initializeSearchPage();
    }
    
    // Setup message listener
    this.setupMessageListener();
    
    console.log('✅ DAT Speed Pro Content Script Ready');
  }

  isDATPage() {
    return window.location.hostname.includes('dat.com');
  }

  isSearchPage() {
    return window.location.pathname.includes('search-loads');
  }

  async loadSettings() {
    const result = await chrome.storage.sync.get(['alertSettings', 'uiSettings']);
    this.settings = {
      alerts: result.alertSettings || {},
      ui: result.uiSettings || { theme: 'dark', position: 'top' }
    };
  }

  initializeSearchPage() {
    console.log('🚀 Initializing search page...');
    
    // Create UI first
    this.createProUI();
    
    // Setup event listeners after a brief delay to ensure DOM is ready
    setTimeout(() => {
      this.setupEventListeners();
    }, 100);
    
    // Wait for DAT.com to load its content before enhancing
    this.waitForDATContent();
    this.isActive = true;
  }

  waitForDATContent() {
    console.log('🔍 Waiting for DAT.com content to load...');
    
    // Check every 500ms for up to 30 seconds
    let attempts = 0;
    const maxAttempts = 60;
    
    const checkInterval = setInterval(() => {
      attempts++;
      
      // Look for the virtual scroll container and load rows
      const tableBody = document.querySelector('[data-test="results-table-body"]');
      const rows = document.querySelectorAll('[data-test="results-table-body"] .row-container');
      
      console.log(`Attempt ${attempts}: Found tableBody=${!!tableBody}, rows=${rows.length}`);
      
      if (tableBody && rows.length > 0) {
        console.log('✅ DAT.com content detected! Initializing enhancements...');
        clearInterval(checkInterval);
        
        // Give it a moment for all content to stabilize
        setTimeout(() => {
          this.enhanceLoadTableOriginal();
          this.setupLoadMonitoring();
        }, 1000);
        
      } else if (attempts >= maxAttempts) {
        console.warn('⚠️ DAT.com content not found after 30 seconds. Trying anyway...');
        clearInterval(checkInterval);
        this.enhanceLoadTableOriginal();
        this.setupLoadMonitoring();
      }
    }, 500);
  }

  setupLoadMonitoring() {
    console.log('📡 Setting up load monitoring...');
    
    // Debug current page structure
    this.debugPageStructure();
    
    // Start real-time monitoring for new loads
    this.startRealTimeUpdates();
    
    // Setup refresh monitoring for when user searches/filters
    this.setupSearchMonitoring();
    
    // Add manual trigger button for debugging
    this.addDebugControls();
  }

  setupSearchMonitoring() {
    // Monitor for search form changes or new search results
    const searchObserver = new MutationObserver((mutations) => {
      mutations.forEach(mutation => {
        if (mutation.type === 'childList') {
          // Check if new search results loaded
          const tableBody = document.querySelector('[data-test="results-table-body"]');
          if (tableBody && mutation.target.contains(tableBody)) {
            console.log('🔄 New search results detected, re-enhancing...');
            setTimeout(() => {
              this.enhanceLoadRows();
            }, 500);
          }
        }
      });
    });

    // Watch the main content area for changes
    const mainContent = document.querySelector('body');
    if (mainContent) {
      searchObserver.observe(mainContent, {
        childList: true,
        subtree: true
      });
    }
  }

  createProUI() {
    // Remove any existing UI
    document.getElementById('dat-speed-pro-ui')?.remove();
    
    // Create main UI container
    const ui = document.createElement('div');
    ui.id = 'dat-speed-pro-ui';
    ui.className = 'dat-speed-pro-container';
    
    ui.innerHTML = `
      <div class="dat-speed-pro-header">
        <div class="dat-speed-logo">
          <img src="${chrome.runtime.getURL('icons/icon48.png')}" alt="DAT Speed Pro" />
          <span class="dat-speed-title">DAT Speed Pro</span>
          <span class="dat-speed-version">v2.0</span>
        </div>
        
        <div class="dat-speed-stats">
          <div class="stat-item">
            <span class="stat-value" id="loads-processed">0</span>
            <span class="stat-label">Loads Processed</span>
          </div>
          <div class="stat-item">
            <span class="stat-value" id="ai-alerts">0</span>
            <span class="stat-label">AI Alerts</span>
          </div>
          <div class="stat-item">
            <span class="stat-value" id="profit-potential">$0</span>
            <span class="stat-label">Profit Potential</span>
          </div>
        </div>
        
        <div class="dat-speed-controls">
          <button id="toggle-monitoring" class="pro-btn pro-btn-primary">
            <span class="btn-icon">🎯</span>
            <span class="btn-text">Start Monitoring</span>
          </button>
          <button id="toggle-ai-mode" class="pro-btn pro-btn-secondary">
            <span class="btn-icon">🤖</span>
            <span class="btn-text">AI Mode</span>
          </button>
          <button id="manual-enhance" class="pro-btn pro-btn-tertiary">
            <span class="btn-icon">🔧</span>
            <span class="btn-text">Enhance Now</span>
          </button>
          <button id="quick-filters" class="pro-btn pro-btn-tertiary">
            <span class="btn-icon">⚡</span>
            <span class="btn-text">Quick Filters</span>
          </button>
          <button id="minimize-ui" class="pro-btn pro-btn-minimal">−</button>
        </div>
      </div>
      
      <div class="dat-speed-pro-panel" id="pro-panel">
        <div class="panel-tabs">
          <button class="tab-btn active" data-tab="monitoring">🎯 Monitoring</button>
          <button class="tab-btn" data-tab="ai-insights">🤖 AI Insights</button>
          <button class="tab-btn" data-tab="analytics">📊 Analytics</button>
          <button class="tab-btn" data-tab="automation">⚡ Automation</button>
        </div>
        
        <div class="panel-content">
          <div class="tab-content active" id="monitoring-tab">
            <div class="monitoring-controls">
              <div class="control-group">
                <label>Min Rate: $<input type="number" id="min-rate" value="1500" min="0" step="50"></label>
                <label>Max DH-O: <input type="number" id="max-dho" value="100" min="0" step="10"> mi</label>
              </div>
              <div class="control-group">
                <label>AI Score Threshold: <input type="range" id="ai-threshold" min="0" max="100" value="70"> <span id="ai-threshold-val">70</span></label>
                <label><input type="checkbox" id="auto-book"> Auto-Book High Scoring Loads</label>
              </div>
            </div>
          </div>
          
          <div class="tab-content" id="ai-insights-tab">
            <div class="ai-insights">
              <div class="insight-item">
                <h4>🔥 Market Hotspots</h4>
                <div id="market-hotspots">Analyzing market data...</div>
              </div>
              <div class="insight-item">
                <h4>💡 Smart Recommendations</h4>
                <div id="smart-recommendations">AI recommendations will appear here</div>
              </div>
            </div>
          </div>
          
          <div class="tab-content" id="analytics-tab">
            <div class="analytics-dashboard">
              <div class="metric-card">
                <h4>Today's Performance</h4>
                <div class="metric-value">$<span id="today-revenue">0</span></div>
                <div class="metric-change">+<span id="revenue-change">0</span>% vs yesterday</div>
              </div>
              <div class="metric-card">
                <h4>Success Rate</h4>
                <div class="metric-value"><span id="success-rate">0</span>%</div>
                <div class="metric-change">Book rate of alerted loads</div>
              </div>
            </div>
          </div>
          
          <div class="tab-content" id="automation-tab">
            <div class="automation-controls">
              <div class="automation-item">
                <label><input type="checkbox" id="auto-contact"> Auto-Contact Brokers</label>
                <p>Automatically send pre-written messages to brokers for high-scoring loads</p>
              </div>
              <div class="automation-item">
                <label><input type="checkbox" id="smart-filtering"> Smart Filtering</label>
                <p>Hide loads that don't meet your profit criteria</p>
              </div>
              <div class="automation-item">
                <label><input type="checkbox" id="competitor-tracking"> Competitor Tracking</label>
                <p>Monitor and alert when competitors book similar loads</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
    
    // Insert UI at the top of the page
    document.body.insertBefore(ui, document.body.firstChild);
    
    // Add padding to body to account for UI
    document.body.style.paddingTop = '120px';
    
    // Setup event listeners
    this.setupUIEventListeners();
    
    this.ui = ui;
  }

  setupUIEventListeners() {
    // Tab switching
    document.querySelectorAll('.tab-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const tabName = e.target.dataset.tab;
        this.switchTab(tabName);
      });
    });
    
    // Monitoring toggle
    document.getElementById('toggle-monitoring')?.addEventListener('click', () => {
      this.toggleMonitoring();
    });
    
    // AI mode toggle
    document.getElementById('toggle-ai-mode')?.addEventListener('click', () => {
      this.toggleAIMode();
    });
  }

  setupEventListeners() {
    console.log('🔗 Setting up event listeners...');
    
    // Manual enhance button
    const manualEnhanceBtn = document.getElementById('manual-enhance');
    if (manualEnhanceBtn) {
      manualEnhanceBtn.addEventListener('click', () => {
        console.log('🔧 Manual enhance clicked');
        this.manualEnhance();
      });
      console.log('✅ Manual enhance button linked');
    } else {
      console.warn('❌ Manual enhance button not found');
    }
    
    // Quick filters
    const quickFiltersBtn = document.getElementById('quick-filters');
    if (quickFiltersBtn) {
      quickFiltersBtn.addEventListener('click', () => {
        console.log('🎯 Quick filters clicked');
        this.showQuickFilters();
      });
      console.log('✅ Quick filters button linked');
    } else {
      console.warn('❌ Quick filters button not found');
    }
    
    // AI mode toggle
    const aiModeBtn = document.getElementById('ai-mode');
    if (aiModeBtn) {
      aiModeBtn.addEventListener('click', () => {
        console.log('🤖 AI mode clicked');
        this.toggleAIMode();
      });
      console.log('✅ AI mode button linked');
    } else {
      console.warn('❌ AI mode button not found');
    }
    
    // Minimize UI
    const minimizeBtn = document.getElementById('minimize-ui');
    if (minimizeBtn) {
      minimizeBtn.addEventListener('click', () => {
        this.toggleUIMinimized();
      });
      console.log('✅ Minimize button linked');
    } else {
      console.warn('❌ Minimize button not found');
    }
    
    // Settings changes
    const aiThreshold = document.getElementById('ai-threshold');
    const aiThresholdVal = document.getElementById('ai-threshold-val');
    if (aiThreshold && aiThresholdVal) {
      aiThreshold.addEventListener('input', (e) => {
        aiThresholdVal.textContent = e.target.value;
      });
      console.log('✅ AI threshold slider linked');
    }
  }

  switchTab(tabName) {
    // Update tab buttons
    document.querySelectorAll('.tab-btn').forEach(btn => {
      btn.classList.remove('active');
    });
    document.querySelector(`[data-tab="${tabName}"]`)?.classList.add('active');
    
    // Update tab content
    document.querySelectorAll('.tab-content').forEach(content => {
      content.classList.remove('active');
    });
    document.getElementById(`${tabName}-tab`)?.classList.add('active');
  }

  async toggleMonitoring() {
    const btn = document.getElementById('toggle-monitoring');
    const isEnabled = btn.classList.contains('active');
    
    try {
      await chrome.runtime.sendMessage({
        action: 'toggleMonitoring',
        enabled: !isEnabled
      });
      
      btn.classList.toggle('active');
      btn.querySelector('.btn-text').textContent = isEnabled ? 'Start Monitoring' : 'Stop Monitoring';
      
      if (!isEnabled) {
        this.startRealTimeUpdates();
      } else {
        this.stopRealTimeUpdates();
      }
    } catch (error) {
      console.error('Failed to toggle monitoring:', error);
    }
  }

  toggleAIMode() {
    const btn = document.getElementById('toggle-ai-mode');
    btn.classList.toggle('active');
    
    const isActive = btn.classList.contains('active');
    btn.querySelector('.btn-text').textContent = isActive ? 'AI Mode ON' : 'AI Mode';
    
    // Apply AI highlighting if active
    if (isActive) {
      this.applyAIHighlighting();
    } else {
      this.removeAIHighlighting();
    }
  }

  showQuickFilters() {
    // Create quick filter popup
    const popup = document.createElement('div');
    popup.className = 'quick-filters-popup';
    popup.innerHTML = `
      <div class="popup-content">
        <h3>Quick Filters</h3>
        <div class="filter-grid">
          <button class="filter-btn" data-filter="high-rate">💰 High Rate (>$2000)</button>
          <button class="filter-btn" data-filter="low-deadhead">🎯 Low Deadhead (<50mi)</button>
          <button class="filter-btn" data-filter="preferred-lanes">🛣️ Preferred Lanes</button>
          <button class="filter-btn" data-filter="hot-loads">🔥 Hot Loads (<30min)</button>
          <button class="filter-btn" data-filter="ai-recommended">🤖 AI Recommended</button>
          <button class="filter-btn" data-filter="clear-all">🔄 Clear All</button>
        </div>
        <button class="close-popup">×</button>
      </div>
    `;
    
    document.body.appendChild(popup);
    
    // Setup filter click handlers
    popup.querySelectorAll('.filter-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        this.applyQuickFilter(e.target.dataset.filter);
        popup.remove();
      });
    });
    
    popup.querySelector('.close-popup').addEventListener('click', () => {
      popup.remove();
    });
  }

  applyQuickFilter(filterType) {
    console.log(`🎯 Applying filter: ${filterType}`);
    
    // Try multiple selectors to find rows
    let rows = document.querySelectorAll('[data-test="results-table-body"] .row-container');
    
    // Fallback selectors if the first one doesn't work
    if (rows.length === 0) {
      rows = document.querySelectorAll('.row-container');
    }
    if (rows.length === 0) {
      rows = document.querySelectorAll('[class*="row"]');
    }
    if (rows.length === 0) {
      rows = document.querySelectorAll('.cdk-virtual-scroll-content-wrapper > div');
    }
    
    console.log(`Found ${rows.length} rows to filter`);
    
    if (rows.length === 0) {
      alert('No load rows found. Please make sure you are on the DAT load search page with results.');
      return;
    }
    
    let filteredCount = 0;
    let hiddenCount = 0;
    
    rows.forEach((row, index) => {
      // Reset visibility
      row.style.display = '';
      row.style.opacity = '';
      
      let shouldHide = false;
      
      switch (filterType) {
        case 'high-rate':
          const rateCell = row.querySelector('[data-test="load-rate-cell"] .offer') || 
                          row.querySelector('.offer') ||
                          row.querySelector('[class*="rate"]');
          if (rateCell) {
            const rate = parseInt(rateCell.textContent.replace(/[^\d]/g, '')) || 0;
            console.log(`Row ${index}: Rate = $${rate}`);
            shouldHide = rate < 2000;
          } else {
            console.log(`Row ${index}: No rate cell found`);
            shouldHide = true;
          }
          break;
          
        case 'low-deadhead':
          const dhoCell = row.querySelector('[data-test="load-dho-cell"]') ||
                         row.querySelector('[class*="deadhead"]') ||
                         row.querySelector('[class*="dho"]');
          if (dhoCell) {
            const dho = parseInt(dhoCell.textContent.replace(/[^\d]/g, '')) || 999;
            console.log(`Row ${index}: DHO = ${dho}mi`);
            shouldHide = dho > 50;
          } else {
            console.log(`Row ${index}: No DHO cell found`);
            shouldHide = true;
          }
          break;
          
        case 'hot-loads':
          const ageCell = row.querySelector('[data-test="load-age-cell"]') ||
                         row.querySelector('[class*="age"]');
          if (ageCell) {
            const ageText = ageCell.textContent?.trim() || '';
            const ageMinutes = this.parseAgeToMinutes(ageText);
            console.log(`Row ${index}: Age = ${ageText} (${ageMinutes} minutes)`);
            shouldHide = ageMinutes > 30;
          } else {
            console.log(`Row ${index}: No age cell found`);
            shouldHide = true;
          }
          break;
          
        case 'preferred-lanes':
          const originCell = row.querySelector('[data-test="load-origin-cell"]') ||
                           row.querySelector('[class*="origin"]');
          const destCell = row.querySelector('[data-test="load-destination-cell"]') ||
                          row.querySelector('[class*="destination"]');
          
          if (originCell && destCell) {
            const origin = originCell.textContent.trim();
            const destination = destCell.textContent.trim();
            console.log(`Row ${index}: ${origin} → ${destination}`);
            
            // Define preferred states/markets
            const preferredMarkets = ['CA', 'TX', 'FL', 'NY', 'IL', 'GA', 'PA', 'OH', 'NC'];
            const hasPreferredOrigin = preferredMarkets.some(market => origin.includes(market));
            const hasPreferredDest = preferredMarkets.some(market => destination.includes(market));
            
            shouldHide = !(hasPreferredOrigin && hasPreferredDest);
          } else {
            console.log(`Row ${index}: No origin/destination cells found`);
            shouldHide = true;
          }
          break;
          
        case 'clear-all':
          // Show all rows
          shouldHide = false;
          break;
          
        default:
          console.log(`Filter ${filterType} not implemented yet`);
          return;
      }
      
      if (shouldHide) {
        row.style.display = 'none';
        hiddenCount++;
      } else {
        filteredCount++;
      }
    });
    
    console.log(`✅ Filter complete: ${filteredCount} rows visible, ${hiddenCount} rows hidden`);
    
    // Show notification
    this.showNotification(`Filter applied: ${filteredCount} loads match "${filterType}" criteria`);
  }

  parseAgeToMinutes(ageStr) {
    const match = ageStr.match(/(\d+)([hm])/);
    if (!match) return 0;
    
    const value = parseInt(match[1]);
    const unit = match[2];
    
    return unit === 'h' ? value * 60 : value;
  }

  // Auto-sort loads based on DHO (low to high) and Rate (high to low)
  sortLoadTable() {
    const tableBody = document.querySelector('[data-test="results-table-body"]');
    if (!tableBody) return;

    const rows = Array.from(document.querySelectorAll('[data-test="results-table-body"] .row-container'));
    if (rows.length === 0) return;

    // Sort rows based on the criteria: DHO (low to high) and Rate (high to low)
    rows.sort((a, b) => {
      const loadDataA = this.extractLoadDataFromRow(a);
      const loadDataB = this.extractLoadDataFromRow(b);
      
      if (!loadDataA || !loadDataB) return 0;

      // Primary sort: DHO (low to high)
      if (loadDataA.dho !== loadDataB.dho) {
        return loadDataA.dho - loadDataB.dho;
      }

      // Secondary sort: Rate (high to low)
      return loadDataB.rate - loadDataA.rate;
    });

    // Clear and re-append sorted rows
    rows.forEach(row => row.remove());
    rows.forEach(row => tableBody.appendChild(row));

    // Add sort indicators to headers
    this.addSortIndicators();
  }

  addSortIndicators() {
    // Add visual indicators to show current sort
    const headers = document.querySelectorAll('.header-cell');
    
    headers.forEach(header => {
      // Remove existing sort indicators
      const existingIndicator = header.querySelector('.sort-indicator');
      if (existingIndicator) {
        existingIndicator.remove();
      }
    });

    // Add DHO sort indicator (ascending)
    const dhoHeader = Array.from(headers).find(h => 
      h.textContent.toLowerCase().includes('dh') || 
      h.textContent.toLowerCase().includes('deadhead')
    );
    if (dhoHeader) {
      const indicator = document.createElement('span');
      indicator.className = 'sort-indicator';
      indicator.innerHTML = ' ↑';
      indicator.style.color = '#4caf50';
      indicator.style.fontWeight = 'bold';
      dhoHeader.appendChild(indicator);
    }

    // Add Rate sort indicator (descending)
    const rateHeader = Array.from(headers).find(h => 
      h.textContent.toLowerCase().includes('rate') || 
      h.textContent.toLowerCase().includes('$')
    );
    if (rateHeader) {
      const indicator = document.createElement('span');
      indicator.className = 'sort-indicator';
      indicator.innerHTML = ' ↓';
      indicator.style.color = '#f44336';
      indicator.style.fontWeight = 'bold';
      rateHeader.appendChild(indicator);
    }
  }

  // Enhanced table enhancement with auto-sorting
  enhanceLoadTable() {
    // Add AI score column if not exists
    const headerRow = document.querySelector('.header-cells');
    if (headerRow && !document.querySelector('.ai-score-header')) {
      const aiHeader = document.createElement('div');
      aiHeader.className = 'header-cell ai-score-header';
      aiHeader.innerHTML = '<span>🤖 AI Score</span>';
      aiHeader.style.order = '10';
      headerRow.appendChild(aiHeader);
    }
    
    // Enhance load rows first
    this.enhanceLoadRows();
    
    // Then apply sorting
    this.sortLoadTable();
    
    // Add auto-sort notification
    this.showSortNotification();
  }

  showSortNotification() {
    // Show a notification that auto-sorting is active
    const notification = document.createElement('div');
    notification.className = 'sort-notification';
    notification.innerHTML = `
      <div style="
        position: fixed;
        top: 20px;
        right: 20px;
        background: linear-gradient(135deg, #4caf50 0%, #45a049 100%);
        color: white;
        padding: 12px 20px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(76,175,80,0.3);
        z-index: 999999;
        font-family: 'Segoe UI', sans-serif;
        font-weight: 600;
        display: flex;
        align-items: center;
        gap: 8px;
        animation: slideInRight 0.3s ease;
      ">
        <span>🎯</span>
        <span>Auto-sorted: DHO ↑ | Rate ↓</span>
      </div>
    `;
    
    document.body.appendChild(notification);
    
    // Remove notification after 3 seconds
    setTimeout(() => {
      if (notification && notification.parentNode) {
        notification.remove();
      }
    }, 3000);
  }

  // Add CSS for sort animations
  addSortingStyles() {
    const style = document.createElement('style');
    style.textContent = `
      @keyframes slideInRight {
        from {
          transform: translateX(100%);
          opacity: 0;
        }
        to {
          transform: translateX(0);
          opacity: 1;
        }
      }
      
      .sort-indicator {
        font-size: 14px;
        margin-left: 4px;
        opacity: 0.8;
      }
      
      .row-container {
        transition: transform 0.3s ease;
      }
      
      .row-container:hover {
        transform: translateX(2px);
        box-shadow: 2px 0 8px rgba(0,0,0,0.1);
      }
    `;
    
    if (!document.head.querySelector('#sorting-styles')) {
      style.id = 'sorting-styles';
      document.head.appendChild(style);
    }
  }

  // Enhanced table enhancement with auto-sorting
  enhanceLoadTableOriginal() {
    // Add AI score column if not exists
    const headerRow = document.querySelector('.header-cells');
    if (headerRow && !document.querySelector('.ai-score-header')) {
      const aiHeader = document.createElement('div');
      aiHeader.className = 'header-cell ai-score-header';
      aiHeader.innerHTML = '<span>🤖 AI Score</span>';
      aiHeader.style.order = '10';
      headerRow.appendChild(aiHeader);
    }
    
    // Enhance load rows first
    this.enhanceLoadRows();
    
    // Then apply sorting (DHO low to high, Rate high to low)
    this.sortLoadTable();
    
    // Add sorting styles
    this.addSortingStyles();
    
    // Show notification
    this.showSortNotification();
  }

  enhanceLoadRows() {
    console.log('🔧 Starting load row enhancement...');
    
    const rows = document.querySelectorAll('[data-test="results-table-body"] .row-container');
    console.log(`Found ${rows.length} load rows to enhance`);
    
    if (rows.length === 0) {
      console.warn('⚠️ No load rows found! Checking page structure...');
      this.debugPageStructure();
      return;
    }

    let enhancedCount = 0;
    rows.forEach((row, index) => {
      if (row.dataset.enhanced) {
        console.log(`Row ${index} already enhanced, skipping`);
        return; // Skip if already enhanced
      }

      // Extract load data
      const loadData = this.extractLoadDataFromRow(row);
      if (!loadData) {
        console.warn(`Failed to extract data from row ${index}`);
        return;
      }

      console.log(`Enhancing row ${index}:`, loadData);

      // Calculate AI score
      const aiScore = this.calculateAIScore(loadData);

      // Add AI score cell
      this.addAIScoreCell(row, aiScore);

      // Add profit indicator
      this.addProfitIndicator(row, loadData);

      // Apply highlighting based on score
      this.applyRowHighlighting(row, aiScore);

      row.dataset.enhanced = 'true';
      row.dataset.aiScore = aiScore;
      enhancedCount++;
    });
    
    console.log(`✅ Enhanced ${enhancedCount} load rows successfully`);
  }

  // Debug function to check page structure
  debugPageStructure() {
    console.log('🔍 DEBUG: Checking page structure...');
    
    // Check for various row selectors
    const selectors = [
      '[data-test="results-table-body"]',
      '[data-test="results-table-body"] .row-container',
      '.row-container',
      '.cdk-virtual-scroll-content-wrapper',
      '.cdk-virtual-scroll-content-wrapper > div',
      '[class*="row"]',
      '[data-test="load-rate-cell"]',
      '[data-test="load-origin-cell"]',
      '[data-test="load-age-cell"]'
    ];
    
    selectors.forEach(selector => {
      const elements = document.querySelectorAll(selector);
      console.log(`${selector}: ${elements.length} elements found`);
      if (elements.length > 0) {
        console.log('First element:', elements[0]);
      }
    });
    
    // Check if we're on the right page
    console.log('Current URL:', window.location.href);
    console.log('Page title:', document.title);
    
    // Look for any load data
    const rateElements = document.querySelectorAll('[data-test="load-rate-cell"]');
    if (rateElements.length > 0) {
      console.log('Sample rate data:', rateElements[0].textContent);
    }
    
    return {
      url: window.location.href,
      title: document.title,
      rowCount: document.querySelectorAll('.row-container').length,
      hasLoadData: rateElements.length > 0
    };
  }

  extractLoadDataFromRow(row) {
    try {
      const rateCell = row.querySelector('[data-test="load-rate-cell"] .offer');
      const originCell = row.querySelector('[data-test="load-origin-cell"]');
      const destCell = row.querySelector('[data-test="load-destination-cell"]');
      const dhoCell = row.querySelector('[data-test="load-dho-cell"]');
      const ageCell = row.querySelector('[data-test="load-age-cell"]');
      
      if (!rateCell || !originCell || !destCell) return null;
      
      return {
        rate: parseInt(rateCell.textContent.replace(/[^\d]/g, '')) || 0,
        origin: originCell.textContent.trim(),
        destination: destCell.textContent.trim(),
        dho: parseInt(dhoCell?.textContent.replace(/[^\d]/g, '')) || 0,
        age: ageCell?.textContent.trim() || ''
      };
    } catch (error) {
      console.warn('Error extracting load data:', error);
      return null;
    }
  }

  calculateAIScore(loadData) {
    let score = 0;
    
    // Rate scoring (0-40 points)
    score += Math.min(40, loadData.rate / 50);
    
    // Deadhead scoring (0-30 points)
    score += Math.max(0, 30 - (loadData.dho / 3));
    
    // Age scoring (0-20 points)
    const ageMinutes = this.parseAgeToMinutes(loadData.age);
    score += Math.max(0, 20 - (ageMinutes / 3));
    
    // Lane scoring (0-10 points)
    score += this.calculateLaneScore(loadData.origin, loadData.destination);
    
    return Math.min(100, Math.round(score));
  }

  calculateLaneScore(origin, destination) {
    // Basic lane scoring
    const goodMarkets = ['CA', 'TX', 'FL', 'NY', 'IL', 'GA'];
    let score = 0;
    
    if (goodMarkets.some(market => origin.includes(market))) score += 3;
    if (goodMarkets.some(market => destination.includes(market))) score += 3;
    
    return score;
  }

  addAIScoreCell(row, score) {
    // Check if already added
    if (row.querySelector('.ai-score-cell')) return;
    
    const scoreCell = document.createElement('div');
    scoreCell.className = 'table-cell ai-score-cell';
    scoreCell.style.order = '10';
    
    const scoreColor = score >= 80 ? '#00ff00' : score >= 60 ? '#ffff00' : '#ff6666';
    const scoreIcon = score >= 80 ? '🔥' : score >= 60 ? '⭐' : '📊';
    
    scoreCell.innerHTML = `
      <div class="ai-score-container">
        <span class="ai-score-icon">${scoreIcon}</span>
        <span class="ai-score-value" style="color: ${scoreColor}">${score}</span>
      </div>
    `;
    
    row.querySelector('.row-cells')?.appendChild(scoreCell);
  }

  addProfitIndicator(row, loadData) {
    // Add profit potential indicator
    const profitEstimate = this.calculateProfitEstimate(loadData);
    
    if (profitEstimate > 0) {
      const indicator = document.createElement('div');
      indicator.className = 'profit-indicator';
      indicator.innerHTML = `💰 ~$${profitEstimate} profit`;
      indicator.style.cssText = `
        position: absolute;
        top: 5px;
        right: 5px;
        background: #4caf50;
        color: white;
        padding: 2px 6px;
        border-radius: 4px;
        font-size: 11px;
        font-weight: bold;
        z-index: 10;
      `;
      
      row.style.position = 'relative';
      row.appendChild(indicator);
    }
  }

  calculateProfitEstimate(loadData) {
    // Basic profit calculation (rate - expenses)
    const baseCostPerMile = 1.8; // Adjust based on current market
    const estimatedMiles = loadData.dho + 500; // Rough estimate
    const estimatedCost = estimatedMiles * baseCostPerMile;
    
    return Math.max(0, loadData.rate - estimatedCost);
  }

  applyRowHighlighting(row, score) {
    row.classList.remove('high-score', 'medium-score', 'low-score', 'excellent-deal', 'good-deal');
    
    // Enhanced highlighting with green colors and mail icons for good deals
    if (score >= 85) {
      row.classList.add('excellent-deal');
      this.addGoodDealHighlighting(row, 'excellent');
    } else if (score >= 70) {
      row.classList.add('good-deal');
      this.addGoodDealHighlighting(row, 'good');
    } else if (score >= 60) {
      row.classList.add('medium-score');
    } else {
      row.classList.add('low-score');
    }
  }

  addGoodDealHighlighting(row, dealType) {
    // Remove any existing highlighting elements
    const existingHighlight = row.querySelector('.good-deal-overlay');
    if (existingHighlight) {
      existingHighlight.remove();
    }

    // Create advanced green highlighting overlay
    const overlay = document.createElement('div');
    overlay.className = 'good-deal-overlay';
    
    const isExcellent = dealType === 'excellent';
    const gradientColor = isExcellent 
      ? 'linear-gradient(90deg, rgba(76, 175, 80, 0.2) 0%, rgba(139, 195, 74, 0.15) 100%)'
      : 'linear-gradient(90deg, rgba(139, 195, 74, 0.15) 0%, rgba(76, 175, 80, 0.1) 100%)';
    
    overlay.style.cssText = `
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: ${gradientColor};
      border-left: 4px solid ${isExcellent ? '#4CAF50' : '#8BC34A'};
      border-radius: 0 4px 4px 0;
      pointer-events: none;
      z-index: 1;
      animation: goodDealPulse 2s ease-in-out infinite;
    `;

    // Add mail icon for contacting broker
    const mailIcon = document.createElement('div');
    mailIcon.className = 'deal-mail-icon';
    mailIcon.innerHTML = '📧';
    mailIcon.title = 'Click to contact broker immediately!';
    mailIcon.style.cssText = `
      position: absolute;
      top: 8px;
      right: 8px;
      background: ${isExcellent ? '#2E7D32' : '#689F38'};
      color: white;
      width: 32px;
      height: 32px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 14px;
      cursor: pointer;
      z-index: 10;
      box-shadow: 0 2px 8px rgba(76, 175, 80, 0.4);
      transition: all 0.3s ease;
      animation: mailIconBounce 1s ease-in-out infinite;
    `;

    // Add click handler for mail icon
    mailIcon.addEventListener('click', (e) => {
      e.stopPropagation();
      this.openContactBrokerModal(row);
    });

    mailIcon.addEventListener('mouseenter', () => {
      mailIcon.style.transform = 'scale(1.2)';
      mailIcon.style.boxShadow = '0 4px 12px rgba(76, 175, 80, 0.6)';
    });

    mailIcon.addEventListener('mouseleave', () => {
      mailIcon.style.transform = 'scale(1)';
      mailIcon.style.boxShadow = '0 2px 8px rgba(76, 175, 80, 0.4)';
    });

    // Add deal badge
    const dealBadge = document.createElement('div');
    dealBadge.className = 'deal-badge';
    dealBadge.innerHTML = isExcellent ? '🔥 EXCELLENT DEAL!' : '⭐ GOOD DEAL!';
    dealBadge.style.cssText = `
      position: absolute;
      top: 8px;
      left: 8px;
      background: ${isExcellent ? '#1B5E20' : '#33691E'};
      color: white;
      padding: 4px 8px;
      border-radius: 12px;
      font-size: 11px;
      font-weight: bold;
      z-index: 10;
      text-shadow: 1px 1px 2px rgba(0,0,0,0.3);
      animation: dealBadgeGlow 2s ease-in-out infinite;
    `;

    // Add profit indicator with enhanced styling
    const loadData = this.extractLoadDataFromRow(row);
    if (loadData) {
      const profitEstimate = this.calculateProfitEstimate(loadData);
      if (profitEstimate > 0) {
        const profitBadge = document.createElement('div');
        profitBadge.className = 'enhanced-profit-badge';
        profitBadge.innerHTML = `💰 $${profitEstimate.toLocaleString()} profit`;
        profitBadge.style.cssText = `
          position: absolute;
          bottom: 8px;
          right: 8px;
          background: linear-gradient(45deg, #2E7D32, #388E3C);
          color: white;
          padding: 6px 10px;
          border-radius: 8px;
          font-size: 12px;
          font-weight: bold;
          z-index: 10;
          box-shadow: 0 2px 8px rgba(46, 125, 50, 0.3);
          border: 1px solid #4CAF50;
        `;
        row.appendChild(profitBadge);
      }
    }

    // Add quick action buttons
    const actionBar = document.createElement('div');
    actionBar.className = 'deal-action-bar';
    actionBar.style.cssText = `
      position: absolute;
      bottom: -30px;
      left: 0;
      right: 0;
      background: rgba(76, 175, 80, 0.95);
      padding: 6px;
      border-radius: 0 0 8px 8px;
      display: flex;
      gap: 8px;
      justify-content: center;
      opacity: 0;
      transition: all 0.3s ease;
      z-index: 15;
    `;

    actionBar.innerHTML = `
      <button class="deal-action-btn book-now" title="Book This Load Now">📞 Book Now</button>
      <button class="deal-action-btn negotiate" title="Negotiate Rate">💬 Negotiate</button>
      <button class="deal-action-btn save-load" title="Save to Favorites">⭐ Save</button>
    `;

    // Style the action buttons
    actionBar.querySelectorAll('.deal-action-btn').forEach(btn => {
      btn.style.cssText = `
        background: white;
        color: #2E7D32;
        border: none;
        padding: 4px 8px;
        border-radius: 4px;
        font-size: 10px;
        font-weight: bold;
        cursor: pointer;
        transition: all 0.2s ease;
      `;
      
      btn.addEventListener('mouseenter', () => {
        btn.style.background = '#E8F5E8';
        btn.style.transform = 'translateY(-1px)';
      });
      
      btn.addEventListener('mouseleave', () => {
        btn.style.background = 'white';
        btn.style.transform = 'translateY(0)';
      });
    });

    // Add click handlers for action buttons
    actionBar.querySelector('.book-now').addEventListener('click', (e) => {
      e.stopPropagation();
      this.bookLoadImmediately(row);
    });

    actionBar.querySelector('.negotiate').addEventListener('click', (e) => {
      e.stopPropagation();
      this.openNegotiationModal(row);
    });

    actionBar.querySelector('.save-load').addEventListener('click', (e) => {
      e.stopPropagation();
      this.saveLoadToFavorites(row);
    });

    // Show action bar on hover
    row.addEventListener('mouseenter', () => {
      actionBar.style.opacity = '1';
      actionBar.style.bottom = '0px';
    });

    row.addEventListener('mouseleave', () => {
      actionBar.style.opacity = '0';
      actionBar.style.bottom = '-30px';
    });

    // Make row relatively positioned for overlays
    row.style.position = 'relative';
    row.style.overflow = 'visible';

    // Append all elements
    row.appendChild(overlay);
    row.appendChild(mailIcon);
    row.appendChild(dealBadge);
    row.appendChild(actionBar);

    // Add pulsing effect for excellent deals
    if (isExcellent) {
      row.style.boxShadow = '0 0 20px rgba(76, 175, 80, 0.5)';
    }
  }

  // Enhanced broker contact methods
  openContactBrokerModal(row) {
    const loadData = this.extractLoadDataFromRow(row);
    if (!loadData) return;

    const modal = document.createElement('div');
    modal.className = 'contact-broker-modal';
    modal.innerHTML = `
      <div class="modal-content">
        <div class="modal-header">
          <h3>📧 Contact Broker - Quick Message</h3>
          <button class="close-modal">×</button>
        </div>
        <div class="modal-body">
          <div class="load-summary">
            <p><strong>Route:</strong> ${loadData.origin} → ${loadData.destination}</p>
            <p><strong>Rate:</strong> $${loadData.rate.toLocaleString()}</p>
            <p><strong>DHO:</strong> ${loadData.dho} miles</p>
          </div>
          <div class="message-templates">
            <h4>Quick Templates:</h4>
            <button class="template-btn" data-template="interested">💰 I'm Interested</button>
            <button class="template-btn" data-template="negotiate">💬 Rate Negotiation</button>
            <button class="template-btn" data-template="available">🚛 Equipment Available</button>
          </div>
          <textarea class="message-text" placeholder="Type your message here..."></textarea>
          <div class="modal-actions">
            <button class="send-message-btn">📧 Send Message</button>
            <button class="cancel-btn">Cancel</button>
          </div>
        </div>
      </div>
    `;

    modal.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0,0,0,0.7);
      z-index: 999999;
      display: flex;
      align-items: center;
      justify-content: center;
    `;

    // Style the modal content
    const modalContent = modal.querySelector('.modal-content');
    modalContent.style.cssText = `
      background: white;
      border-radius: 12px;
      padding: 24px;
      max-width: 500px;
      width: 90%;
      box-shadow: 0 8px 32px rgba(0,0,0,0.3);
    `;

    // Add event listeners
    modal.querySelector('.close-modal').addEventListener('click', () => modal.remove());
    modal.querySelector('.cancel-btn').addEventListener('click', () => modal.remove());
    
    modal.querySelectorAll('.template-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const template = this.getMessageTemplate(btn.dataset.template, loadData);
        modal.querySelector('.message-text').value = template;
      });
    });

    modal.querySelector('.send-message-btn').addEventListener('click', () => {
      const message = modal.querySelector('.message-text').value;
      if (message.trim()) {
        this.sendBrokerMessage(loadData, message);
        modal.remove();
      }
    });

    document.body.appendChild(modal);
  }

  getMessageTemplate(type, loadData) {
    const templates = {
      interested: `Hi! I'm very interested in your load from ${loadData.origin} to ${loadData.destination}. I have a reliable truck available and can pick up immediately. Please let me know if this is still available. Thank you!`,
      negotiate: `Hello, I'm interested in your ${loadData.origin} to ${loadData.destination} load. My rate would be $${(loadData.rate * 1.1).toFixed(0)} for immediate pickup with my experienced driver. Can we work together on this?`,
      available: `Hi! I have equipment available for your ${loadData.origin} to ${loadData.destination} load. Clean truck, experienced driver, and excellent track record. Ready to move immediately at posted rate of $${loadData.rate.toLocaleString()}. Please confirm availability.`
    };
    return templates[type] || '';
  }

  bookLoadImmediately(row) {
    const loadData = this.extractLoadDataFromRow(row);
    if (!loadData) return;

    // Show confirmation dialog
    const confirmed = confirm(
      `🚛 BOOK LOAD IMMEDIATELY?\n\n` +
      `Route: ${loadData.origin} → ${loadData.destination}\n` +
      `Rate: $${loadData.rate.toLocaleString()}\n` +
      `DHO: ${loadData.dho} miles\n\n` +
      `Click OK to attempt booking this load now!`
    );

    if (confirmed) {
      // Simulate booking process
      this.showBookingProgress(row, loadData);
    }
  }

  showBookingProgress(row, loadData) {
    const progress = document.createElement('div');
    progress.className = 'booking-progress';
    progress.innerHTML = `
      <div class="progress-content">
        <div class="spinner"></div>
        <p>📞 Booking load...</p>
        <p class="load-info">${loadData.origin} → ${loadData.destination}</p>
      </div>
    `;
    
    progress.style.cssText = `
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background: white;
      padding: 24px;
      border-radius: 12px;
      box-shadow: 0 8px 32px rgba(0,0,0,0.3);
      z-index: 999999;
      text-align: center;
    `;

    document.body.appendChild(progress);

    // Simulate booking process
    setTimeout(() => {
      progress.innerHTML = `
        <div class="progress-content">
          <div style="font-size: 48px; color: #4CAF50;">✅</div>
          <h3 style="color: #2E7D32; margin: 16px 0 8px 0;">Booking Successful!</h3>
          <p>Load has been booked successfully.</p>
          <p class="load-info">${loadData.origin} → ${loadData.destination}</p>
          <button class="close-progress" style="margin-top: 16px; padding: 8px 16px; background: #4CAF50; color: white; border: none; border-radius: 4px; cursor: pointer;">Close</button>
        </div>
      `;
      
      progress.querySelector('.close-progress').addEventListener('click', () => {
        progress.remove();
        // Add success highlighting to the row
        row.style.background = 'linear-gradient(90deg, rgba(76, 175, 80, 0.3), rgba(129, 199, 132, 0.2))';
        row.style.border = '2px solid #4CAF50';
      });
    }, 2000);
  }

  openNegotiationModal(row) {
    const loadData = this.extractLoadDataFromRow(row);
    if (!loadData) return;

    const suggestedRate = Math.round(loadData.rate * 1.15);
    
    const modal = document.createElement('div');
    modal.className = 'negotiation-modal';
    modal.innerHTML = `
      <div class="modal-content">
        <div class="modal-header">
          <h3>💬 Rate Negotiation</h3>
          <button class="close-modal">×</button>
        </div>
        <div class="modal-body">
          <div class="current-rate">
            <p><strong>Posted Rate:</strong> $${loadData.rate.toLocaleString()}</p>
            <p><strong>Suggested Counter:</strong> $${suggestedRate.toLocaleString()}</p>
          </div>
          <div class="rate-input">
            <label>Your Counter Offer:</label>
            <input type="number" class="counter-rate" value="${suggestedRate}" min="${loadData.rate}" step="50">
          </div>
          <div class="negotiation-message">
            <label>Message to Broker:</label>
            <textarea class="nego-message" placeholder="Enter your negotiation message...">Hi! I'm interested in this load and can offer $${suggestedRate} for immediate pickup with an experienced driver. Please let me know if we can work together. Thank you!</textarea>
          </div>
          <div class="modal-actions">
            <button class="send-counter-btn">💬 Send Counter Offer</button>
            <button class="cancel-nego-btn">Cancel</button>
          </div>
        </div>
      </div>
    `;

    // Apply modal styling and show
    this.showModal(modal, () => {
      const counterRate = modal.querySelector('.counter-rate').value;
      const message = modal.querySelector('.nego-message').value;
      this.sendCounterOffer(loadData, counterRate, message);
    });
  }

  saveLoadToFavorites(row) {
    const loadData = this.extractLoadDataFromRow(row);
    if (!loadData) return;

    // Save to local storage
    const favorites = JSON.parse(localStorage.getItem('datSpeedFavorites') || '[]');
    const loadId = `${loadData.origin}-${loadData.destination}-${loadData.rate}`;
    
    if (!favorites.find(fav => fav.id === loadId)) {
      favorites.push({
        id: loadId,
        ...loadData,
        savedAt: new Date().toISOString()
      });
      
      localStorage.setItem('datSpeedFavorites', JSON.stringify(favorites));
      
      // Show success notification
      this.showNotification('⭐ Load saved to favorites!', 'success');
      
      // Add visual feedback to the row
      const saveIcon = document.createElement('div');
      saveIcon.innerHTML = '⭐';
      saveIcon.style.cssText = `
        position: absolute;
        top: 8px;
        left: 50px;
        background: #FF9800;
        color: white;
        width: 24px;
        height: 24px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 12px;
        z-index: 10;
        animation: starSaved 0.5s ease;
      `;
      row.appendChild(saveIcon);
    } else {
      this.showNotification('Load already in favorites', 'warning');
    }
  }

  showModal(modal, onConfirm) {
    modal.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0,0,0,0.7);
      z-index: 999999;
      display: flex;
      align-items: center;
      justify-content: center;
    `;

    const modalContent = modal.querySelector('.modal-content');
    modalContent.style.cssText = `
      background: white;
      border-radius: 12px;
      padding: 24px;
      max-width: 500px;
      width: 90%;
      box-shadow: 0 8px 32px rgba(0,0,0,0.3);
    `;

    modal.querySelector('.close-modal').addEventListener('click', () => modal.remove());
    modal.querySelector('[class*="cancel"]').addEventListener('click', () => modal.remove());
    modal.querySelector('[class*="send"]').addEventListener('click', () => {
      onConfirm();
      modal.remove();
    });

    document.body.appendChild(modal);
  }

  sendBrokerMessage(loadData, message) {
    this.showNotification('📧 Message sent to broker!', 'success');
    console.log('Sending message:', { loadData, message });
  }

  sendCounterOffer(loadData, counterRate, message) {
    this.showNotification(`💬 Counter offer of $${parseInt(counterRate).toLocaleString()} sent!`, 'success');
    console.log('Sending counter offer:', { loadData, counterRate, message });
  }

  showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = 'speed-notification';
    notification.innerHTML = message;
    
    const colors = {
      success: '#4CAF50',
      warning: '#FF9800',
      error: '#F44336',
      info: '#2196F3'
    };

    notification.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: ${colors[type]};
      color: white;
      padding: 12px 20px;
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.3);
      z-index: 999999;
      font-weight: 600;
      animation: slideInNotification 0.3s ease;
    `;

    document.body.appendChild(notification);

    setTimeout(() => {
      notification.style.animation = 'slideOutNotification 0.3s ease';
      setTimeout(() => notification.remove(), 300);
    }, 3000);
  }

  // AI Highlighting Control Methods
  applyAIHighlighting() {
    console.log('🤖 Applying AI highlighting...');
    
    // Re-enhance all load rows with AI highlighting
    const rows = document.querySelectorAll('[data-test="results-table-body"] .row-container');
    rows.forEach(row => {
      const aiScore = parseInt(row.dataset.aiScore) || 0;
      if (aiScore > 0) {
        this.applyRowHighlighting(row, aiScore);
      }
    });
  }

  removeAIHighlighting() {
    console.log('🤖 Removing AI highlighting...');
    
    const rows = document.querySelectorAll('[data-test="results-table-body"] .row-container');
    rows.forEach(row => {
      // Remove highlighting classes
      row.classList.remove('high-score', 'medium-score', 'low-score', 'excellent-deal', 'good-deal');
      
      // Remove overlays and badges
      const overlay = row.querySelector('.good-deal-overlay');
      if (overlay) overlay.remove();
      
      const badge = row.querySelector('.deal-badge');
      if (badge) badge.remove();
      
      const mailIcon = row.querySelector('.deal-mail-icon');
      if (mailIcon) mailIcon.remove();
      
      const profitBadge = row.querySelector('.enhanced-profit-badge');
      if (profitBadge) profitBadge.remove();
    });
  }

  showNotification(message) {
    // Create a notification element
    const notification = document.createElement('div');
    notification.className = 'dat-speed-notification';
    notification.textContent = message;
    notification.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: #4CAF50;
      color: white;
      padding: 12px 20px;
      border-radius: 6px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.3);
      z-index: 10000;
      font-size: 14px;
      font-weight: 500;
      max-width: 300px;
      animation: slideIn 0.3s ease-out;
    `;

    document.body.appendChild(notification);

    // Remove after 3 seconds
    setTimeout(() => {
      notification.style.animation = 'slideOut 0.3s ease-in';
      setTimeout(() => notification.remove(), 300);
    }, 3000);
  }
  
  addDebugControls() {
    // Add debug button to the UI
    const debugBtn = document.createElement('button');
    debugBtn.id = 'debug-extension';
    debugBtn.className = 'pro-btn pro-btn-debug';
    debugBtn.innerHTML = `
      <span class="btn-icon">🔧</span>
      <span class="btn-text">Debug Extension</span>
    `;
    debugBtn.style.cssText = `
      margin-top: 10px;
      background: #e11d48;
      border-color: #be185d;
    `;
    
    // Find the sidebar and add the button
    const sidebar = document.getElementById('dat-speed-sidebar');
    if (sidebar) {
      sidebar.appendChild(debugBtn);
      
      debugBtn.addEventListener('click', () => {
        console.log('🔧 Manual debug triggered...');
        const result = this.debugPageStructure();
        
        // Show debug info in popup
        alert(`Debug Info:
URL: ${result.url}
Title: ${result.title}
Rows found: ${result.rowCount}
Has load data: ${result.hasLoadData}

Check console for detailed information.`);
      });
    }
  }
}
