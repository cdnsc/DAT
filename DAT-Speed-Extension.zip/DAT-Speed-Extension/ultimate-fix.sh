#!/bin/bash
# 🔧 Ultimate lxml Fix - Multiple Strategies
# Run this if emergency-fix.sh doesn't work

echo "🔧 ULTIMATE LXML FIX - TRYING MULTIPLE APPROACHES..."
echo ""

# Strategy 1: Install from system packages first
echo "📦 Strategy 1: Installing lxml from system packages..."
sudo dnf install -y python3-lxml

# Strategy 2: Use conda if available
if command -v conda &> /dev/null; then
    echo "📦 Strategy 2: Installing lxml via conda..."
    conda install -y lxml
fi

# Strategy 3: Use pre-compiled wheel
echo "📦 Strategy 3: Trying pre-compiled wheel..."
python3 -m pip install --only-binary=lxml lxml

# Strategy 4: Build with specific flags
echo "📦 Strategy 4: Building with specific compiler flags..."
export CFLAGS="-I/usr/include/libxml2"
export LDFLAGS="-L/usr/lib64"
python3 -m pip install --no-cache-dir --force-reinstall lxml==5.1.0

echo "✅ One of the strategies should have worked!"
echo "🧪 Testing lxml import..."
python3 -c "import lxml; print('✅ lxml import successful!')"

echo "📦 Installing remaining requirements..."
python3 -m pip install -r requirements.txt

echo "🚀 Ready to run: ./start.sh"
